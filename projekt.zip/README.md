# Eventtechnik – Minecraft-Mod (Fabric, Minecraft Java 26.3)

Version 0.5: Presets, neue Animationen, Beat-Sync, LED-Cubes am Festival. Davor 0.4: DJ-Pult mit PA und Subwoofern, Laser, LED-Dancefloor, Pult-Seiten, Verfolger, echter Haze, verbundene Truss, grösseres Festival. Festival-Strukturen, Audio-Sync, LED-Wand und DJ-Zeug folgen in den nächsten Versionen.

## Was drin ist

| Block | Funktion |
|---|---|
| **Lichtpult** | Rechtsklick öffnet die Steuerung: Blackout, Strobe, Dimmer, 8 Farben + Regenbogen, 5 Effekte, Speed, Haze |
| **Moving Head Spot** | Schmaler, langer Lichtkegel (bis 32 Blöcke), Bügel und Kopf bewegen sich sichtbar |
| **Moving Head Wash** | Breiter, weicher Lichtkegel |
| **LED-Bar** | Wechselt Farbe, Lauflicht (Chase) bei allen Effekten ausser "Statisch" |
| **Hazer** | Nebel. Je mehr Haze, desto dichter und sichtbarer die Strahlen |
| **LED-Wand Panel** | Mehrere Panels nebeneinander/übereinander ergeben eine grosse LED-Wand mit durchgehenden Mustern |
| **Laser** | Fächer aus 9 Strahlen, bewegt sich mit den Effekten |
| **LED-Dancefloor** | Leuchtender Boden, mehrere Platten ergeben ein grosses Muster |
| **DJ-Pult** | 4 eigene Tracks, Play/Stop, Lautstärke, Auto (spielt nachts) |
| **PA-Top** | Spielt die Höhen (Hats, Claps, Synths) |
| **Subwoofer** | Spielt den Bass (Kick, Bassline). Ohne Subwoofer kein Bass! |
| **Truss** | Verbindet sich mit Nachbar-Truss zu Traversen und Türmen |

## Lichtpult

- **Presets:** Oben rechts auf "Presets" – 12 fertige Shows (Warm Up, Deep Blue, Techno, Red Alert, Festival Drop, Fire, Matrix, Sunset, Police, Ambient White, Rave, DJ Focus). Auto spielt sie nacheinander ab.
- **Sync:** Läuft ein DJ-Pult in der Nähe, laufen Bewegungen, Strobe und LED-Muster im Takt der Musik.
- **Effekte Heads/Laser:** Statisch, Circle, Sweep, Ballyhoo, Publikum, Verfolger, Wave, Kreuz, Fly-Out, Random.
- **Effekte LED-Wand/Floor/Bars:** Fläche, Puls, Lauflicht, Glitzer, Equalizer, Feuer, Matrix, Wellen, Scanner, Schach.

- **Seiten:** Oben wählst du Alle, Spots, Washes, LED-Bars, LED-Wand, Laser oder Floor – jede Seite hat eigene Einstellungen.
- **Verfolger:** Effekt "Verfolger" wählen und unten bei "Ziel" einen Spieler (z.B. den DJ) – die Heads folgen ihm.
- **Gruppen:** Rechtsklick **mit leerer Hand** auf ein Gerät schaltet die Gruppe weiter (1–8). Oben im Pult wählst du "Alle" oder eine Gruppe.
- **Pro Gruppe:** an/aus, Dimmer, Farbe, Effekt.
- **Master:** Blackout, Strobe, Master-Dimmer, Speed, Haze, **Auto** (Show läuft nur nachts und wechselt selbst).
- **Effekte auf der LED-Wand:** Statisch = Fläche, Circle = Regenbogenwelle, Sweep = Lauflicht, Ballyhoo = Glitzer, Publikum = Equalizer.

## Festival-Struktur

In Ebenen, Wiesen, Savannen und Wäldern entstehen verlassene Festivalgelände: Bühne mit Truss, Heads und LED-Wand, PA, FOH mit Lichtpult, Bar, Zelte, Toi-Tois, Merch-Stand und ein Backstage-Container mit Loot. Nachts starten Licht und Musik automatisch, und im Publikum tauchen Zombie-Gäste auf. Am Eingang steht die Security. Barkeeper und Food-Stand verkaufen gegen Gold-Nuggets (findest du in den Kisten) Tränke und Essen.

Zum Finden in einer **neuen Welt**: `/locate structure eventtechnik:festival`

- Geräte verbinden sich **automatisch** mit dem nächsten Lichtpult im Umkreis von 48 Blöcken.
- Geräte zeigen beim Setzen **zu dir** (wie ein Kolben): Schaust du nach unten, zeigt der Head nach oben. Von unten an eine Truss gesetzt, hängt er kopfüber. Von der Seite gesetzt, zeigt er zur Seite.
- Strahlen enden an festen Blöcken. Ohne Haze sind sie schwach, mit Haze hell und dicht – wie in echt.
- Alle Blöcke sind auch im Survival craftbar (Rezeptbuch, Kategorie Redstone).
- Im Creative-Modus findest du alles im Tab **Funktionsblöcke**.

## Mod bauen (einmalig einrichten)

1. **Java 25 installieren**: [Eclipse Temurin JDK 25](https://adoptium.net/temurin/releases/?version=25) für Windows (.msi), bei der Installation "Set JAVA_HOME" anhaken.
2. Den Ordner `eventtechnik` irgendwo entpacken, z.B. `C:\Mods\eventtechnik`.
3. Im Ordner in die Adresszeile des Explorers `cmd` tippen und Enter drücken.
4. Zum **direkten Testen** (startet Minecraft mit der Mod):
   ```
   gradlew.bat runClient
   ```
   Der erste Start dauert ein paar Minuten, weil Minecraft und Fabric heruntergeladen werden.
5. Zum **Bauen der .jar**:
   ```
   gradlew.bat build
   ```
   Die fertige Mod liegt dann in `build\libs\eventtechnik-0.1.0.jar`.

## In deinem normalen Minecraft spielen

1. [Fabric Installer](https://fabricmc.net/use/installer/) starten, Version 26.3 wählen, installieren.
2. [Fabric API](https://modrinth.com/mod/fabric-api) für 26.3 herunterladen.
3. Beide .jar-Dateien (Fabric API + `eventtechnik-0.1.0.jar`) nach `%appdata%\.minecraft\mods` kopieren.
4. Im Launcher das Fabric-Profil starten.

## Erste Show in 1 Minute

1. Lichtpult hinstellen.
2. 3–5 Moving Heads auf eine Truss-Reihe setzen (oder von unten dranhängen), ein paar LED-Bars an die Bühnenkante, einen Hazer.
3. Nacht machen (`/time set night`), Pult rechtsklicken, Effekt "Circle" oder "Ballyhoo", Haze auf 6+.

## Hinweis

Die Mod wurde für Fabric 26.3 geschrieben, aber noch nicht kompiliert. Falls `gradlew.bat build` einen Fehler zeigt, kopiere die Fehlermeldung in den Chat, dann wird sie korrigiert.
