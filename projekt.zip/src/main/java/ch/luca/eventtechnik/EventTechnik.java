package ch.luca.eventtechnik;

import java.util.function.Consumer;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;

import net.fabricmc.api.ModInitializer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ch.luca.eventtechnik.audio.DjTracks;
import ch.luca.eventtechnik.network.ModNetworking;
import ch.luca.eventtechnik.registry.ModBlockEntities;
import ch.luca.eventtechnik.registry.ModBlocks;

public class EventTechnik implements ModInitializer {
	public static final String MOD_ID = "eventtechnik";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	/**
	 * Wird vom Client gesetzt, damit der Pult-Block das GUI öffnen kann,
	 * ohne dass der Server-Code Client-Klassen kennen muss.
	 */
	public static Consumer<BlockPos> openConsoleScreen = pos -> { };
	public static Consumer<BlockPos> openDjScreen = pos -> { };

	@Override
	public void onInitialize() {
		DjTracks.initialize();
		ModBlocks.initialize();
		ModBlockEntities.initialize();
		ModNetworking.initialize();
		LOGGER.info("Eventtechnik geladen – Licht an!");
	}

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
