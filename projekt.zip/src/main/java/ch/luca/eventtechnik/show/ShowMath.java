package ch.luca.eventtechnik.show;

import net.minecraft.core.BlockPos;

import ch.luca.eventtechnik.blockentity.ConsoleBlockEntity;

/**
 * Alle Show-Berechnungen: Farben, Bewegungs-Effekte (Heads/Laser), Pixel-Effekte (LED-Wand, Floor, Bars).
 * Läuft ein DJ-Pult und ist Sync an, rechnen die Effekte im Takt der Musik.
 */
public final class ShowMath {
	private ShowMath() { }

	public static final int[] COLORS = {
			0xFFFFFF, // Weiss
			0xFF2020, // Rot
			0xFF8800, // Orange
			0xFFE600, // Gelb
			0x20FF40, // Grün
			0x00E5FF, // Cyan
			0x2040FF, // Blau
			0xFF20E0  // Magenta
	};
	public static final String[] COLOR_NAMES = {"Weiss", "Rot", "Orange", "Gelb", "Grün", "Cyan", "Blau", "Magenta", "Regenbogen"};
	public static final int RAINBOW = 8;

	public static final int EFFECT_COUNT = 10;
	public static final String[] HEAD_FX = {"Statisch", "Circle", "Sweep", "Ballyhoo", "Publikum", "Verfolger", "Wave", "Kreuz", "Fly-Out", "Random"};
	public static final String[] PIXEL_FX = {"Fläche", "Puls", "Lauflicht", "Glitzer", "Equalizer", "Feuer", "Matrix", "Wellen", "Scanner", "Schach"};
	public static final int FOLLOW = 5;

	/** Sind auf dieser Pult-Seite Pixel-Geräte (LED-Bars, LED-Wand, Floor)? */
	public static boolean isPixelPage(int page) {
		return page == 2 || page == 3 || page == 5;
	}

	public static String[] effectNames(int page) {
		return isPixelPage(page) ? PIXEL_FX : HEAD_FX;
	}

	/** Versatz pro Gerät (-2..2), damit Heads einen Fächer bilden. */
	public static int fanPhase(BlockPos pos) {
		return Math.floorMod(pos.getX() * 31 + pos.getZ() * 17, 5) - 2;
	}

	public static int chasePhase(BlockPos pos) {
		return Math.floorMod(pos.getX() + pos.getZ(), 8);
	}

	public static int colorFor(ConsoleBlockEntity console, int page, int group, BlockPos pos, long time) {
		return COLORS[colorIndexFor(console, page, group, pos, time)];
	}

	public static int colorIndexFor(ConsoleBlockEntity console, int page, int group, BlockPos pos, long time) {
		int c = console.getColor(page, group);
		if (c == RAINBOW) {
			return (int) Math.floorMod(time / 10 + chasePhase(pos), 8);
		}
		return c;
	}

	public static boolean isOn(ConsoleBlockEntity console, int page, int group, long time) {
		if (console.isBlackout() || console.getDimmer(page, group) <= 0) return false;
		if (console.isStrobe()) {
			// Im Takt: Sechzehntel-Strobe; sonst feste Frequenz
			if (console.isBeatSynced()) return frac(console.beats(time) * 4) < 0.5;
			return Math.floorMod(time, 4) < 2;
		}
		return true;
	}

	// =====================================================================
	// Bewegung (Heads, Laser)
	// =====================================================================

	/** Pan/Tilt in Radiant, relativ zur Montagerichtung. */
	public static float[] panTilt(ConsoleBlockEntity console, int page, int group, BlockPos pos, double time) {
		double t = console.showTime(time) * console.getSpeed() * 0.025;
		int phase = fanPhase(pos);

		double pan;
		double tilt;
		switch (console.getEffect(page, group)) {
			case 1 -> { // Circle
				pan = t * 2.0 + phase * 0.6;
				tilt = Math.toRadians(30);
			}
			case 2 -> { // Sweep
				pan = Math.PI / 2;
				tilt = Math.sin(t) * Math.toRadians(55) + phase * 0.15;
			}
			case 3 -> { // Ballyhoo
				pan = Math.sin(t * 1.3 + phase) * Math.toRadians(120);
				tilt = Math.toRadians(15 + Math.abs(Math.sin(t * 0.7 + phase)) * 45);
			}
			case 4 -> { // Publikum
				pan = Math.sin(t + phase) * Math.toRadians(25);
				tilt = Math.toRadians(55);
			}
			case 6 -> { // Wave: die Köpfe laufen als Welle durch die Reihe
				pan = Math.PI / 2;
				tilt = Math.sin(t * 1.5 - phase * 0.9) * Math.toRadians(45);
			}
			case 7 -> { // Kreuz: abwechselnd nach links und rechts, die Strahlen kreuzen sich
				pan = Math.PI / 2;
				double side = (Math.floorMod(phase, 2) == 0) ? 1 : -1;
				tilt = side * (Math.toRadians(20) + Math.abs(Math.sin(t)) * Math.toRadians(30));
			}
			case 8 -> { // Fly-Out: alle gleichzeitig vom Zentrum nach aussen
				pan = Math.PI / 2;
				double open = Math.sin(t * 1.2) * 0.5 + 0.5;
				tilt = phase * Math.toRadians(8 + open * 18);
			}
			case 9 -> { // Random: springt im Takt zu neuen Positionen (weich überblendet)
				double step = Math.floor(t * 1.5);
				double f = smooth(frac(t * 1.5));
				double p0 = rand(pos, step) * Math.PI * 2, p1 = rand(pos, step + 1) * Math.PI * 2;
				double t0 = Math.toRadians(10 + rand(pos, step + 77) * 50), t1 = Math.toRadians(10 + rand(pos, step + 78) * 50);
				pan = p0 + (p1 - p0) * f;
				tilt = t0 + (t1 - t0) * f;
			}
			default -> { // Statisch / Verfolger (Verfolger rechnet der Renderer)
				pan = 0;
				tilt = Math.toRadians(phase * 15);
			}
		}
		return new float[] {(float) pan, (float) tilt};
	}

	// =====================================================================
	// Pixel (LED-Wand, Floor, LED-Bars)
	// =====================================================================

	/**
	 * Farbe eines Pixels. u = waagrecht, v = senkrecht (beim Floor: Tiefe), in Pixeln (4 pro Block).
	 * Muster aus Weltkoordinaten → benachbarte Panels ergeben ein grosses Bild.
	 *
	 * @return RGB, oder -1 für aus
	 */
	public static int ledWallPixel(ConsoleBlockEntity console, int page, int group, int u, int v, double time) {
		long tick = (long) time;
		if (!isOn(console, page, group, tick)) return -1;
		double st = console.showTime(time);
		double t = st * console.getSpeed() * 0.05;
		int c = console.getColor(page, group);
		int base = c == RAINBOW ? hsv((float) (u * 0.03 + t * 0.05), 1f, 1f) : COLORS[c];
		float pulse = console.beatPulse(time);

		switch (console.getEffect(page, group)) {
			case 1 -> { // Puls: alles blitzt auf dem Beat und klingt aus
				return scale(base, 0.15f + 0.85f * pulse);
			}
			case 2 -> { // Lauflicht
				int pos = (int) Math.floorMod((long) (t * 3), 24);
				return Math.floorMod(u - pos, 24) < 6 ? base : -1;
			}
			case 3 -> { // Glitzer
				int h = hash(u, v, (int) (t * 2));
				return (h & 7) == 0 ? 0xFFFFFF : ((h & 3) == 1 ? base : -1);
			}
			case 4 -> { // Equalizer, springt auf dem Beat höher
				double level = (Math.sin(u * 0.9 + t * 1.7) * 0.5 + 0.5) * 0.5 + (Math.sin(u * 0.37 - t * 1.1) * 0.5 + 0.5) * 0.3 + pulse * 0.2;
				int height = (int) (level * 8);
				int row = Math.floorMod(v, 8);
				if (row >= height) return -1;
				return row >= 6 ? 0xFF2020 : (row >= 4 ? 0xFFE600 : base);
			}
			case 5 -> { // Feuer: Flammen von unten, Grundfarbe als Glut
				double n = noise(u * 0.35, v * 0.25 - t * 0.9) * 0.6 + noise(u * 0.9, v * 0.6 - t * 1.6) * 0.4;
				int row = Math.floorMod(v, 16);
				double heat = n * 1.25 - row / 16.0 * 0.9 + pulse * 0.15;
				if (heat < 0.15) return -1;
				if (heat > 0.8) return mix(0xFFE600, 0xFFFFFF, (float) Math.min(1, (heat - 0.8) * 4));
				return mix(base, 0xFF8800, (float) ((heat - 0.15) / 0.65));
			}
			case 6 -> { // Matrix: fallende Spuren pro Spalte
				int col = u;
				double speed = 0.6 + (hash(col, 7, 3) & 255) / 255.0;
				double head = Math.floorMod((long) (t * 6 * speed) + (hash(col, 1, 9) & 63), 40);
				double d = head - Math.floorMod(-v, 40);
				if (d < 0 || d > 12) return -1;
				if (d < 1) return 0xEFFFEF;
				return scale(base, (float) (1 - d / 12.0));
			}
			case 7 -> { // Wellen: weiche Helligkeitswellen in der Grundfarbe
				double w = Math.sin(u * 0.22 + t * 0.9) * 0.5 + Math.sin(v * 0.3 - t * 0.6 + u * 0.1) * 0.5;
				float b = (float) (0.2 + 0.8 * (w * 0.5 + 0.5));
				return scale(base, Math.min(1f, b + pulse * 0.25f));
			}
			case 8 -> { // Scanner: Linie läuft hoch und runter, auf dem Beat ein Blitz
				double p = (Math.sin(t * 1.4) * 0.5 + 0.5) * 15;
				double dist = Math.abs(Math.floorMod(v, 16) - p);
				if (dist < 1.2) return 0xFFFFFF;
				if (dist < 3.5) return scale(base, (float) (1 - dist / 3.5));
				return pulse > 0.85 ? scale(base, 0.25f) : -1;
			}
			case 9 -> { // Schach: Blöcke tauschen im Takt
				long beat = console.beatIndex(time);
				boolean on = Math.floorMod(Math.floorDiv(u, 4) + Math.floorDiv(v, 4) + beat, 2) == 0;
				return on ? scale(base, 0.6f + 0.4f * pulse) : -1;
			}
			default -> {
				return base;
			}
		}
	}

	/** Nächste Palettenfarbe (0..7) für ein RGB – für LED-Bars, die nur Palettenfarben kennen. */
	public static int nearestPalette(int rgb) {
		int best = 0;
		long bestD = Long.MAX_VALUE;
		int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
		for (int i = 0; i < COLORS.length; i++) {
			int pr = (COLORS[i] >> 16) & 0xFF, pg = (COLORS[i] >> 8) & 0xFF, pb = COLORS[i] & 0xFF;
			long d = (long) (r - pr) * (r - pr) + (long) (g - pg) * (g - pg) + (long) (b - pb) * (b - pb);
			if (d < bestD) {
				bestD = d;
				best = i;
			}
		}
		return best;
	}

	public static int brightness(int rgb) {
		return Math.max((rgb >> 16) & 0xFF, Math.max((rgb >> 8) & 0xFF, rgb & 0xFF));
	}

	// ---------------- Hilfen ----------------

	public static double frac(double x) {
		return x - Math.floor(x);
	}

	private static double smooth(double x) {
		return x * x * (3 - 2 * x);
	}

	private static double rand(BlockPos pos, double step) {
		return (hash(pos.getX() * 7 + pos.getZ(), pos.getY(), (int) step) & 0xFFFF) / 65535.0;
	}

	private static int hash(int x, int y, int z) {
		int h = x * 73856093 ^ y * 19349663 ^ z * 83492791;
		h ^= (h >>> 13);
		h *= 0x5bd1e995;
		return h ^ (h >>> 15);
	}

	/** Einfaches Wert-Rauschen 0..1. */
	private static double noise(double x, double y) {
		int xi = (int) Math.floor(x), yi = (int) Math.floor(y);
		double fx = smooth(x - xi), fy = smooth(y - yi);
		double a = (hash(xi, yi, 5) & 1023) / 1023.0, b = (hash(xi + 1, yi, 5) & 1023) / 1023.0;
		double c = (hash(xi, yi + 1, 5) & 1023) / 1023.0, d = (hash(xi + 1, yi + 1, 5) & 1023) / 1023.0;
		return (a + (b - a) * fx) + ((c + (d - c) * fx) - (a + (b - a) * fx)) * fy;
	}

	public static int scale(int rgb, float f) {
		f = Math.max(0, Math.min(1, f));
		int r = (int) (((rgb >> 16) & 0xFF) * f);
		int g = (int) (((rgb >> 8) & 0xFF) * f);
		int b = (int) ((rgb & 0xFF) * f);
		return (r << 16) | (g << 8) | b;
	}

	private static int mix(int a, int b, float f) {
		f = Math.max(0, Math.min(1, f));
		int r = (int) (((a >> 16) & 0xFF) * (1 - f) + ((b >> 16) & 0xFF) * f);
		int g = (int) (((a >> 8) & 0xFF) * (1 - f) + ((b >> 8) & 0xFF) * f);
		int bl = (int) ((a & 0xFF) * (1 - f) + (b & 0xFF) * f);
		return (r << 16) | (g << 8) | bl;
	}

	public static int hsv(float h, float s, float v) {
		h = h - (float) Math.floor(h);
		float r, g, b;
		int i = (int) (h * 6);
		float f = h * 6 - i;
		float p = v * (1 - s), q = v * (1 - f * s), tt = v * (1 - (1 - f) * s);
		switch (i % 6) {
			case 0 -> { r = v; g = tt; b = p; }
			case 1 -> { r = q; g = v; b = p; }
			case 2 -> { r = p; g = v; b = tt; }
			case 3 -> { r = p; g = q; b = v; }
			case 4 -> { r = tt; g = p; b = v; }
			default -> { r = v; g = p; b = q; }
		}
		return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
	}
}
