package ch.luca.eventtechnik.show;

import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

import ch.luca.eventtechnik.blockentity.ConsoleBlockEntity;

/**
 * Alle Show-Berechnungen an einem Ort: Farben, Effekte, Pan/Tilt.
 */
public final class ShowMath {
	private ShowMath() { }

	/** Farbpalette des Pults. Index 8 = Regenbogen. */
	public static final int[] COLORS = {
			0xFFFFFF, // Weiss
			0xFF2020, // Rot
			0xFF8800, // Orange
			0xFFE600, // Gelb
			0x20FF40, // Grün
			0x00E5FF, // Cyan
			0x2040FF, // Blau
			0xFF20E0  // Magenta
	};
	public static final String[] COLOR_NAMES = {"Weiss", "Rot", "Orange", "Gelb", "Grün", "Cyan", "Blau", "Magenta", "Regenbogen"};
	public static final int RAINBOW = 8;

	public static final String[] EFFECT_NAMES = {"Statisch", "Circle", "Sweep", "Ballyhoo", "Publikum"};

	/** Versatz pro Gerät (-2..2), damit Heads einen Fächer bilden. */
	public static int fanPhase(BlockPos pos) {
		return Math.floorMod(pos.getX() * 31 + pos.getZ() * 17, 5) - 2;
	}

	/** Versatz pro Gerät (0..7) für Chases. */
	public static int chasePhase(BlockPos pos) {
		return Math.floorMod(pos.getX() + pos.getZ(), 8);
	}

	/** Aktuelle RGB-Farbe für ein Gerät. */
	public static int colorFor(ConsoleBlockEntity console, BlockPos pos, long time) {
		return COLORS[colorIndexFor(console, pos, time)];
	}

	/** Aktueller Paletten-Index (0..7) für ein Gerät. */
	public static int colorIndexFor(ConsoleBlockEntity console, BlockPos pos, long time) {
		int c = console.getColor();
		if (c == RAINBOW) {
			return (int) Math.floorMod(time / 10 + chasePhase(pos), 8);
		}
		return c;
	}

	/** Ist das Licht in diesem Tick sichtbar (Blackout, Dimmer, Strobe)? */
	public static boolean isOn(ConsoleBlockEntity console, long time) {
		if (console.isBlackout() || console.getDimmer() <= 0) return false;
		if (console.isStrobe()) {
			return Math.floorMod(time, 4) < 2;
		}
		return true;
	}

	/**
	 * Strahlrichtung eines Moving Heads.
	 *
	 * @param hanging true = kopfüber an der Truss, Strahl nach unten
	 */
	public static Vec3 beamDirection(ConsoleBlockEntity console, BlockPos pos, boolean hanging, double time) {
		double speed = console.getSpeed() * 0.025;
		double t = time * speed;
		int phase = fanPhase(pos);

		double pan;
		double tilt;
		switch (console.getEffect()) {
			case 1 -> { // Circle
				pan = t * 2.0 + phase * 0.6;
				tilt = Math.toRadians(30);
			}
			case 2 -> { // Sweep
				pan = Math.sin(t) * Math.toRadians(60) + phase * 0.2;
				tilt = Math.toRadians(35);
			}
			case 3 -> { // Ballyhoo
				pan = Math.sin(t * 1.3 + phase) * Math.toRadians(90);
				tilt = Math.toRadians(20 + Math.abs(Math.sin(t * 0.7 + phase)) * 40);
			}
			case 4 -> { // Publikum
				pan = Math.sin(t + phase) * Math.toRadians(20);
				tilt = Math.toRadians(60);
			}
			default -> { // Statischer Fächer
				pan = 0;
				tilt = Math.toRadians(phase * 15);
			}
		}

		double vertical = Math.cos(tilt) * (hanging ? -1 : 1);
		double horizontal = Math.sin(tilt);
		return new Vec3(horizontal * Math.cos(pan), vertical, horizontal * Math.sin(pan)).normalize();
	}
}
