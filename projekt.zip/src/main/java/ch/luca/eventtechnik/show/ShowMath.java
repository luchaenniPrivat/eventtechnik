package ch.luca.eventtechnik.show;

import net.minecraft.core.BlockPos;

import ch.luca.eventtechnik.blockentity.ConsoleBlockEntity;

/**
 * Alle Show-Berechnungen an einem Ort: Farben, Effekte, Pan/Tilt, LED-Wand-Muster.
 */
public final class ShowMath {
	private ShowMath() { }

	/** Farbpalette des Pults. Index 8 = Regenbogen. */
	public static final int[] COLORS = {
			0xFFFFFF, // Weiss
			0xFF2020, // Rot
			0xFF8800, // Orange
			0xFFE600, // Gelb
			0x20FF40, // Grün
			0x00E5FF, // Cyan
			0x2040FF, // Blau
			0xFF20E0  // Magenta
	};
	public static final String[] COLOR_NAMES = {"Weiss", "Rot", "Orange", "Gelb", "Grün", "Cyan", "Blau", "Magenta", "Regenbogen"};
	public static final int RAINBOW = 8;

	/** Effekte. Bei der LED-Wand: Fläche, Regenbogenwelle, Lauflicht, Glitzer, Equalizer. */
	public static final String[] EFFECT_NAMES = {"Statisch", "Circle", "Sweep", "Ballyhoo", "Publikum", "Verfolger"};
	public static final int FOLLOW = 5;

	/** Versatz pro Gerät (-2..2), damit Heads einen Fächer bilden. */
	public static int fanPhase(BlockPos pos) {
		return Math.floorMod(pos.getX() * 31 + pos.getZ() * 17, 5) - 2;
	}

	/** Versatz pro Gerät (0..7) für Chases. */
	public static int chasePhase(BlockPos pos) {
		return Math.floorMod(pos.getX() + pos.getZ(), 8);
	}

	public static int colorFor(ConsoleBlockEntity console, int page, int group, BlockPos pos, long time) {
		return COLORS[colorIndexFor(console, page, group, pos, time)];
	}

	/** Aktueller Paletten-Index (0..7) für ein Gerät. */
	public static int colorIndexFor(ConsoleBlockEntity console, int page, int group, BlockPos pos, long time) {
		int c = console.getColor(page, group);
		if (c == RAINBOW) {
			return (int) Math.floorMod(time / 10 + chasePhase(pos), 8);
		}
		return c;
	}

	/** Ist die Gruppe in diesem Tick sichtbar (Blackout, Dimmer, Gruppe aus, Strobe)? */
	public static boolean isOn(ConsoleBlockEntity console, int page, int group, long time) {
		if (console.isBlackout() || console.getDimmer(page, group) <= 0) return false;
		if (console.isStrobe()) {
			return Math.floorMod(time, 4) < 2;
		}
		return true;
	}

	/**
	 * Pan und Tilt eines Moving Heads in Radiant, relativ zur Montagerichtung.
	 * [0] = Pan (Drehung um die eigene Achse), [1] = Tilt (Neigung weg von der Achse).
	 */
	public static float[] panTilt(ConsoleBlockEntity console, int page, int group, BlockPos pos, double time) {
		double t = time * console.getSpeed() * 0.025;
		int phase = fanPhase(pos);

		double pan;
		double tilt;
		switch (console.getEffect(page, group)) {
			case 1 -> { // Circle
				pan = t * 2.0 + phase * 0.6;
				tilt = Math.toRadians(30);
			}
			case 2 -> { // Sweep
				pan = Math.PI / 2;
				tilt = Math.sin(t) * Math.toRadians(55) + phase * 0.15;
			}
			case 3 -> { // Ballyhoo
				pan = Math.sin(t * 1.3 + phase) * Math.toRadians(120);
				tilt = Math.toRadians(15 + Math.abs(Math.sin(t * 0.7 + phase)) * 45);
			}
			case 4 -> { // Publikum
				pan = Math.sin(t + phase) * Math.toRadians(25);
				tilt = Math.toRadians(55);
			}
			default -> { // Statischer Fächer
				pan = 0;
				tilt = Math.toRadians(phase * 15);
			}
		}
		return new float[] {(float) pan, (float) tilt};
	}

	/**
	 * Farbe eines LED-Pixels der LED-Wand. u = horizontale, v = vertikale Weltkoordinate in Pixeln (4 pro Block).
	 * Weil die Muster aus Weltkoordinaten berechnet werden, ergeben nebeneinanderliegende Panels ein grosses Bild.
	 *
	 * @return RGB, oder -1 für "Pixel aus"
	 */
	public static int ledWallPixel(ConsoleBlockEntity console, int page, int group, int u, int v, double time) {
		long tick = (long) time;
		if (!isOn(console, page, group, tick)) return -1;
		double t = time * console.getSpeed() * 0.05;
		int c = console.getColor(page, group);
		int base = c == RAINBOW ? hsv((float) (u * 0.03 + t * 0.05), 1f, 1f) : COLORS[c];

		switch (console.getEffect(page, group)) {
			case 1 -> { // Regenbogenwelle (eigene Farbe wird zur Welle)
				float h = (float) ((u + v) * 0.025 + t * 0.04);
				return hsv(h, 1f, 1f);
			}
			case 2 -> { // Lauflicht: breiter Balken wandert horizontal
				int pos = (int) Math.floorMod((long) (t * 3), 24);
				return Math.floorMod(u - pos, 24) < 6 ? base : -1;
			}
			case 3 -> { // Glitzer
				int h = hash(u, v, (int) (t * 2));
				return (h & 7) == 0 ? 0xFFFFFF : ((h & 3) == 1 ? base : -1);
			}
			case 4 -> { // Equalizer: Balken pro Spalte, wiederholt sich alle 8 Pixel nach oben
				double level = (Math.sin(u * 0.9 + t * 1.7) * 0.5 + 0.5) * 0.6 + (Math.sin(u * 0.37 - t * 1.1) * 0.5 + 0.5) * 0.4;
				int height = (int) (level * 8);
				int row = Math.floorMod(v, 8);
				if (row >= height) return -1;
				return row >= 6 ? 0xFF2020 : (row >= 4 ? 0xFFE600 : base);
			}
			default -> {
				return base;
			}
		}
	}

	private static int hash(int x, int y, int z) {
		int h = x * 73856093 ^ y * 19349663 ^ z * 83492791;
		h ^= (h >>> 13);
		h *= 0x5bd1e995;
		return h ^ (h >>> 15);
	}

	/** HSV → RGB, h in Umdrehungen (0..1, beliebig gross). */
	public static int hsv(float h, float s, float v) {
		h = h - (float) Math.floor(h);
		float r, g, b;
		int i = (int) (h * 6);
		float f = h * 6 - i;
		float p = v * (1 - s), q = v * (1 - f * s), tt = v * (1 - (1 - f) * s);
		switch (i % 6) {
			case 0 -> { r = v; g = tt; b = p; }
			case 1 -> { r = q; g = v; b = p; }
			case 2 -> { r = p; g = v; b = tt; }
			case 3 -> { r = p; g = q; b = v; }
			case 4 -> { r = tt; g = p; b = v; }
			default -> { r = v; g = p; b = q; }
		}
		return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
	}
}
