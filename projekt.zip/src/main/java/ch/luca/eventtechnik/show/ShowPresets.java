package ch.luca.eventtechnik.show;

import ch.luca.eventtechnik.blockentity.ConsoleBlockEntity;

/**
 * Fertige Shows. Jede legt pro Seite (Spots, Washes, LED-Bars, LED-Wand, Laser, Floor) Effekt und Farben fest.
 * Farben wechseln über die Gruppen ab (Gruppe 1 = erste Farbe, Gruppe 2 = zweite, ...).
 * Im Auto-Modus läuft das Pult diese Presets nacheinander durch.
 */
public final class ShowPresets {
	private ShowPresets() { }

	// Farben
	private static final int W = 0, R = 1, O = 2, Y = 3, G = 4, C = 5, B = 6, M = 7, RB = 8;
	// Head-Effekte
	private static final int H_STATIC = 0, H_CIRCLE = 1, H_SWEEP = 2, H_BALLY = 3, H_AUDIENCE = 4, H_FOLLOW = 5,
			H_WAVE = 6, H_CROSS = 7, H_FLYOUT = 8, H_RANDOM = 9;
	// Pixel-Effekte
	private static final int P_FILL = 0, P_PULSE = 1, P_CHASE = 2, P_SPARKLE = 3, P_EQ = 4, P_FIRE = 5,
			P_MATRIX = 6, P_WAVES = 7, P_SCANNER = 8, P_CHECKER = 9;

	public record Page(int effect, int[] colors, int dimmer) {
		int color(int group) {
			return colors[group % colors.length];
		}
	}

	public record Preset(String name, int speed, int haze, boolean strobe, Page[] pages) { }

	private static Page p(int effect, int dimmer, int... colors) {
		return new Page(effect, colors, dimmer);
	}

	/** Reihenfolge der Seiten: Spots, Washes, LED-Bars, LED-Wand, Laser, Floor. */
	private static Preset preset(String name, int speed, int haze, boolean strobe,
			Page spots, Page washes, Page bars, Page wall, Page laser, Page floor) {
		return new Preset(name, speed, haze, strobe, new Page[] {spots, washes, bars, wall, laser, floor});
	}

	public static final Preset[] PRESETS = {
			preset("Warm Up", 2, 3, false,
					p(H_AUDIENCE, 70, O, Y), p(H_WAVE, 60, O), p(P_WAVES, 70, O),
					p(P_WAVES, 70, O, Y), p(H_STATIC, 0, O), p(P_WAVES, 50, O)),
			preset("Deep Blue", 3, 6, false,
					p(H_SWEEP, 90, C, B), p(H_WAVE, 80, B), p(P_CHASE, 80, B, C),
					p(P_WAVES, 85, B, C), p(H_CIRCLE, 70, C), p(P_WAVES, 70, B)),
			preset("Techno", 8, 8, false,
					p(H_BALLY, 100, W), p(H_CROSS, 90, W, C), p(P_CHASE, 100, W),
					p(P_SCANNER, 100, W), p(H_FLYOUT, 100, G), p(P_CHECKER, 90, W)),
			preset("Red Alert", 7, 6, false,
					p(H_CROSS, 100, R), p(H_SWEEP, 90, R), p(P_PULSE, 100, R),
					p(P_PULSE, 100, R), p(H_RANDOM, 80, R), p(P_PULSE, 80, R)),
			preset("Festival Drop", 9, 10, true,
					p(H_RANDOM, 100, M, C), p(H_BALLY, 100, C, M), p(P_CHASE, 100, M, C),
					p(P_EQ, 100, M, C), p(H_WAVE, 100, C, M), p(P_CHECKER, 100, M, C)),
			preset("Fire", 5, 7, false,
					p(H_WAVE, 90, O, R), p(H_AUDIENCE, 80, R), p(P_FIRE, 100, R),
					p(P_FIRE, 100, R), p(H_STATIC, 0, R), p(P_FIRE, 90, R)),
			preset("Matrix", 5, 7, false,
					p(H_STATIC, 80, G), p(H_SWEEP, 60, G), p(P_MATRIX, 90, G),
					p(P_MATRIX, 100, G), p(H_CIRCLE, 90, G), p(P_MATRIX, 80, G)),
			preset("Sunset", 2, 4, false,
					p(H_CIRCLE, 80, O, M), p(H_WAVE, 70, M, O), p(P_WAVES, 80, M, O),
					p(P_WAVES, 90, O, M), p(H_STATIC, 0, M), p(P_WAVES, 70, M, O)),
			preset("Police", 9, 5, false,
					p(H_SWEEP, 100, R, B), p(H_CROSS, 100, B, R), p(P_CHECKER, 100, R, B),
					p(P_CHECKER, 100, R, B), p(H_FLYOUT, 80, B, R), p(P_CHECKER, 100, B, R)),
			preset("Ambient White", 2, 6, false,
					p(H_STATIC, 60, W), p(H_AUDIENCE, 50, W), p(P_FILL, 40, W),
					p(P_WAVES, 50, W), p(H_STATIC, 0, W), p(P_FILL, 30, W)),
			preset("Rave", 10, 9, true,
					p(H_BALLY, 100, RB), p(H_RANDOM, 100, RB), p(P_SPARKLE, 100, RB),
					p(P_SPARKLE, 100, RB), p(H_RANDOM, 100, RB), p(P_SPARKLE, 100, RB)),
			preset("DJ Focus", 4, 5, false,
					p(H_FOLLOW, 100, W), p(H_AUDIENCE, 70, B), p(P_PULSE, 70, B),
					p(P_PULSE, 90, B, C), p(H_STATIC, 0, B), p(P_PULSE, 60, B)),
	};

	/** Presets, die im Auto-Modus laufen (ohne DJ Focus, der ein Ziel braucht). */
	public static final int AUTO_COUNT = PRESETS.length - 1;

	public static int color(Preset p, int page, int group) {
		return p.pages()[page].color(group);
	}

	public static int effect(Preset p, int page) {
		return p.pages()[page].effect();
	}

	public static int dimmer(Preset p, int page) {
		return p.pages()[page].dimmer();
	}

	/** Schreibt ein Preset fest ins Pult (alle Seiten, alle Gruppen). */
	public static void apply(ConsoleBlockEntity console, int index) {
		if (index < 0 || index >= PRESETS.length) return;
		console.loadPreset(PRESETS[index]);
	}
}
