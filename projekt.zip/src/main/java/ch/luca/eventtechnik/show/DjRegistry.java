package ch.luca.eventtechnik.show;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.jetbrains.annotations.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

/** Merkt sich serverseitig, wo DJ-Pulte stehen, damit Lautsprecher das nächste finden. */
public final class DjRegistry {
	private DjRegistry() { }

	public static final int LINK_RANGE = 48;
	private static final Map<ResourceKey<Level>, Set<BlockPos>> DJS = new ConcurrentHashMap<>();

	public static void add(Level level, BlockPos pos) {
		DJS.computeIfAbsent(level.dimension(), k -> ConcurrentHashMap.newKeySet()).add(pos.immutable());
	}

	public static void remove(Level level, BlockPos pos) {
		Set<BlockPos> set = DJS.get(level.dimension());
		if (set != null) set.remove(pos);
	}

	@Nullable
	public static BlockPos findNearest(Level level, BlockPos from) {
		Set<BlockPos> set = DJS.get(level.dimension());
		if (set == null) return null;
		BlockPos best = null;
		double bestDist = (double) LINK_RANGE * LINK_RANGE;
		for (BlockPos p : set) {
			double d = p.distSqr(from);
			if (d <= bestDist) {
				bestDist = d;
				best = p;
			}
		}
		return best;
	}
}
