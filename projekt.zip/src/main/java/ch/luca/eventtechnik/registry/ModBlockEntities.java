package ch.luca.eventtechnik.registry;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;

import ch.luca.eventtechnik.EventTechnik;
import ch.luca.eventtechnik.blockentity.ConsoleBlockEntity;
import ch.luca.eventtechnik.blockentity.DjBlockEntity;
import ch.luca.eventtechnik.blockentity.FixtureBlockEntity;
import ch.luca.eventtechnik.blockentity.SpeakerBlockEntity;

public final class ModBlockEntities {
	private ModBlockEntities() { }

	public static final BlockEntityType<FixtureBlockEntity> FIXTURE = register("fixture", FixtureBlockEntity::new,
			ModBlocks.MOVING_HEAD_SPOT, ModBlocks.MOVING_HEAD_WASH, ModBlocks.HAZER, ModBlocks.LED_BAR, ModBlocks.LED_PANEL, ModBlocks.LASER, ModBlocks.LED_FLOOR);

	public static final BlockEntityType<ConsoleBlockEntity> CONSOLE = register("lighting_console", ConsoleBlockEntity::new,
			ModBlocks.LIGHTING_CONSOLE);

	public static final BlockEntityType<DjBlockEntity> DJ = register("dj_controller", DjBlockEntity::new,
			ModBlocks.DJ_CONTROLLER);

	public static final BlockEntityType<SpeakerBlockEntity> SPEAKER = register("speaker", SpeakerBlockEntity::new,
			ModBlocks.PA_TOP, ModBlocks.SUBWOOFER);

	private static <T extends BlockEntity> BlockEntityType<T> register(String name,
			FabricBlockEntityTypeBuilder.Factory<? extends T> factory, Block... blocks) {
		return Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE, EventTechnik.id(name),
				FabricBlockEntityTypeBuilder.<T>create(factory, blocks).build());
	}

	public static void initialize() { }
}
