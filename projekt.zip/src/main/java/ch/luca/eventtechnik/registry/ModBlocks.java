package ch.luca.eventtechnik.registry;

import java.util.function.Function;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.references.BlockItemId;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;

import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;

import ch.luca.eventtechnik.EventTechnik;
import ch.luca.eventtechnik.block.ConsoleBlock;
import ch.luca.eventtechnik.block.FixtureBlock;
import ch.luca.eventtechnik.block.FixtureType;
import ch.luca.eventtechnik.block.LedBarBlock;
import ch.luca.eventtechnik.block.DjBlock;
import ch.luca.eventtechnik.block.LedFloorBlock;
import ch.luca.eventtechnik.block.LedPanelBlock;
import ch.luca.eventtechnik.block.SpeakerBlock;
import ch.luca.eventtechnik.block.TrussBlock;

public final class ModBlocks {
	private ModBlocks() { }

	public static final Block MOVING_HEAD_SPOT = register("moving_head_spot",
			p -> new FixtureBlock(p, FixtureType.SPOT),
			BlockBehaviour.Properties.of().strength(1.5f).sound(SoundType.METAL).noOcclusion().lightLevel(s -> 6));

	public static final Block MOVING_HEAD_WASH = register("moving_head_wash",
			p -> new FixtureBlock(p, FixtureType.WASH),
			BlockBehaviour.Properties.of().strength(1.5f).sound(SoundType.METAL).noOcclusion().lightLevel(s -> 8));

	public static final Block HAZER = register("hazer",
			p -> new FixtureBlock(p, FixtureType.HAZER),
			BlockBehaviour.Properties.of().strength(1.5f).sound(SoundType.METAL).noOcclusion());

	public static final Block LED_BAR = register("led_bar",
			LedBarBlock::new,
			BlockBehaviour.Properties.of().strength(1.0f).sound(SoundType.GLASS).noOcclusion().lightLevel(LedBarBlock::getLuminance));

	public static final Block LED_PANEL = register("led_panel",
			LedPanelBlock::new,
			BlockBehaviour.Properties.of().strength(1.0f).sound(SoundType.GLASS).noOcclusion().lightLevel(s -> 10));

	public static final Block LASER = register("laser",
			p -> new FixtureBlock(p, FixtureType.LASER),
			BlockBehaviour.Properties.of().strength(1.5f).sound(SoundType.METAL).noOcclusion().lightLevel(s -> 4));

	public static final Block LED_FLOOR = register("led_floor",
			LedFloorBlock::new,
			BlockBehaviour.Properties.of().strength(1.5f).sound(SoundType.GLASS).lightLevel(s -> 9));

	public static final Block DJ_CONTROLLER = register("dj_controller",
			DjBlock::new,
			BlockBehaviour.Properties.of().strength(2.0f).sound(SoundType.METAL).noOcclusion());

	public static final Block PA_TOP = register("pa_top",
			p -> new SpeakerBlock(p, false),
			BlockBehaviour.Properties.of().strength(2.0f).sound(SoundType.WOOD));

	public static final Block SUBWOOFER = register("subwoofer",
			p -> new SpeakerBlock(p, true),
			BlockBehaviour.Properties.of().strength(2.0f).sound(SoundType.WOOD));

	public static final Block LIGHTING_CONSOLE = register("lighting_console",
			ConsoleBlock::new,
			BlockBehaviour.Properties.of().strength(2.0f).sound(SoundType.METAL).noOcclusion());

	public static final Block TRUSS = register("truss",
			TrussBlock::new,
			BlockBehaviour.Properties.of().strength(3.0f).sound(SoundType.METAL).noOcclusion());

	private static Block register(String name, Function<BlockBehaviour.Properties, Block> factory, BlockBehaviour.Properties properties) {
		Identifier id = EventTechnik.id(name);
		BlockItemId ids = BlockItemId.create(id, id);

		Block block = factory.apply(properties.setId(ids.block()));
		Registry.register(BuiltInRegistries.BLOCK, ids.block(), block);

		BlockItem item = new BlockItem(block, new Item.Properties().useBlockDescriptionPrefix().setId(ids.item()));
		Registry.register(BuiltInRegistries.ITEM, ids.item(), item);
		return block;
	}

	public static void initialize() {
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.FUNCTIONAL_BLOCKS).register(tab -> {
			tab.accept(LIGHTING_CONSOLE.asItem());
			tab.accept(MOVING_HEAD_SPOT.asItem());
			tab.accept(MOVING_HEAD_WASH.asItem());
			tab.accept(LED_BAR.asItem());
			tab.accept(LED_PANEL.asItem());
			tab.accept(HAZER.asItem());
			tab.accept(LASER.asItem());
			tab.accept(LED_FLOOR.asItem());
			tab.accept(DJ_CONTROLLER.asItem());
			tab.accept(PA_TOP.asItem());
			tab.accept(SUBWOOFER.asItem());
			tab.accept(TRUSS.asItem());
		});
	}
}
