package ch.luca.eventtechnik.blockentity;

import java.util.function.Consumer;

import org.jetbrains.annotations.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

import ch.luca.eventtechnik.block.SpeakerBlock;
import ch.luca.eventtechnik.registry.ModBlockEntities;
import ch.luca.eventtechnik.show.DjRegistry;

/**
 * PA-Top oder Subwoofer. Verbindet sich mit dem nächsten DJ-Pult.
 * Den Ton spielt der Client ab (über {@link #clientAudio}).
 */
public class SpeakerBlockEntity extends BlockEntity {
	/** Wird vom Client gesetzt; der Server spielt keinen Ton ab. */
	public static Consumer<SpeakerBlockEntity> clientAudio = s -> { };

	@Nullable
	private BlockPos djPos;

	public SpeakerBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.SPEAKER, pos, state);
	}

	public boolean isSubwoofer() {
		return getBlockState().getBlock() instanceof SpeakerBlock sb && sb.isSubwoofer();
	}

	@Nullable
	public DjBlockEntity dj(Level level) {
		if (djPos == null) return null;
		return level.getBlockEntity(djPos) instanceof DjBlockEntity dj ? dj : null;
	}

	public static void tick(Level level, BlockPos pos, BlockState state, SpeakerBlockEntity speaker) {
		if (level.isClientSide()) {
			clientAudio.accept(speaker);
			return;
		}
		if (level.getGameTime() % 40 == Math.floorMod(pos.asLong(), 40)) {
			BlockPos nearest = DjRegistry.findNearest(level, pos);
			boolean same = nearest == null ? speaker.djPos == null : nearest.equals(speaker.djPos);
			if (!same) {
				speaker.djPos = nearest;
				speaker.setChanged();
			}
		}
	}

	@Override
	public void setChanged() {
		super.setChanged();
		if (level == null) return;
		BlockState state = getBlockState();
		level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
	}

	@Override
	protected void saveAdditional(ValueOutput output) {
		output.putInt("linked", djPos != null ? 1 : 0);
		if (djPos != null) output.putLong("dj", djPos.asLong());
		super.saveAdditional(output);
	}

	@Override
	protected void loadAdditional(ValueInput input) {
		super.loadAdditional(input);
		djPos = input.getIntOr("linked", 0) != 0 ? BlockPos.of(input.getLongOr("dj", 0L)) : null;
	}

	@Override
	public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
		return saveWithoutMetadata(registries);
	}

	@Override
	public Packet<ClientGamePacketListener> getUpdatePacket() {
		return ClientboundBlockEntityDataPacket.create(this);
	}
}
