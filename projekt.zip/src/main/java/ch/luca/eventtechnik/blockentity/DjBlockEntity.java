package ch.luca.eventtechnik.blockentity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

import ch.luca.eventtechnik.audio.DjTracks;
import ch.luca.eventtechnik.registry.ModBlockEntities;
import ch.luca.eventtechnik.show.DjRegistry;

/** DJ-Pult: welcher Track läuft, seit wann, wie laut. Lautsprecher lesen das ab. */
public class DjBlockEntity extends BlockEntity {
	public static final int ACTION_TRACK = 0;
	public static final int ACTION_PLAY = 1;
	public static final int ACTION_VOLUME = 2;
	/** Auto: läuft nachts von selbst (für die Festival-Struktur). */
	public static final int ACTION_AUTO = 3;

	private int track = 0;
	private boolean playing = false;
	private long startTick = 0;
	private int volume = 7;
	private boolean auto = false;

	public DjBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.DJ, pos, state);
	}

	public void applyAction(int action, int value) {
		long now = level == null ? 0 : level.getGameTime();
		switch (action) {
			case ACTION_TRACK -> {
				track = Mth.clamp(value, 0, DjTracks.NAMES.length - 1);
				startTick = now + 4;
			}
			case ACTION_PLAY -> {
				playing = value != 0;
				// kurze Vorlaufzeit, damit alle Clients rechtzeitig Bescheid wissen
				startTick = now + 4;
			}
			case ACTION_VOLUME -> volume = Mth.clamp(value, 0, 10);
			case ACTION_AUTO -> auto = value != 0;
			default -> {
				return;
			}
		}
		setChanged();
	}

	public int getTrack() { return track; }
	public boolean isPlayingSwitch() { return playing; }
	public boolean isAuto() { return auto; }
	public long getStartTick() { return startTick; }
	public int getVolume() { return volume; }

	/** Läuft gerade Musik? (manuell an, oder Auto und Nacht) */
	public boolean isPlaying() {
		if (playing) return true;
		return auto && level != null && level.isDarkOutside();
	}

	/** Track, der gerade spielt (Auto wechselt jede Nacht-Stunde). */
	public int currentTrack() {
		if (!playing && auto && level != null) {
			return (int) Math.floorMod(level.getGameTime() / 6000, DjTracks.NAMES.length);
		}
		return track;
	}

	/** Position im aktuellen Loop in Ticks (0 = Loop beginnt). */
	public long loopPhase(long gameTime) {
		int len = DjTracks.loopTicks(currentTrack());
		return Math.floorMod(gameTime - startTick, (long) len);
	}

	/** Schlag-Phase 0..1 (0 = genau auf dem Beat). Für Licht im Takt. */
	public float beatPhase(double time) {
		int tpb = DjTracks.TICKS_PER_BEAT[currentTrack()];
		double p = (time - startTick) / tpb;
		return (float) (p - Math.floor(p));
	}

	public static void tick(Level level, BlockPos pos, BlockState state, DjBlockEntity dj) {
		if (!level.isClientSide() && level.getGameTime() % 20 == 0) {
			DjRegistry.add(level, pos);
		}
	}

	@Override
	public void setRemoved() {
		if (level != null && !level.isClientSide()) DjRegistry.remove(level, worldPosition);
		super.setRemoved();
	}

	@Override
	public void setChanged() {
		super.setChanged();
		if (level == null) return;
		BlockState state = getBlockState();
		level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
	}

	@Override
	protected void saveAdditional(ValueOutput output) {
		output.putInt("track", track);
		output.putInt("playing", playing ? 1 : 0);
		output.putLong("start", startTick);
		output.putInt("volume", volume);
		output.putInt("auto", auto ? 1 : 0);
		super.saveAdditional(output);
	}

	@Override
	protected void loadAdditional(ValueInput input) {
		super.loadAdditional(input);
		track = Mth.clamp(input.getIntOr("track", 0), 0, DjTracks.NAMES.length - 1);
		playing = input.getIntOr("playing", 0) != 0;
		startTick = input.getLongOr("start", 0L);
		volume = input.getIntOr("volume", 7);
		auto = input.getIntOr("auto", 0) != 0;
	}

	@Override
	public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
		return saveWithoutMetadata(registries);
	}

	@Override
	public Packet<ClientGamePacketListener> getUpdatePacket() {
		return ClientboundBlockEntityDataPacket.create(this);
	}
}
