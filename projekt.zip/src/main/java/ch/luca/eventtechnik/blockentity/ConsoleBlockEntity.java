package ch.luca.eventtechnik.blockentity;

import java.util.UUID;

import org.jetbrains.annotations.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

import ch.luca.eventtechnik.audio.DjTracks;
import ch.luca.eventtechnik.registry.ModBlockEntities;
import ch.luca.eventtechnik.show.ConsoleRegistry;
import ch.luca.eventtechnik.show.DjRegistry;
import ch.luca.eventtechnik.show.ShowPresets;
import ch.luca.eventtechnik.show.ShowMath;

/**
 * Das Lichtpult.
 * Seiten (Spots, Washes, LED-Bars, LED-Wand, Laser, Floor) × 8 Gruppen, jede mit Farbe, Effekt, Dimmer, an/aus.
 * Dazu Master-Regler und ein Verfolger-Ziel (Spieler), dem Heads im Effekt "Verfolger" folgen.
 */
public class ConsoleBlockEntity extends BlockEntity {
	public static final int GROUPS = 8;
	public static final int PAGES = 6;
	public static final String[] PAGE_NAMES = {"Spots", "Washes", "LED-Bars", "LED-Wand", "Laser", "Floor"};

	// Master-Aktionen
	public static final int ACTION_MASTER_DIMMER = 0;
	public static final int ACTION_SPEED = 1;
	public static final int ACTION_STROBE = 2;
	public static final int ACTION_HAZE = 3;
	public static final int ACTION_BLACKOUT = 4;
	public static final int ACTION_AUTO = 5;
	/** value = Entity-ID des Spielers, -1 = kein Ziel. */
	public static final int ACTION_FOLLOW = 6;
	/** value = Preset-Nummer. */
	public static final int ACTION_PRESET = 7;
	/** value = 0/1: Beat-Sync mit dem nächsten DJ-Pult. */
	public static final int ACTION_SYNC = 8;
	// Seiten-/Gruppen-Aktionen
	public static final int ACTION_COLOR = 10;
	public static final int ACTION_EFFECT = 11;
	public static final int ACTION_GROUP_DIMMER = 12;
	public static final int ACTION_GROUP_ON = 13;

	private int masterDimmer = 100;
	private int speed = 4;
	private boolean strobe = false;
	private int haze = 3;
	private boolean blackout = false;
	private boolean auto = false;
	@Nullable
	private UUID followTarget;
	private boolean sync = true;
	private int lastPreset = -1;
	@Nullable
	private BlockPos djPos;

	private final int[][] color = new int[PAGES][GROUPS];
	private final int[][] effect = new int[PAGES][GROUPS];
	private final int[][] groupDimmer = new int[PAGES][GROUPS];
	private final boolean[][] groupOn = new boolean[PAGES][GROUPS];

	public ConsoleBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.CONSOLE, pos, state);
		for (int p = 0; p < PAGES; p++) {
			for (int g = 0; g < GROUPS; g++) {
				color[p][g] = (p + g) % 8;
				effect[p][g] = 1;
				groupDimmer[p][g] = 100;
				groupOn[p][g] = true;
			}
		}
	}

	/** Verpackt Seite und Gruppe in eine Zahl. page/group -1 = alle. */
	public static int target(int page, int group) {
		return (page + 1) * 16 + (group + 1);
	}

	public void applyAction(int action, int target, int value, @Nullable UUID followUuid) {
		switch (action) {
			case ACTION_MASTER_DIMMER -> masterDimmer = Mth.clamp(value, 0, 100);
			case ACTION_SPEED -> speed = Mth.clamp(value, 1, 10);
			case ACTION_STROBE -> strobe = value != 0;
			case ACTION_HAZE -> haze = Mth.clamp(value, 0, 10);
			case ACTION_BLACKOUT -> blackout = value != 0;
			case ACTION_AUTO -> auto = value != 0;
			case ACTION_FOLLOW -> followTarget = followUuid;
			case ACTION_PRESET -> {
				auto = false;
				ShowPresets.apply(this, value);
			}
			case ACTION_SYNC -> sync = value != 0;
			case ACTION_COLOR, ACTION_EFFECT, ACTION_GROUP_DIMMER, ACTION_GROUP_ON -> {
				int page = target / 16 - 1;
				int group = target % 16 - 1;
				for (int p = 0; p < PAGES; p++) {
					if (page >= 0 && p != page) continue;
					for (int g = 0; g < GROUPS; g++) {
						if (group >= 0 && g != group) continue;
						setValue(action, p, g, value);
					}
				}
			}
			default -> {
				return;
			}
		}
		setChanged();
	}

	/** Übernimmt ein Preset in alle Seiten und Gruppen. */
	public void loadPreset(ShowPresets.Preset preset) {
		for (int p = 0; p < PAGES; p++) {
			for (int g = 0; g < GROUPS; g++) {
				color[p][g] = ShowPresets.color(preset, p, g);
				effect[p][g] = ShowPresets.effect(preset, p);
				groupDimmer[p][g] = ShowPresets.dimmer(preset, p);
				groupOn[p][g] = ShowPresets.dimmer(preset, p) > 0;
			}
		}
		speed = preset.speed();
		haze = preset.haze();
		strobe = preset.strobe();
		blackout = false;
		for (int i = 0; i < ShowPresets.PRESETS.length; i++) {
			if (ShowPresets.PRESETS[i] == preset) lastPreset = i;
		}
	}

	private void setValue(int action, int p, int g, int value) {
		switch (action) {
			case ACTION_COLOR -> color[p][g] = Mth.clamp(value, 0, ShowMath.RAINBOW);
			case ACTION_EFFECT -> effect[p][g] = Mth.clamp(value, 0, ShowMath.EFFECT_COUNT - 1);
			case ACTION_GROUP_DIMMER -> groupDimmer[p][g] = Mth.clamp(value, 0, 100);
			case ACTION_GROUP_ON -> groupOn[p][g] = value != 0;
			default -> { }
		}
	}

	private static int pg(int page) {
		return Mth.clamp(page, 0, PAGES - 1);
	}

	private static int gr(int group) {
		return Mth.clamp(group, 0, GROUPS - 1);
	}

	private long time() {
		return level == null ? 0 : level.getGameTime();
	}

	private boolean isNight() {
		return level == null || level.isDarkOutside();
	}

	/** Im Auto-Modus: welches Preset läuft gerade? (wechselt alle 32 Takte bzw. 30 Sekunden) */
	public ShowPresets.Preset autoPreset() {
		long step = isBeatSynced() ? beatIndex(time()) / 128 : time() / 600;
		return ShowPresets.PRESETS[(int) Math.floorMod(step, ShowPresets.AUTO_COUNT)];
	}

	public int getLastPreset() { return auto ? -1 : lastPreset; }
	public boolean isSync() { return sync; }

	// ---- Master ----
	public int getMasterDimmer() { return masterDimmer; }
	public int getSpeed() { return auto ? autoPreset().speed() : speed; }
	public boolean isStrobe() { return auto ? autoPreset().strobe() : strobe; }
	public int getHaze() { return auto ? autoPreset().haze() : haze; }
	public boolean isAuto() { return auto; }
	public boolean isBlackout() { return blackout || (auto && !isNight()); }
	public boolean isBlackoutSwitch() { return blackout; }
	public int getRawSpeed() { return speed; }
	public int getRawHaze() { return haze; }
	@Nullable
	public UUID getFollowTarget() { return followTarget; }

	// ---- Seiten & Gruppen ----
	public int getColor(int page, int group) {
		if (auto) return ShowPresets.color(autoPreset(), pg(page), gr(group));
		return color[pg(page)][gr(group)];
	}

	public int getEffect(int page, int group) {
		if (auto) return ShowPresets.effect(autoPreset(), pg(page));
		return effect[pg(page)][gr(group)];
	}

	public int getGroupDimmer(int page, int group) { return groupDimmer[pg(page)][gr(group)]; }
	public boolean isGroupOn(int page, int group) {
		if (auto) return ShowPresets.dimmer(autoPreset(), pg(page)) > 0;
		return groupOn[pg(page)][gr(group)];
	}
	public int getRawColor(int page, int group) { return color[pg(page)][gr(group)]; }
	public int getRawEffect(int page, int group) { return effect[pg(page)][gr(group)]; }
	public boolean isRawGroupOn(int page, int group) { return groupOn[pg(page)][gr(group)]; }

	/** Wirksame Helligkeit 0..100 (Master × Gruppe). */
	public int getDimmer(int page, int group) {
		if (!isGroupOn(page, group)) return 0;
		int gd = auto ? ShowPresets.dimmer(autoPreset(), pg(page)) : groupDimmer[pg(page)][gr(group)];
		return masterDimmer * gd / 100;
	}

	// ---- Beat-Sync ----

	@Nullable
	private DjBlockEntity dj() {
		if (!sync || djPos == null || level == null) return null;
		return level.getBlockEntity(djPos) instanceof DjBlockEntity d && d.isPlaying() ? d : null;
	}

	/** Läuft gerade Musik, mit der das Licht im Takt ist? */
	public boolean isBeatSynced() {
		return dj() != null;
	}

	/** Anzahl Schläge seit Start. Ohne DJ: ein virtueller Takt mit 120 BPM. */
	public double beats(double time) {
		DjBlockEntity d = dj();
		if (d == null) return time / 10.0;
		return (time - d.getStartTick()) / DjTracks.TICKS_PER_BEAT[d.currentTrack()];
	}

	/** Zeitbasis der Effekte: mit DJ im Takt (10 "Ticks" pro Schlag), sonst echte Ticks. */
	public double showTime(double time) {
		return isBeatSynced() ? beats(time) * 10.0 : time;
	}

	/** 1 genau auf dem Beat, klingt bis zum nächsten Beat ab. */
	public float beatPulse(double time) {
		double ph = ShowMath.frac(beats(time));
		return (float) Math.exp(-ph * 4.5);
	}

	public long beatIndex(double time) {
		return (long) Math.floor(beats(time));
	}

	public static void tick(Level level, BlockPos pos, BlockState state, ConsoleBlockEntity console) {
		if (level.isClientSide()) return;
		if (level.getGameTime() % 20 == 0) {
			ConsoleRegistry.add(level, pos);
		}
		if (level.getGameTime() % 40 == Math.floorMod(pos.asLong(), 40)) {
			BlockPos nearest = DjRegistry.findNearest(level, pos);
			boolean same = nearest == null ? console.djPos == null : nearest.equals(console.djPos);
			if (!same) {
				console.djPos = nearest;
				console.setChanged();
			}
		}
	}

	@Override
	public void setRemoved() {
		if (level != null && !level.isClientSide()) {
			ConsoleRegistry.remove(level, worldPosition);
		}
		super.setRemoved();
	}

	@Override
	public void setChanged() {
		super.setChanged();
		if (level == null) return;
		BlockState state = getBlockState();
		level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
	}

	@Override
	protected void saveAdditional(ValueOutput output) {
		output.putInt("dimmer", masterDimmer);
		output.putInt("speed", speed);
		output.putInt("strobe", strobe ? 1 : 0);
		output.putInt("haze", haze);
		output.putInt("blackout", blackout ? 1 : 0);
		output.putInt("auto", auto ? 1 : 0);
		output.putString("follow", followTarget == null ? "" : followTarget.toString());
		output.putInt("sync", sync ? 1 : 0);
		output.putInt("preset", lastPreset);
		output.putInt("djlinked", djPos != null ? 1 : 0);
		if (djPos != null) output.putLong("dj", djPos.asLong());
		for (int p = 0; p < PAGES; p++) {
			for (int g = 0; g < GROUPS; g++) {
				String k = p + "_" + g;
				output.putInt("c" + k, color[p][g]);
				output.putInt("e" + k, effect[p][g]);
				output.putInt("d" + k, groupDimmer[p][g]);
				output.putInt("o" + k, groupOn[p][g] ? 1 : 0);
			}
		}
		super.saveAdditional(output);
	}

	@Override
	protected void loadAdditional(ValueInput input) {
		super.loadAdditional(input);
		masterDimmer = input.getIntOr("dimmer", 100);
		speed = input.getIntOr("speed", 4);
		strobe = input.getIntOr("strobe", 0) != 0;
		haze = input.getIntOr("haze", 3);
		blackout = input.getIntOr("blackout", 0) != 0;
		auto = input.getIntOr("auto", 0) != 0;
		sync = input.getIntOr("sync", 1) != 0;
		lastPreset = input.getIntOr("preset", -1);
		djPos = input.getIntOr("djlinked", 0) != 0 ? BlockPos.of(input.getLongOr("dj", 0L)) : null;
		String f = input.getStringOr("follow", "");
		try {
			followTarget = f.isEmpty() ? null : UUID.fromString(f);
		} catch (IllegalArgumentException e) {
			followTarget = null;
		}
		for (int p = 0; p < PAGES; p++) {
			for (int g = 0; g < GROUPS; g++) {
				String k = p + "_" + g;
				color[p][g] = input.getIntOr("c" + k, (p + g) % 8);
				effect[p][g] = input.getIntOr("e" + k, 1);
				groupDimmer[p][g] = input.getIntOr("d" + k, 100);
				groupOn[p][g] = input.getIntOr("o" + k, 1) != 0;
			}
		}
	}

	@Override
	public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
		return saveWithoutMetadata(registries);
	}

	@Override
	public Packet<ClientGamePacketListener> getUpdatePacket() {
		return ClientboundBlockEntityDataPacket.create(this);
	}
}
