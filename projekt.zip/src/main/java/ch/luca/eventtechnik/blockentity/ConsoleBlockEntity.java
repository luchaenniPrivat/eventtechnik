package ch.luca.eventtechnik.blockentity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

import ch.luca.eventtechnik.registry.ModBlockEntities;
import ch.luca.eventtechnik.show.ConsoleRegistry;
import ch.luca.eventtechnik.show.ShowMath;

/**
 * Das Lichtpult. Hält den Show-Zustand, den alle Geräte in Reichweite lesen.
 */
public class ConsoleBlockEntity extends BlockEntity {
	// Aktionen, die das GUI an den Server schickt
	public static final int ACTION_DIMMER = 0;   // value = neuer Wert 0..100
	public static final int ACTION_COLOR = 1;    // value = 0..8
	public static final int ACTION_EFFECT = 2;   // value = 0..4
	public static final int ACTION_SPEED = 3;    // value = 1..10
	public static final int ACTION_STROBE = 4;   // value = 0/1
	public static final int ACTION_HAZE = 5;     // value = 0..10
	public static final int ACTION_BLACKOUT = 6; // value = 0/1

	private int dimmer = 100;
	private int color = 0;
	private int effect = 1;
	private int speed = 4;
	private boolean strobe = false;
	private int haze = 3;
	private boolean blackout = false;

	public ConsoleBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.CONSOLE, pos, state);
	}

	public void applyAction(int action, int value) {
		switch (action) {
			case ACTION_DIMMER -> dimmer = Mth.clamp(value, 0, 100);
			case ACTION_COLOR -> color = Mth.clamp(value, 0, ShowMath.RAINBOW);
			case ACTION_EFFECT -> effect = Mth.clamp(value, 0, ShowMath.EFFECT_NAMES.length - 1);
			case ACTION_SPEED -> speed = Mth.clamp(value, 1, 10);
			case ACTION_STROBE -> strobe = value != 0;
			case ACTION_HAZE -> haze = Mth.clamp(value, 0, 10);
			case ACTION_BLACKOUT -> blackout = value != 0;
			default -> {
				return;
			}
		}
		setChanged();
	}

	public int getDimmer() { return dimmer; }
	public int getColor() { return color; }
	public int getEffect() { return effect; }
	public int getSpeed() { return speed; }
	public boolean isStrobe() { return strobe; }
	public int getHaze() { return haze; }
	public boolean isBlackout() { return blackout; }

	public static void tick(Level level, BlockPos pos, BlockState state, ConsoleBlockEntity console) {
		if (!level.isClientSide() && level.getGameTime() % 20 == 0) {
			ConsoleRegistry.add(level, pos);
		}
	}

	@Override
	public void setRemoved() {
		if (level != null && !level.isClientSide()) {
			ConsoleRegistry.remove(level, worldPosition);
		}
		super.setRemoved();
	}

	@Override
	public void setChanged() {
		super.setChanged();
		if (level == null) return;
		BlockState state = getBlockState();
		level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
	}

	@Override
	protected void saveAdditional(ValueOutput output) {
		output.putInt("dimmer", dimmer);
		output.putInt("color", color);
		output.putInt("effect", effect);
		output.putInt("speed", speed);
		output.putInt("strobe", strobe ? 1 : 0);
		output.putInt("haze", haze);
		output.putInt("blackout", blackout ? 1 : 0);
		super.saveAdditional(output);
	}

	@Override
	protected void loadAdditional(ValueInput input) {
		super.loadAdditional(input);
		dimmer = input.getIntOr("dimmer", 100);
		color = input.getIntOr("color", 0);
		effect = input.getIntOr("effect", 1);
		speed = input.getIntOr("speed", 4);
		strobe = input.getIntOr("strobe", 0) != 0;
		haze = input.getIntOr("haze", 3);
		blackout = input.getIntOr("blackout", 0) != 0;
	}

	@Override
	public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
		return saveWithoutMetadata(registries);
	}

	@Override
	public Packet<ClientGamePacketListener> getUpdatePacket() {
		return ClientboundBlockEntityDataPacket.create(this);
	}
}
