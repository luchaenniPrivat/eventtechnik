package ch.luca.eventtechnik.blockentity;

import java.util.UUID;

import org.jetbrains.annotations.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

import ch.luca.eventtechnik.registry.ModBlockEntities;
import ch.luca.eventtechnik.show.ConsoleRegistry;
import ch.luca.eventtechnik.show.ShowMath;

/**
 * Das Lichtpult.
 * Seiten (Spots, Washes, LED-Bars, LED-Wand, Laser, Floor) × 8 Gruppen, jede mit Farbe, Effekt, Dimmer, an/aus.
 * Dazu Master-Regler und ein Verfolger-Ziel (Spieler), dem Heads im Effekt "Verfolger" folgen.
 */
public class ConsoleBlockEntity extends BlockEntity {
	public static final int GROUPS = 8;
	public static final int PAGES = 6;
	public static final String[] PAGE_NAMES = {"Spots", "Washes", "LED-Bars", "LED-Wand", "Laser", "Floor"};

	// Master-Aktionen
	public static final int ACTION_MASTER_DIMMER = 0;
	public static final int ACTION_SPEED = 1;
	public static final int ACTION_STROBE = 2;
	public static final int ACTION_HAZE = 3;
	public static final int ACTION_BLACKOUT = 4;
	public static final int ACTION_AUTO = 5;
	/** value = Entity-ID des Spielers, -1 = kein Ziel. */
	public static final int ACTION_FOLLOW = 6;
	// Seiten-/Gruppen-Aktionen
	public static final int ACTION_COLOR = 10;
	public static final int ACTION_EFFECT = 11;
	public static final int ACTION_GROUP_DIMMER = 12;
	public static final int ACTION_GROUP_ON = 13;

	private int masterDimmer = 100;
	private int speed = 4;
	private boolean strobe = false;
	private int haze = 3;
	private boolean blackout = false;
	private boolean auto = false;
	@Nullable
	private UUID followTarget;

	private final int[][] color = new int[PAGES][GROUPS];
	private final int[][] effect = new int[PAGES][GROUPS];
	private final int[][] groupDimmer = new int[PAGES][GROUPS];
	private final boolean[][] groupOn = new boolean[PAGES][GROUPS];

	public ConsoleBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.CONSOLE, pos, state);
		for (int p = 0; p < PAGES; p++) {
			for (int g = 0; g < GROUPS; g++) {
				color[p][g] = (p + g) % 8;
				effect[p][g] = 1;
				groupDimmer[p][g] = 100;
				groupOn[p][g] = true;
			}
		}
	}

	/** Verpackt Seite und Gruppe in eine Zahl. page/group -1 = alle. */
	public static int target(int page, int group) {
		return (page + 1) * 16 + (group + 1);
	}

	public void applyAction(int action, int target, int value, @Nullable UUID followUuid) {
		switch (action) {
			case ACTION_MASTER_DIMMER -> masterDimmer = Mth.clamp(value, 0, 100);
			case ACTION_SPEED -> speed = Mth.clamp(value, 1, 10);
			case ACTION_STROBE -> strobe = value != 0;
			case ACTION_HAZE -> haze = Mth.clamp(value, 0, 10);
			case ACTION_BLACKOUT -> blackout = value != 0;
			case ACTION_AUTO -> auto = value != 0;
			case ACTION_FOLLOW -> followTarget = followUuid;
			case ACTION_COLOR, ACTION_EFFECT, ACTION_GROUP_DIMMER, ACTION_GROUP_ON -> {
				int page = target / 16 - 1;
				int group = target % 16 - 1;
				for (int p = 0; p < PAGES; p++) {
					if (page >= 0 && p != page) continue;
					for (int g = 0; g < GROUPS; g++) {
						if (group >= 0 && g != group) continue;
						setValue(action, p, g, value);
					}
				}
			}
			default -> {
				return;
			}
		}
		setChanged();
	}

	private void setValue(int action, int p, int g, int value) {
		switch (action) {
			case ACTION_COLOR -> color[p][g] = Mth.clamp(value, 0, ShowMath.RAINBOW);
			case ACTION_EFFECT -> effect[p][g] = Mth.clamp(value, 0, ShowMath.EFFECT_NAMES.length - 1);
			case ACTION_GROUP_DIMMER -> groupDimmer[p][g] = Mth.clamp(value, 0, 100);
			case ACTION_GROUP_ON -> groupOn[p][g] = value != 0;
			default -> { }
		}
	}

	private static int pg(int page) {
		return Mth.clamp(page, 0, PAGES - 1);
	}

	private static int gr(int group) {
		return Mth.clamp(group, 0, GROUPS - 1);
	}

	private long time() {
		return level == null ? 0 : level.getGameTime();
	}

	private boolean isNight() {
		return level == null || level.isDarkOutside();
	}

	// ---- Master ----
	public int getMasterDimmer() { return masterDimmer; }
	public int getSpeed() { return auto ? 5 : speed; }
	public boolean isStrobe() { return strobe; }
	public int getHaze() { return auto ? 6 : haze; }
	public boolean isAuto() { return auto; }
	public boolean isBlackout() { return blackout || (auto && !isNight()); }
	public boolean isBlackoutSwitch() { return blackout; }
	public int getRawSpeed() { return speed; }
	public int getRawHaze() { return haze; }
	@Nullable
	public UUID getFollowTarget() { return followTarget; }

	// ---- Seiten & Gruppen ----
	public int getColor(int page, int group) {
		if (auto) return (int) Math.floorMod(time() / 300 + group + page, 9);
		return color[pg(page)][gr(group)];
	}

	public int getEffect(int page, int group) {
		// Auto wechselt zwischen den Bewegungs-Effekten 1..4 (kein Verfolger)
		if (auto) return (int) Math.floorMod(time() / 400 + group + page, 4) + 1;
		return effect[pg(page)][gr(group)];
	}

	public int getGroupDimmer(int page, int group) { return groupDimmer[pg(page)][gr(group)]; }
	public boolean isGroupOn(int page, int group) { return auto || groupOn[pg(page)][gr(group)]; }
	public int getRawColor(int page, int group) { return color[pg(page)][gr(group)]; }
	public int getRawEffect(int page, int group) { return effect[pg(page)][gr(group)]; }
	public boolean isRawGroupOn(int page, int group) { return groupOn[pg(page)][gr(group)]; }

	/** Wirksame Helligkeit 0..100 (Master × Gruppe). */
	public int getDimmer(int page, int group) {
		if (!isGroupOn(page, group)) return 0;
		return masterDimmer * (auto ? 100 : groupDimmer[pg(page)][gr(group)]) / 100;
	}

	public static void tick(Level level, BlockPos pos, BlockState state, ConsoleBlockEntity console) {
		if (!level.isClientSide() && level.getGameTime() % 20 == 0) {
			ConsoleRegistry.add(level, pos);
		}
	}

	@Override
	public void setRemoved() {
		if (level != null && !level.isClientSide()) {
			ConsoleRegistry.remove(level, worldPosition);
		}
		super.setRemoved();
	}

	@Override
	public void setChanged() {
		super.setChanged();
		if (level == null) return;
		BlockState state = getBlockState();
		level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
	}

	@Override
	protected void saveAdditional(ValueOutput output) {
		output.putInt("dimmer", masterDimmer);
		output.putInt("speed", speed);
		output.putInt("strobe", strobe ? 1 : 0);
		output.putInt("haze", haze);
		output.putInt("blackout", blackout ? 1 : 0);
		output.putInt("auto", auto ? 1 : 0);
		output.putString("follow", followTarget == null ? "" : followTarget.toString());
		for (int p = 0; p < PAGES; p++) {
			for (int g = 0; g < GROUPS; g++) {
				String k = p + "_" + g;
				output.putInt("c" + k, color[p][g]);
				output.putInt("e" + k, effect[p][g]);
				output.putInt("d" + k, groupDimmer[p][g]);
				output.putInt("o" + k, groupOn[p][g] ? 1 : 0);
			}
		}
		super.saveAdditional(output);
	}

	@Override
	protected void loadAdditional(ValueInput input) {
		super.loadAdditional(input);
		masterDimmer = input.getIntOr("dimmer", 100);
		speed = input.getIntOr("speed", 4);
		strobe = input.getIntOr("strobe", 0) != 0;
		haze = input.getIntOr("haze", 3);
		blackout = input.getIntOr("blackout", 0) != 0;
		auto = input.getIntOr("auto", 0) != 0;
		String f = input.getStringOr("follow", "");
		try {
			followTarget = f.isEmpty() ? null : UUID.fromString(f);
		} catch (IllegalArgumentException e) {
			followTarget = null;
		}
		for (int p = 0; p < PAGES; p++) {
			for (int g = 0; g < GROUPS; g++) {
				String k = p + "_" + g;
				color[p][g] = input.getIntOr("c" + k, (p + g) % 8);
				effect[p][g] = input.getIntOr("e" + k, 1);
				groupDimmer[p][g] = input.getIntOr("d" + k, 100);
				groupOn[p][g] = input.getIntOr("o" + k, 1) != 0;
			}
		}
	}

	@Override
	public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
		return saveWithoutMetadata(registries);
	}

	@Override
	public Packet<ClientGamePacketListener> getUpdatePacket() {
		return ClientboundBlockEntityDataPacket.create(this);
	}
}
