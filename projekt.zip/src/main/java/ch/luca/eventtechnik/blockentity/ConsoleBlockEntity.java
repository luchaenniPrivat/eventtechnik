package ch.luca.eventtechnik.blockentity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

import ch.luca.eventtechnik.registry.ModBlockEntities;
import ch.luca.eventtechnik.show.ConsoleRegistry;
import ch.luca.eventtechnik.show.ShowMath;

/**
 * Das Lichtpult. Master-Regler plus 8 Gruppen mit eigener Farbe, Effekt, Dimmer und an/aus.
 * Alle Geräte in Reichweite lesen ihren Zustand hier ab.
 */
public class ConsoleBlockEntity extends BlockEntity {
	public static final int GROUPS = 8;
	/** Gruppe -1 in einer Aktion = alle Gruppen. */
	public static final int ALL_GROUPS = -1;

	// Master-Aktionen (Gruppe wird ignoriert)
	public static final int ACTION_MASTER_DIMMER = 0;
	public static final int ACTION_SPEED = 1;
	public static final int ACTION_STROBE = 2;
	public static final int ACTION_HAZE = 3;
	public static final int ACTION_BLACKOUT = 4;
	public static final int ACTION_AUTO = 5;
	// Gruppen-Aktionen
	public static final int ACTION_COLOR = 10;
	public static final int ACTION_EFFECT = 11;
	public static final int ACTION_GROUP_DIMMER = 12;
	public static final int ACTION_GROUP_ON = 13;

	private int masterDimmer = 100;
	private int speed = 4;
	private boolean strobe = false;
	private int haze = 3;
	private boolean blackout = false;
	/** Automatik: Show läuft nur nachts und wechselt selbst Farben und Effekte. */
	private boolean auto = false;

	private final int[] color = new int[GROUPS];
	private final int[] effect = new int[GROUPS];
	private final int[] groupDimmer = new int[GROUPS];
	private final boolean[] groupOn = new boolean[GROUPS];

	public ConsoleBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.CONSOLE, pos, state);
		for (int g = 0; g < GROUPS; g++) {
			color[g] = g % 8;
			effect[g] = 1;
			groupDimmer[g] = 100;
			groupOn[g] = true;
		}
	}

	public void applyAction(int action, int group, int value) {
		switch (action) {
			case ACTION_MASTER_DIMMER -> masterDimmer = Mth.clamp(value, 0, 100);
			case ACTION_SPEED -> speed = Mth.clamp(value, 1, 10);
			case ACTION_STROBE -> strobe = value != 0;
			case ACTION_HAZE -> haze = Mth.clamp(value, 0, 10);
			case ACTION_BLACKOUT -> blackout = value != 0;
			case ACTION_AUTO -> auto = value != 0;
			case ACTION_COLOR, ACTION_EFFECT, ACTION_GROUP_DIMMER, ACTION_GROUP_ON -> {
				if (group == ALL_GROUPS) {
					for (int g = 0; g < GROUPS; g++) setGroupValue(action, g, value);
				} else if (group >= 0 && group < GROUPS) {
					setGroupValue(action, group, value);
				} else {
					return;
				}
			}
			default -> {
				return;
			}
		}
		setChanged();
	}

	private void setGroupValue(int action, int g, int value) {
		switch (action) {
			case ACTION_COLOR -> color[g] = Mth.clamp(value, 0, ShowMath.RAINBOW);
			case ACTION_EFFECT -> effect[g] = Mth.clamp(value, 0, ShowMath.EFFECT_NAMES.length - 1);
			case ACTION_GROUP_DIMMER -> groupDimmer[g] = Mth.clamp(value, 0, 100);
			case ACTION_GROUP_ON -> groupOn[g] = value != 0;
			default -> { }
		}
	}

	private static int g(int group) {
		return Mth.clamp(group, 0, GROUPS - 1);
	}

	private long time() {
		return level == null ? 0 : level.getGameTime();
	}

	private boolean isNight() {
		return level == null || level.isDarkOutside();
	}

	// ---- Master ----
	public int getMasterDimmer() { return masterDimmer; }
	public int getSpeed() { return auto ? 5 : speed; }
	public boolean isStrobe() { return strobe; }
	public int getHaze() { return auto ? 6 : haze; }
	public boolean isAuto() { return auto; }
	/** Blackout am Pult, oder Automatik am Tag. */
	public boolean isBlackout() { return blackout || (auto && !isNight()); }
	public boolean isBlackoutSwitch() { return blackout; }
	public int getRawSpeed() { return speed; }
	public int getRawHaze() { return haze; }

	// ---- Gruppen ----
	public int getColor(int group) {
		if (auto) return (int) Math.floorMod(time() / 300 + group, 9);
		return color[g(group)];
	}

	public int getEffect(int group) {
		if (auto) return (int) Math.floorMod(time() / 400 + group, ShowMath.EFFECT_NAMES.length - 1) + 1;
		return effect[g(group)];
	}

	public int getGroupDimmer(int group) { return groupDimmer[g(group)]; }
	public boolean isGroupOn(int group) { return auto || groupOn[g(group)]; }
	public int getRawColor(int group) { return color[g(group)]; }
	public int getRawEffect(int group) { return effect[g(group)]; }
	public boolean isRawGroupOn(int group) { return groupOn[g(group)]; }

	/** Wirksame Helligkeit einer Gruppe 0..100 (Master × Gruppe). */
	public int getDimmer(int group) {
		if (!isGroupOn(group)) return 0;
		return masterDimmer * (auto ? 100 : groupDimmer[g(group)]) / 100;
	}

	public static void tick(Level level, BlockPos pos, BlockState state, ConsoleBlockEntity console) {
		if (!level.isClientSide() && level.getGameTime() % 20 == 0) {
			ConsoleRegistry.add(level, pos);
		}
	}

	@Override
	public void setRemoved() {
		if (level != null && !level.isClientSide()) {
			ConsoleRegistry.remove(level, worldPosition);
		}
		super.setRemoved();
	}

	@Override
	public void setChanged() {
		super.setChanged();
		if (level == null) return;
		BlockState state = getBlockState();
		level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
	}

	@Override
	protected void saveAdditional(ValueOutput output) {
		output.putInt("dimmer", masterDimmer);
		output.putInt("speed", speed);
		output.putInt("strobe", strobe ? 1 : 0);
		output.putInt("haze", haze);
		output.putInt("blackout", blackout ? 1 : 0);
		output.putInt("auto", auto ? 1 : 0);
		for (int g = 0; g < GROUPS; g++) {
			output.putInt("color" + g, color[g]);
			output.putInt("effect" + g, effect[g]);
			output.putInt("gdim" + g, groupDimmer[g]);
			output.putInt("gon" + g, groupOn[g] ? 1 : 0);
		}
		super.saveAdditional(output);
	}

	@Override
	protected void loadAdditional(ValueInput input) {
		super.loadAdditional(input);
		masterDimmer = input.getIntOr("dimmer", 100);
		speed = input.getIntOr("speed", 4);
		strobe = input.getIntOr("strobe", 0) != 0;
		haze = input.getIntOr("haze", 3);
		blackout = input.getIntOr("blackout", 0) != 0;
		auto = input.getIntOr("auto", 0) != 0;
		for (int g = 0; g < GROUPS; g++) {
			color[g] = input.getIntOr("color" + g, g % 8);
			effect[g] = input.getIntOr("effect" + g, 1);
			groupDimmer[g] = input.getIntOr("gdim" + g, 100);
			groupOn[g] = input.getIntOr("gon" + g, 1) != 0;
		}
	}

	@Override
	public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
		return saveWithoutMetadata(registries);
	}

	@Override
	public Packet<ClientGamePacketListener> getUpdatePacket() {
		return ClientboundBlockEntityDataPacket.create(this);
	}
}
