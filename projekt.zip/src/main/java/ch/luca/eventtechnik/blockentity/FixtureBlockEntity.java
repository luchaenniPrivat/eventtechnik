package ch.luca.eventtechnik.blockentity;

import org.jetbrains.annotations.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

import ch.luca.eventtechnik.block.FixtureBlock;
import ch.luca.eventtechnik.block.FixtureType;
import ch.luca.eventtechnik.block.LedBarBlock;
import ch.luca.eventtechnik.registry.ModBlockEntities;
import ch.luca.eventtechnik.show.ConsoleRegistry;
import ch.luca.eventtechnik.show.ShowMath;

/**
 * Ein Gerät (Moving Head, Wash, Hazer, LED-Bar).
 * Server: verbindet sich mit dem nächsten Pult und schaltet LED-Bars.
 * Client: Nebel des Hazers (Strahlen zeichnet der FixtureRenderer).
 */
public class FixtureBlockEntity extends BlockEntity {
	@Nullable
	private BlockPos consolePos;

	public FixtureBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.FIXTURE, pos, state);
	}

	public FixtureType type() {
		Block block = getBlockState().getBlock();
		if (block instanceof FixtureBlock fixture) return fixture.getFixtureType();
		if (block instanceof LedBarBlock) return FixtureType.LED_BAR;
		return FixtureType.SPOT;
	}

	@Nullable
	public ConsoleBlockEntity console(Level level) {
		if (consolePos == null) return null;
		if (level.getBlockEntity(consolePos) instanceof ConsoleBlockEntity console) return console;
		return null;
	}

	public static void tick(Level level, BlockPos pos, BlockState state, FixtureBlockEntity fixture) {
		if (level.isClientSide()) {
			fixture.clientTick(level, pos, state);
		} else {
			fixture.serverTick(level, pos, state);
		}
	}

	// ---------------- Server ----------------

	private void serverTick(Level level, BlockPos pos, BlockState state) {
		long time = level.getGameTime();

		// Alle 2 Sekunden Verbindung zum Pult prüfen
		if (time % 40 == Math.floorMod(pos.asLong(), 40)) {
			BlockPos nearest = ConsoleRegistry.findNearest(level, pos);
			boolean same = nearest == null ? consolePos == null : nearest.equals(consolePos);
			if (!same) {
				consolePos = nearest;
				setChanged();
			}
		}

		if (type() == FixtureType.LED_BAR && time % 2 == 0) {
			int wanted = ledColorState(level, pos, time);
			if (state.getValue(LedBarBlock.COLOR) != wanted) {
				level.setBlock(pos, state.setValue(LedBarBlock.COLOR, wanted), Block.UPDATE_CLIENTS);
			}
		}
	}

	/** 0 = aus, 1..8 = Farbe aus der Palette. */
	private int ledColorState(Level level, BlockPos pos, long time) {
		ConsoleBlockEntity console = console(level);
		if (console == null || !ShowMath.isOn(console, time)) return 0;

		if (console.getEffect() != 0) {
			// Chase: immer nur jede vierte Bar leuchtet, Lauflicht
			int step = Math.max(1, 12 - console.getSpeed());
			long chase = time / step + ShowMath.chasePhase(pos);
			if (Math.floorMod(chase, 4) != 0) return 0;
		}
		return ShowMath.colorIndexFor(console, pos, time) + 1;
	}

	// ---------------- Client ----------------

	private void clientTick(Level level, BlockPos pos, BlockState state) {
		// Strahlen und bewegliche Köpfe zeichnet der FixtureRenderer.
		// Hier entsteht nur der Nebel des Hazers.
		if (type() != FixtureType.HAZER) return;
		ConsoleBlockEntity console = console(level);
		if (console == null) return;

		int haze = console.getHaze();
		if (haze <= 0) return;
		RandomSource random = level.getRandom();
		if (random.nextInt(14) >= haze) return;

		Direction facing = state.getValue(FixtureBlock.FACING);
		double speed = 0.04 + random.nextDouble() * 0.05;
		double spread = 0.02;
		level.addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE,
				pos.getX() + 0.5 + facing.getStepX() * 0.55,
				pos.getY() + 0.3,
				pos.getZ() + 0.5 + facing.getStepZ() * 0.55,
				facing.getStepX() * speed + (random.nextDouble() - 0.5) * spread,
				0.0,
				facing.getStepZ() * speed + (random.nextDouble() - 0.5) * spread);
	}

	// ---------------- Speichern & Sync ----------------

	@Override
	public void setChanged() {
		super.setChanged();
		if (level == null) return;
		BlockState state = getBlockState();
		level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
	}

	@Override
	protected void saveAdditional(ValueOutput output) {
		output.putInt("linked", consolePos != null ? 1 : 0);
		if (consolePos != null) output.putLong("console", consolePos.asLong());
		super.saveAdditional(output);
	}

	@Override
	protected void loadAdditional(ValueInput input) {
		super.loadAdditional(input);
		consolePos = input.getIntOr("linked", 0) != 0 ? BlockPos.of(input.getLongOr("console", 0L)) : null;
	}

	@Override
	public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
		return saveWithoutMetadata(registries);
	}

	@Override
	public Packet<ClientGamePacketListener> getUpdatePacket() {
		return ClientboundBlockEntityDataPacket.create(this);
	}
}
