package ch.luca.eventtechnik.blockentity;

import org.jetbrains.annotations.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;

import ch.luca.eventtechnik.block.FixtureBlock;
import ch.luca.eventtechnik.block.FixtureType;
import ch.luca.eventtechnik.block.LedBarBlock;
import ch.luca.eventtechnik.registry.ModBlockEntities;
import ch.luca.eventtechnik.show.ConsoleRegistry;
import ch.luca.eventtechnik.show.ShowMath;

/**
 * Ein Gerät (Moving Head, Wash, Hazer, LED-Bar).
 * Server: verbindet sich mit dem nächsten Pult und schaltet LED-Bars.
 * Client: zeichnet Strahlen und Nebel als Partikel.
 */
public class FixtureBlockEntity extends BlockEntity {
	private static final double SPOT_LENGTH = 24.0;
	private static final double WASH_LENGTH = 14.0;

	@Nullable
	private BlockPos consolePos;

	public FixtureBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.FIXTURE, pos, state);
	}

	private FixtureType type() {
		Block block = getBlockState().getBlock();
		if (block instanceof FixtureBlock fixture) return fixture.getFixtureType();
		if (block instanceof LedBarBlock) return FixtureType.LED_BAR;
		return FixtureType.SPOT;
	}

	@Nullable
	private ConsoleBlockEntity console(Level level) {
		if (consolePos == null) return null;
		if (level.getBlockEntity(consolePos) instanceof ConsoleBlockEntity console) return console;
		return null;
	}

	public static void tick(Level level, BlockPos pos, BlockState state, FixtureBlockEntity fixture) {
		if (level.isClientSide()) {
			fixture.clientTick(level, pos, state);
		} else {
			fixture.serverTick(level, pos, state);
		}
	}

	// ---------------- Server ----------------

	private void serverTick(Level level, BlockPos pos, BlockState state) {
		long time = level.getGameTime();

		// Alle 2 Sekunden Verbindung zum Pult prüfen
		if (time % 40 == Math.floorMod(pos.asLong(), 40)) {
			BlockPos nearest = ConsoleRegistry.findNearest(level, pos);
			boolean same = nearest == null ? consolePos == null : nearest.equals(consolePos);
			if (!same) {
				consolePos = nearest;
				setChanged();
			}
		}

		if (type() == FixtureType.LED_BAR && time % 2 == 0) {
			int wanted = ledColorState(level, pos, time);
			if (state.getValue(LedBarBlock.COLOR) != wanted) {
				level.setBlock(pos, state.setValue(LedBarBlock.COLOR, wanted), Block.UPDATE_CLIENTS);
			}
		}
	}

	/** 0 = aus, 1..8 = Farbe aus der Palette. */
	private int ledColorState(Level level, BlockPos pos, long time) {
		ConsoleBlockEntity console = console(level);
		if (console == null || !ShowMath.isOn(console, time)) return 0;

		if (console.getEffect() != 0) {
			// Chase: immer nur jede vierte Bar leuchtet, Lauflicht
			int step = Math.max(1, 12 - console.getSpeed());
			long chase = time / step + ShowMath.chasePhase(pos);
			if (Math.floorMod(chase, 4) != 0) return 0;
		}
		return ShowMath.colorIndexFor(console, pos, time) + 1;
	}

	// ---------------- Client ----------------

	private void clientTick(Level level, BlockPos pos, BlockState state) {
		ConsoleBlockEntity console = console(level);
		if (console == null) return;

		long time = level.getGameTime();
		RandomSource random = level.getRandom();

		switch (type()) {
			case SPOT, WASH -> {
				if (!ShowMath.isOn(console, time)) return;
				boolean hanging = state.hasProperty(FixtureBlock.HANGING) && state.getValue(FixtureBlock.HANGING);
				Vec3 dir = ShowMath.beamDirection(console, pos, hanging, time);
				drawBeam(level, pos, dir, console, time, random, type() == FixtureType.WASH);
			}
			case HAZER -> drawHaze(level, pos, console, random);
			default -> { }
		}
	}

	private void drawBeam(Level level, BlockPos pos, Vec3 dir, ConsoleBlockEntity console, long time, RandomSource random, boolean wash) {
		int color = ShowMath.colorFor(console, pos, time);
		double dimmer = console.getDimmer() / 100.0;
		// Mehr Haze = dichterer, sichtbarerer Strahl
		double density = dimmer * (0.25 + console.getHaze() * 0.05);
		float scale = wash ? 2.2f : 0.9f;
		double length = wash ? WASH_LENGTH : SPOT_LENGTH;
		double step = wash ? 0.7 : 0.5;

		DustParticleOptions dust = new DustParticleOptions(color, scale);
		Vec3 start = Vec3.atCenterOf(pos).add(dir.scale(0.6));

		for (double d = 0; d < length; d += step) {
			Vec3 p = start.add(dir.scale(d));
			BlockPos bp = BlockPos.containing(p);
			if (!bp.equals(pos)) {
				BlockState hit = level.getBlockState(bp);
				if (!hit.isAir() && hit.canOcclude()) break; // Strahl endet an festen Blöcken
			}
			if (random.nextDouble() > density) continue;

			double spread = wash ? d * 0.12 : 0.03;
			level.addParticle(dust,
					p.x + (random.nextDouble() - 0.5) * spread,
					p.y + (random.nextDouble() - 0.5) * spread,
					p.z + (random.nextDouble() - 0.5) * spread,
					0, 0, 0);
		}
	}

	private void drawHaze(Level level, BlockPos pos, ConsoleBlockEntity console, RandomSource random) {
		int haze = console.getHaze();
		if (haze <= 0) return;
		if (random.nextInt(12) >= haze) return;

		double angle = random.nextDouble() * Math.PI * 2;
		double speed = 0.03 + random.nextDouble() * 0.04;
		level.addParticle(ParticleTypes.WHITE_SMOKE,
				pos.getX() + 0.5, pos.getY() + 0.6, pos.getZ() + 0.5,
				Math.cos(angle) * speed, 0.005, Math.sin(angle) * speed);
	}

	// ---------------- Speichern & Sync ----------------

	@Override
	public void setChanged() {
		super.setChanged();
		if (level == null) return;
		BlockState state = getBlockState();
		level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
	}

	@Override
	protected void saveAdditional(ValueOutput output) {
		output.putInt("linked", consolePos != null ? 1 : 0);
		if (consolePos != null) output.putLong("console", consolePos.asLong());
		super.saveAdditional(output);
	}

	@Override
	protected void loadAdditional(ValueInput input) {
		super.loadAdditional(input);
		consolePos = input.getIntOr("linked", 0) != 0 ? BlockPos.of(input.getLongOr("console", 0L)) : null;
	}

	@Override
	public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
		return saveWithoutMetadata(registries);
	}

	@Override
	public Packet<ClientGamePacketListener> getUpdatePacket() {
		return ClientboundBlockEntityDataPacket.create(this);
	}
}
