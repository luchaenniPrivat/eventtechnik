package ch.luca.eventtechnik.blockentity;

import org.jetbrains.annotations.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

import ch.luca.eventtechnik.block.FixtureBlock;
import ch.luca.eventtechnik.block.FixtureType;
import ch.luca.eventtechnik.block.LedBarBlock;
import ch.luca.eventtechnik.block.LedPanelBlock;
import ch.luca.eventtechnik.registry.ModBlockEntities;
import ch.luca.eventtechnik.show.ConsoleRegistry;
import ch.luca.eventtechnik.show.ShowMath;

/**
 * Ein Gerät (Moving Head, Wash, Hazer, LED-Bar, LED-Wand-Panel).
 * Server: verbindet sich mit dem nächsten Pult und schaltet LED-Bars.
 * Client: Nebel des Hazers (Strahlen, Köpfe und LED-Wand zeichnet der FixtureRenderer).
 */
public class FixtureBlockEntity extends BlockEntity {
	@Nullable
	private BlockPos consolePos;
	/** Gruppe 0..7 am Pult (angezeigt als 1..8). */
	private int group = 0;

	public FixtureBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.FIXTURE, pos, state);
	}

	public FixtureType type() {
		Block block = getBlockState().getBlock();
		if (block instanceof FixtureBlock fixture) return fixture.getFixtureType();
		if (block instanceof LedBarBlock) return FixtureType.LED_BAR;
		if (block instanceof LedPanelBlock) return FixtureType.LED_PANEL;
		return FixtureType.SPOT;
	}

	public int getGroup() {
		return group;
	}

	/** Nächste Gruppe (1 → 2 → … → 8 → 1). Gibt die neue Gruppe zurück. */
	public int cycleGroup() {
		group = (group + 1) % ConsoleBlockEntity.GROUPS;
		setChanged();
		return group;
	}

	@Nullable
	public ConsoleBlockEntity console(Level level) {
		if (consolePos == null) return null;
		if (level.getBlockEntity(consolePos) instanceof ConsoleBlockEntity console) return console;
		return null;
	}

	public static void tick(Level level, BlockPos pos, BlockState state, FixtureBlockEntity fixture) {
		if (level.isClientSide()) {
			fixture.clientTick(level, pos, state);
		} else {
			fixture.serverTick(level, pos, state);
		}
	}

	// ---------------- Server ----------------

	private void serverTick(Level level, BlockPos pos, BlockState state) {
		long time = level.getGameTime();

		// Alle 2 Sekunden Verbindung zum Pult prüfen
		if (time % 40 == Math.floorMod(pos.asLong(), 40)) {
			BlockPos nearest = ConsoleRegistry.findNearest(level, pos);
			boolean same = nearest == null ? consolePos == null : nearest.equals(consolePos);
			if (!same) {
				consolePos = nearest;
				setChanged();
			}
		}

		if (type() == FixtureType.LED_BAR && time % 2 == 0) {
			int wanted = ledColorState(level, pos, time);
			if (state.getValue(LedBarBlock.COLOR) != wanted) {
				level.setBlock(pos, state.setValue(LedBarBlock.COLOR, wanted), Block.UPDATE_CLIENTS);
			}
		}
	}

	/** 0 = aus, 1..8 = Farbe aus der Palette. */
	private int ledColorState(Level level, BlockPos pos, long time) {
		ConsoleBlockEntity console = console(level);
		if (console == null || !ShowMath.isOn(console, group, time)) return 0;

		if (console.getEffect(group) != 0) {
			// Chase: immer nur jede vierte Bar leuchtet, Lauflicht
			int step = Math.max(1, 12 - console.getSpeed());
			long chase = time / step + ShowMath.chasePhase(pos);
			if (Math.floorMod(chase, 4) != 0) return 0;
		}
		return ShowMath.colorIndexFor(console, group, pos, time) + 1;
	}

	// ---------------- Client ----------------

	private void clientTick(Level level, BlockPos pos, BlockState state) {
		if (type() != FixtureType.HAZER) return;
		ConsoleBlockEntity console = console(level);
		if (console == null) return;
		int haze = console.getHaze();
		if (haze <= 0) return;

		RandomSource random = level.getRandom();
		Direction facing = state.getValue(FixtureBlock.FACING);

		// 1) Ausstoss an der Düse: kräftiger, je mehr Haze
		if (random.nextInt(10) < haze) {
			double speed = 0.06 + random.nextDouble() * 0.06;
			level.addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE,
					pos.getX() + 0.5 + facing.getStepX() * 0.6,
					pos.getY() + 0.25,
					pos.getZ() + 0.5 + facing.getStepZ() * 0.6,
					facing.getStepX() * speed + (random.nextDouble() - 0.5) * 0.03,
					-0.02,
					facing.getStepZ() * speed + (random.nextDouble() - 0.5) * 0.03);
		}

		// 2) Flächiger Nebelteppich: verteilt sich im Raum vor dem Hazer.
		//    Je höher Haze, desto grösser die Fläche und desto dichter.
		double radius = 2 + haze * 1.4;
		int puffs = haze / 3 + (random.nextInt(3) < haze % 3 ? 1 : 0);
		for (int i = 0; i < puffs; i++) {
			double ang = random.nextDouble() * Math.PI * 2;
			double dist = Math.sqrt(random.nextDouble()) * radius;
			// Fläche liegt vor dem Hazer (in Blasrichtung verschoben)
			double cx = pos.getX() + 0.5 + facing.getStepX() * radius * 0.7 + Math.cos(ang) * dist;
			double cz = pos.getZ() + 0.5 + facing.getStepZ() * radius * 0.7 + Math.sin(ang) * dist;
			double cy = pos.getY() + 0.2 + random.nextDouble() * Mth.clamp(haze * 0.35, 0.5, 3.0);
			level.addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE, cx, cy, cz,
					(random.nextDouble() - 0.5) * 0.01, -0.04, (random.nextDouble() - 0.5) * 0.01);
		}
	}

	// ---------------- Speichern & Sync ----------------

	@Override
	public void setChanged() {
		super.setChanged();
		if (level == null) return;
		BlockState state = getBlockState();
		level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
	}

	@Override
	protected void saveAdditional(ValueOutput output) {
		output.putInt("linked", consolePos != null ? 1 : 0);
		if (consolePos != null) output.putLong("console", consolePos.asLong());
		output.putInt("group", group);
		super.saveAdditional(output);
	}

	@Override
	protected void loadAdditional(ValueInput input) {
		super.loadAdditional(input);
		consolePos = input.getIntOr("linked", 0) != 0 ? BlockPos.of(input.getLongOr("console", 0L)) : null;
		group = Mth.clamp(input.getIntOr("group", 0), 0, ConsoleBlockEntity.GROUPS - 1);
	}

	@Override
	public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
		return saveWithoutMetadata(registries);
	}

	@Override
	public Packet<ClientGamePacketListener> getUpdatePacket() {
		return ClientboundBlockEntityDataPacket.create(this);
	}
}
