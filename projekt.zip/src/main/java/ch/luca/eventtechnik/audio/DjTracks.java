package ch.luca.eventtechnik.audio;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

import ch.luca.eventtechnik.EventTechnik;

/**
 * Die eigenen Tracks des DJ-Pults. Jeder Track besteht aus zwei Spuren:
 * LOW (Kick + Bass) spielt nur aus Subwoofern, HIGH (Hats, Claps, Synths) nur aus PA-Tops.
 * Die Länge eines Loops ist eine ganze Zahl von Ticks, damit alle Lautsprecher im Takt bleiben.
 */
public final class DjTracks {
	private DjTracks() { }

	public static final String[] NAMES = {"Bierhübeli House", "Lyss Techno", "Nachtschicht", "Liquid DnB"};
	public static final String[] BPM = {"120", "133", "120", "171"};
	/** Ticks pro Schlag: 120 BPM = 10, 133 BPM = 9, 171 BPM = 7. */
	public static final int[] TICKS_PER_BEAT = {10, 9, 10, 7};
	/** Jeder Loop ist 8 Takte = 32 Schläge lang. */
	public static final int BEATS_PER_LOOP = 32;

	public static final SoundEvent[] LOW = new SoundEvent[NAMES.length];
	public static final SoundEvent[] HIGH = new SoundEvent[NAMES.length];

	public static int loopTicks(int track) {
		return TICKS_PER_BEAT[track] * BEATS_PER_LOOP;
	}

	public static void initialize() {
		for (int i = 0; i < NAMES.length; i++) {
			LOW[i] = register("dj.track" + (i + 1) + "_low");
			HIGH[i] = register("dj.track" + (i + 1) + "_high");
		}
	}

	private static SoundEvent register(String name) {
		Identifier id = EventTechnik.id(name);
		return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
	}
}
