package ch.luca.eventtechnik.block;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import ch.luca.eventtechnik.blockentity.FixtureBlockEntity;

/** Rechtsklick mit leerer Hand auf ein Gerät: nächste Pult-Gruppe. */
public final class GroupInteraction {
	private GroupInteraction() { }

	public static InteractionResult cycle(Level level, BlockPos pos, Player player) {
		// Mit einem Block in der Hand soll man normal weiterbauen können
		if (!player.getMainHandItem().isEmpty()) return InteractionResult.PASS;
		if (!player.getAbilities().mayBuild) return InteractionResult.PASS;
		if (!(level.getBlockEntity(pos) instanceof FixtureBlockEntity fixture)) return InteractionResult.PASS;

		if (!level.isClientSide()) {
			int group = fixture.cycleGroup();
			player.sendOverlayMessage(Component.literal("Gruppe " + (group + 1)));
		}
		return InteractionResult.SUCCESS;
	}
}
