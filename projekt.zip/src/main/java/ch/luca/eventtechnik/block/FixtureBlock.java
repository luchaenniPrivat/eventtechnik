package ch.luca.eventtechnik.block;

import org.jetbrains.annotations.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;

import ch.luca.eventtechnik.blockentity.FixtureBlockEntity;
import ch.luca.eventtechnik.registry.ModBlockEntities;

/**
 * Moving Head (Spot/Wash) oder Hazer.
 * Unter eine Decke/Truss gesetzt hängt das Gerät kopfüber und leuchtet nach unten.
 */
public class FixtureBlock extends BaseEntityBlock {
	public static final BooleanProperty HANGING = BooleanProperty.create("hanging");

	private final FixtureType fixtureType;

	public FixtureBlock(Properties properties, FixtureType fixtureType) {
		super(properties);
		this.fixtureType = fixtureType;
		registerDefaultState(defaultBlockState().setValue(HANGING, false));
	}

	public FixtureType getFixtureType() {
		return fixtureType;
	}


	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(HANGING);
	}

	@Nullable
	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		boolean hanging = fixtureType != FixtureType.HAZER && context.getClickedFace() == Direction.DOWN;
		return defaultBlockState().setValue(HANGING, hanging);
	}

	@Override
	protected RenderShape getRenderShape(BlockState state) {
		return RenderShape.MODEL;
	}

	@Nullable
	@Override
	public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
		return new FixtureBlockEntity(pos, state);
	}

	@Nullable
	@Override
	public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
		return createTickerHelper(type, ModBlockEntities.FIXTURE, FixtureBlockEntity::tick);
	}
}
