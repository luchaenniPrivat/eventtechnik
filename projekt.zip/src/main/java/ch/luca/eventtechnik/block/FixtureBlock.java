package ch.luca.eventtechnik.block;

import org.jetbrains.annotations.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.EnumProperty;

import ch.luca.eventtechnik.blockentity.FixtureBlockEntity;
import ch.luca.eventtechnik.registry.ModBlockEntities;

/**
 * Moving Head (Spot/Wash) oder Hazer.
 * Wie ein Kolben: Das Gerät zeigt beim Setzen in deine Richtung.
 * Schaust du nach unten, zeigt es nach oben; setzt du es unter eine Truss, hängt es kopfüber.
 */
public class FixtureBlock extends BaseEntityBlock {
	public static final EnumProperty<Direction> FACING = BlockStateProperties.FACING;

	private final FixtureType fixtureType;

	public FixtureBlock(Properties properties, FixtureType fixtureType) {
		super(properties);
		this.fixtureType = fixtureType;
		registerDefaultState(defaultBlockState().setValue(FACING, Direction.UP));
	}

	public FixtureType getFixtureType() {
		return fixtureType;
	}


	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Nullable
	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		Direction facing = fixtureType == FixtureType.HAZER
				? context.getHorizontalDirection().getOpposite()
				: context.getNearestLookingDirection().getOpposite();
		return defaultBlockState().setValue(FACING, facing);
	}

	@Override
	protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
		return GroupInteraction.cycle(level, pos, player);
	}

	// Struktur-Generierung dreht und spiegelt Bauten: Ausrichtung muss mitdrehen
	@Override
	protected BlockState rotate(BlockState state, Rotation rotation) {
		return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
	}

	@Override
	protected BlockState mirror(BlockState state, Mirror mirror) {
		return state.rotate(mirror.getRotation(state.getValue(FACING)));
	}

	@Override
	protected RenderShape getRenderShape(BlockState state) {
		return RenderShape.MODEL;
	}

	@Nullable
	@Override
	public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
		return new FixtureBlockEntity(pos, state);
	}

	@Nullable
	@Override
	public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
		return createTickerHelper(type, ModBlockEntities.FIXTURE, FixtureBlockEntity::tick);
	}
}
