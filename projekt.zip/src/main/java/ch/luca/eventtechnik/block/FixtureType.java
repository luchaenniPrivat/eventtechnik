package ch.luca.eventtechnik.block;

public enum FixtureType {
	/** Moving Head Spot/Beam: schmaler, langer Strahl. */
	SPOT,
	/** Moving Head Wash: breiter, weicher Lichtkegel. */
	WASH,
	/** Hazer: verteilt Nebel, macht Strahlen dichter. */
	HAZER,
	/** LED-Bar: wechselt Farbe, Chases. */
	LED_BAR,
	/** LED-Wand-Panel: nebeneinander gesetzt ergibt es eine grosse LED-Wand. */
	LED_PANEL,
	/** Laser: mehrere dünne Strahlen im Fächer. */
	LASER,
	/** LED-Dancefloor: leuchtender Boden mit Mustern. */
	LED_FLOOR;

	/** Seite am Pult (0..5), oder -1 wenn das Gerät keine eigene Seite hat (Hazer). */
	public int page() {
		return switch (this) {
			case SPOT -> 0;
			case WASH -> 1;
			case LED_BAR -> 2;
			case LED_PANEL -> 3;
			case LASER -> 4;
			case LED_FLOOR -> 5;
			default -> -1;
		};
	}
}
