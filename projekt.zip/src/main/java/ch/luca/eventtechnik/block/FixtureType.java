package ch.luca.eventtechnik.block;

public enum FixtureType {
	/** Moving Head Spot/Beam: schmaler, langer Strahl. */
	SPOT,
	/** Moving Head Wash: breiter, weicher Lichtkegel. */
	WASH,
	/** Hazer: verteilt Nebel, macht Strahlen dichter. */
	HAZER,
	/** LED-Bar: wechselt Farbe, Chases. */
	LED_BAR,
	/** LED-Wand-Panel: nebeneinander gesetzt ergibt es eine grosse LED-Wand. */
	LED_PANEL
}
