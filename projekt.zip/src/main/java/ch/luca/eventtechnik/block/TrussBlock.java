package ch.luca.eventtechnik.block;

import java.util.Map;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.ScheduledTickAccess;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;

/**
 * Truss, die sich mit Nachbar-Truss verbindet: An verbundenen Seiten fallen die Querstreben weg,
 * so entstehen durchgehende Traversen und Türme.
 */
public class TrussBlock extends Block {
	public static final BooleanProperty NORTH = BlockStateProperties.NORTH;
	public static final BooleanProperty EAST = BlockStateProperties.EAST;
	public static final BooleanProperty SOUTH = BlockStateProperties.SOUTH;
	public static final BooleanProperty WEST = BlockStateProperties.WEST;
	public static final BooleanProperty UP = BlockStateProperties.UP;
	public static final BooleanProperty DOWN = BlockStateProperties.DOWN;

	private static final Map<Direction, BooleanProperty> BY_DIR = Map.of(
			Direction.NORTH, NORTH, Direction.EAST, EAST, Direction.SOUTH, SOUTH,
			Direction.WEST, WEST, Direction.UP, UP, Direction.DOWN, DOWN);

	public TrussBlock(Properties properties) {
		super(properties);
		BlockState s = defaultBlockState();
		for (BooleanProperty p : BY_DIR.values()) s = s.setValue(p, false);
		registerDefaultState(s);
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(NORTH, EAST, SOUTH, WEST, UP, DOWN);
	}

	private boolean connects(BlockState neighbor) {
		return neighbor.getBlock() instanceof TrussBlock;
	}

	private BlockState withConnections(BlockState state, BlockGetter level, BlockPos pos) {
		for (Direction d : Direction.values()) {
			state = state.setValue(BY_DIR.get(d), connects(level.getBlockState(pos.relative(d))));
		}
		return state;
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return withConnections(defaultBlockState(), context.getLevel(), context.getClickedPos());
	}

	@Override
	protected BlockState updateShape(BlockState state, LevelReader level, ScheduledTickAccess ticks, BlockPos pos,
			Direction direction, BlockPos neighborPos, BlockState neighborState, RandomSource random) {
		return state.setValue(BY_DIR.get(direction), connects(neighborState));
	}

	@Override
	protected BlockState rotate(BlockState state, Rotation rotation) {
		BlockState out = state;
		for (Direction d : Direction.Plane.HORIZONTAL) {
			out = out.setValue(BY_DIR.get(rotation.rotate(d)), state.getValue(BY_DIR.get(d)));
		}
		return out;
	}

	@Override
	protected BlockState mirror(BlockState state, Mirror mirror) {
		BlockState out = state;
		for (Direction d : Direction.Plane.HORIZONTAL) {
			out = out.setValue(BY_DIR.get(mirror.mirror(d)), state.getValue(BY_DIR.get(d)));
		}
		return out;
	}
}
