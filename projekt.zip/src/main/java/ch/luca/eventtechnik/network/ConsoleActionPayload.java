package ch.luca.eventtechnik.network;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import ch.luca.eventtechnik.EventTechnik;

/** Client → Server: ein Knopf am Lichtpult wurde gedrückt. */
public record ConsoleActionPayload(BlockPos pos, int action, int group, int value) implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<ConsoleActionPayload> TYPE =
			new CustomPacketPayload.Type<>(EventTechnik.id("console_action"));

	public static final StreamCodec<RegistryFriendlyByteBuf, ConsoleActionPayload> CODEC = StreamCodec.composite(
			BlockPos.STREAM_CODEC, ConsoleActionPayload::pos,
			ByteBufCodecs.VAR_INT, ConsoleActionPayload::action,
			ByteBufCodecs.VAR_INT, ConsoleActionPayload::group,
			ByteBufCodecs.VAR_INT, ConsoleActionPayload::value,
			ConsoleActionPayload::new);

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
