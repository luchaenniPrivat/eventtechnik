package ch.luca.eventtechnik.network;

import java.util.UUID;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

import ch.luca.eventtechnik.blockentity.ConsoleBlockEntity;
import ch.luca.eventtechnik.blockentity.DjBlockEntity;

public final class ModNetworking {
	private ModNetworking() { }

	/** Max. Abstand Spieler ↔ Pult (8 Blöcke), damit niemand aus der Ferne fremde Pulte steuert. */
	private static final double MAX_DIST_SQR = 8.0 * 8.0;

	public static void initialize() {
		PayloadTypeRegistry.serverboundPlay().register(ConsoleActionPayload.TYPE, ConsoleActionPayload.CODEC);
		PayloadTypeRegistry.serverboundPlay().register(DjActionPayload.TYPE, DjActionPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(DjActionPayload.TYPE, (payload, context) -> {
			var player = context.player();
			if (player.distanceToSqr(Vec3.atCenterOf(payload.pos())) > MAX_DIST_SQR) return;
			if (!player.getAbilities().mayBuild) return;
			if (player.level().getBlockEntity(payload.pos()) instanceof DjBlockEntity dj) {
				dj.applyAction(payload.action(), payload.value());
			}
		});

		ServerPlayNetworking.registerGlobalReceiver(ConsoleActionPayload.TYPE, (payload, context) -> {
			var player = context.player();
			if (player.distanceToSqr(Vec3.atCenterOf(payload.pos())) > MAX_DIST_SQR) return;
			if (!player.getAbilities().mayBuild) return;

			if (player.level().getBlockEntity(payload.pos()) instanceof ConsoleBlockEntity console) {
				UUID follow = null;
				if (payload.action() == ConsoleBlockEntity.ACTION_FOLLOW && payload.value() >= 0
						&& player.level().getEntity(payload.value()) instanceof Player target) {
					follow = target.getUUID();
				}
				console.applyAction(payload.action(), payload.group(), payload.value(), follow);
			}
		});
	}
}
