package ch.luca.eventtechnik.network;

import net.minecraft.world.phys.Vec3;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

import ch.luca.eventtechnik.blockentity.ConsoleBlockEntity;

public final class ModNetworking {
	private ModNetworking() { }

	/** Max. Abstand Spieler ↔ Pult (8 Blöcke), damit niemand aus der Ferne fremde Pulte steuert. */
	private static final double MAX_DIST_SQR = 8.0 * 8.0;

	public static void initialize() {
		PayloadTypeRegistry.serverboundPlay().register(ConsoleActionPayload.TYPE, ConsoleActionPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(ConsoleActionPayload.TYPE, (payload, context) -> {
			var player = context.player();
			if (player.distanceToSqr(Vec3.atCenterOf(payload.pos())) > MAX_DIST_SQR) return;
			if (!player.getAbilities().mayBuild) return;

			if (player.level().getBlockEntity(payload.pos()) instanceof ConsoleBlockEntity console) {
				console.applyAction(payload.action(), payload.value());
			}
		});
	}
}
