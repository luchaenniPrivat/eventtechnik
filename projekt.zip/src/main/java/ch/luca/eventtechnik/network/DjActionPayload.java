package ch.luca.eventtechnik.network;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import ch.luca.eventtechnik.EventTechnik;

/** Client → Server: ein Knopf am DJ-Pult wurde gedrückt. */
public record DjActionPayload(BlockPos pos, int action, int value) implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<DjActionPayload> TYPE =
			new CustomPacketPayload.Type<>(EventTechnik.id("dj_action"));

	public static final StreamCodec<RegistryFriendlyByteBuf, DjActionPayload> CODEC = StreamCodec.composite(
			BlockPos.STREAM_CODEC, DjActionPayload::pos,
			ByteBufCodecs.VAR_INT, DjActionPayload::action,
			ByteBufCodecs.VAR_INT, DjActionPayload::value,
			DjActionPayload::new);

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
