package ch.luca.eventtechnik.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.level.Level;

import ch.luca.eventtechnik.audio.DjTracks;
import ch.luca.eventtechnik.blockentity.DjBlockEntity;
import ch.luca.eventtechnik.blockentity.SpeakerBlockEntity;

/**
 * Startet in jedem Lautsprecher am Anfang jedes Loops die passende Spur.
 * Weil alle Lautsprecher auf denselben Tick-Raster starten, laufen sie im Gleichtakt.
 */
public final class SpeakerAudio {
	private SpeakerAudio() { }

	public static void tick(SpeakerBlockEntity speaker) {
		Level level = speaker.getLevel();
		if (level == null) return;
		DjBlockEntity dj = speaker.dj(level);
		if (dj == null || !dj.isPlaying() || dj.getVolume() <= 0) return;

		long now = level.getGameTime();
		if (dj.loopPhase(now) != 0) return;

		int track = dj.currentTrack();
		var event = speaker.isSubwoofer() ? DjTracks.LOW[track] : DjTracks.HIGH[track];
		float volume = dj.getVolume() / 10f * 2.0f;
		Minecraft.getInstance().getSoundManager().play(new SpeakerSound(event, speaker, track, volume));
	}
}
