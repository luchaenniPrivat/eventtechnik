package ch.luca.eventtechnik.client;

import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;

import ch.luca.eventtechnik.blockentity.DjBlockEntity;
import ch.luca.eventtechnik.blockentity.SpeakerBlockEntity;

/** Ein Loop-Durchgang einer Spur aus einem Lautsprecher. Stoppt, wenn der DJ stoppt oder den Track wechselt. */
public class SpeakerSound extends AbstractTickableSoundInstance {
	private final SpeakerBlockEntity speaker;
	private final int track;

	public SpeakerSound(SoundEvent event, SpeakerBlockEntity speaker, int track, float volume) {
		super(event, SoundSource.RECORDS, SoundInstance.createUnseededRandom());
		this.speaker = speaker;
		this.track = track;
		this.looping = false;
		this.delay = 0;
		this.volume = volume;
		this.pitch = 1.0f;
		this.x = speaker.getBlockPos().getX() + 0.5;
		this.y = speaker.getBlockPos().getY() + 0.5;
		this.z = speaker.getBlockPos().getZ() + 0.5;
	}

	@Override
	public void tick() {
		if (speaker.isRemoved() || speaker.getLevel() == null) {
			stop();
			return;
		}
		DjBlockEntity dj = speaker.dj(speaker.getLevel());
		if (dj == null || !dj.isPlaying() || dj.currentTrack() != track) {
			stop();
		}
	}
}
