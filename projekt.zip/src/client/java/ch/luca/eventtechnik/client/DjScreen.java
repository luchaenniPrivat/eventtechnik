package ch.luca.eventtechnik.client;

import java.util.ArrayList;
import java.util.List;

import org.jetbrains.annotations.Nullable;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

import ch.luca.eventtechnik.audio.DjTracks;
import ch.luca.eventtechnik.blockentity.DjBlockEntity;
import ch.luca.eventtechnik.network.DjActionPayload;

/** GUI des DJ-Pults: Track wählen, Play/Stop, Lautstärke, Auto. */
public class DjScreen extends Screen {
	private static final int PANEL_W = 260;

	private final BlockPos pos;
	private final List<Button> trackBtns = new ArrayList<>();
	private Button playBtn;
	private Button autoBtn;
	private int left;
	private int top;

	public DjScreen(BlockPos pos) {
		super(Component.translatable("screen.eventtechnik.dj"));
		this.pos = pos;
	}

	@Nullable
	private DjBlockEntity dj() {
		if (minecraft == null || minecraft.level == null) return null;
		return minecraft.level.getBlockEntity(pos) instanceof DjBlockEntity d ? d : null;
	}

	private void send(int action, int value) {
		ClientPlayNetworking.send(new DjActionPayload(pos, action, value));
	}

	@Override
	protected void init() {
		trackBtns.clear();
		left = width / 2 - PANEL_W / 2;
		top = height / 2 - 70;
		int y = top;
		for (int i = 0; i < DjTracks.NAMES.length; i++) {
			final int t = i;
			trackBtns.add(addRenderableWidget(Button.builder(Component.literal(""), b -> send(DjBlockEntity.ACTION_TRACK, t))
					.bounds(left, y + i * 22, PANEL_W, 20).build()));
		}
		y += DjTracks.NAMES.length * 22 + 8;
		playBtn = addRenderableWidget(Button.builder(Component.literal(""), b -> {
			DjBlockEntity d = dj();
			if (d != null) send(DjBlockEntity.ACTION_PLAY, d.isPlayingSwitch() ? 0 : 1);
		}).bounds(left, y, 100, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Leiser"), b -> {
			DjBlockEntity d = dj();
			if (d != null) send(DjBlockEntity.ACTION_VOLUME, d.getVolume() - 1);
		}).bounds(left + 104, y, 50, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Lauter"), b -> {
			DjBlockEntity d = dj();
			if (d != null) send(DjBlockEntity.ACTION_VOLUME, d.getVolume() + 1);
		}).bounds(left + 158, y, 50, 20).build());
		autoBtn = addRenderableWidget(Button.builder(Component.literal(""), b -> {
			DjBlockEntity d = dj();
			if (d != null) send(DjBlockEntity.ACTION_AUTO, d.isAuto() ? 0 : 1);
		}).bounds(left + 212, y, 48, 20).build());
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		DjBlockEntity d = dj();
		if (d == null) {
			onClose();
			return;
		}
		for (int i = 0; i < trackBtns.size(); i++) {
			String label = DjTracks.NAMES[i] + "  (" + DjTracks.BPM[i] + " BPM)";
			trackBtns.get(i).setMessage(Component.literal(i == d.getTrack() ? "§a> " + label : label));
		}
		playBtn.setMessage(Component.literal(d.isPlayingSwitch() ? "§a■ Stop" : "▶ Play"));
		autoBtn.setMessage(Component.literal(d.isAuto() ? "§bAuto" : "Auto"));

		super.extractRenderState(graphics, mouseX, mouseY, delta);
		graphics.text(font, "DJ-PULT  –  Lautstärke " + d.getVolume() + "/10", left, top - 24, 0xFFFFD200, true);
		graphics.text(font, "§7Tops spielen die Höhen, Subwoofer den Bass.", left, top - 12, 0xFFAAAAAA, false);
		graphics.text(font, "§7Neue Lautsprecher steigen am Loop-Anfang ein.", left, top + DjTracks.NAMES.length * 22 + 34, 0xFFAAAAAA, false);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
