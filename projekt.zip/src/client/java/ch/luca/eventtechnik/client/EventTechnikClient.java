package ch.luca.eventtechnik.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderers;

import net.fabricmc.api.ClientModInitializer;

import ch.luca.eventtechnik.EventTechnik;
import ch.luca.eventtechnik.registry.ModBlockEntities;

public class EventTechnikClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		BlockEntityRenderers.register(ModBlockEntities.FIXTURE, FixtureRenderer::new);
		EventTechnik.openConsoleScreen = pos -> Minecraft.getInstance().gui.setScreen(new ConsoleScreen(pos));
	}
}
