package ch.luca.eventtechnik.client;

import net.minecraft.client.Minecraft;

import net.fabricmc.api.ClientModInitializer;

import ch.luca.eventtechnik.EventTechnik;

public class EventTechnikClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		EventTechnik.openConsoleScreen = pos -> Minecraft.getInstance().gui.setScreen(new ConsoleScreen(pos));
	}
}
