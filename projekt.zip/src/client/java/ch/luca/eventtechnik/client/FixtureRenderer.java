package ch.luca.eventtechnik.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import ch.luca.eventtechnik.EventTechnik;
import ch.luca.eventtechnik.block.FixtureBlock;
import ch.luca.eventtechnik.block.FixtureType;
import ch.luca.eventtechnik.block.LedPanelBlock;
import ch.luca.eventtechnik.blockentity.ConsoleBlockEntity;
import ch.luca.eventtechnik.blockentity.FixtureBlockEntity;
import ch.luca.eventtechnik.show.ShowMath;

/**
 * Zeichnet Moving Heads (Bügel, Kopf, Lichtkegel) und LED-Wand-Panels.
 * Koordinaten: Ursprung in der Blockmitte, +Y zeigt in die Montagerichtung (FACING).
 */
public class FixtureRenderer implements BlockEntityRenderer<FixtureBlockEntity, FixtureRenderState> {
	private static final int SEGMENTS = 16;
	private static final float SPOT_MAX = 32f;
	private static final float WASH_MAX = 16f;
	/** Höhe des Drehpunkts (Tilt-Achse) über der Blockmitte. */
	private static final float PIVOT = 0.0625f;
	/** Abstand Drehpunkt → Linse. */
	private static final float LENS = 0.3125f;
	/** Volle Helligkeit (Block- und Himmelslicht 15). */
	private static final int FULL_BRIGHT = 0x00F000F0;

	private static final Identifier BODY_TEX = EventTechnik.id("textures/block/fixture_body.png");
	private static final Identifier WHITE_TEX = EventTechnik.id("textures/block/led_white.png");

	public FixtureRenderer(BlockEntityRendererProvider.Context context) {
	}

	@Override
	public FixtureRenderState createRenderState() {
		return new FixtureRenderState();
	}

	@Override
	public void extractRenderState(FixtureBlockEntity fixture, FixtureRenderState state, float partialTick, Vec3 cameraPos,
			@Nullable ModelFeatureRenderer.CrumblingOverlay crumblingOverlay) {
		BlockEntityRenderer.super.extractRenderState(fixture, state, partialTick, cameraPos, crumblingOverlay);

		FixtureType type = fixture.type();
		state.movingHead = type == FixtureType.SPOT || type == FixtureType.WASH;
		state.panel = type == FixtureType.LED_PANEL;
		state.on = false;
		if (!state.movingHead && !state.panel) return;

		Level level = fixture.getLevel();
		if (level == null) return;
		BlockState blockState = fixture.getBlockState();
		BlockPos pos = fixture.getBlockPos();
		ConsoleBlockEntity console = fixture.console(level);
		int group = fixture.getGroup();
		double time = level.getGameTime() + partialTick;

		if (state.panel) {
			state.facing = blockState.hasProperty(LedPanelBlock.FACING) ? blockState.getValue(LedPanelBlock.FACING) : Direction.NORTH;
			extractPanel(state, pos, console, group, time);
			return;
		}

		state.wash = type == FixtureType.WASH;
		state.facing = blockState.hasProperty(FixtureBlock.FACING) ? blockState.getValue(FixtureBlock.FACING) : Direction.UP;

		if (console == null) {
			state.pan = 0;
			state.tilt = 0;
			return;
		}

		float[] pt = ShowMath.panTilt(console, group, pos, time);
		state.pan = pt[0];
		state.tilt = pt[1];

		long tick = level.getGameTime();
		state.on = ShowMath.isOn(console, group, tick);
		if (!state.on) return;

		state.rgb = ShowMath.colorFor(console, group, pos, tick);
		float dimmer = console.getDimmer(group) / 100f;
		float haze = console.getHaze() / 10f;
		state.intensity = dimmer * (0.25f + 0.75f * haze);
		state.beamLength = traceBeam(level, pos, state);
	}

	/** Berechnet die Pixel eines Panels aus Weltkoordinaten, damit benachbarte Panels ein Bild ergeben. */
	private static void extractPanel(FixtureRenderState state, BlockPos pos, @Nullable ConsoleBlockEntity console, int group, double time) {
		int res = FixtureRenderState.PANEL_RES;
		if (console == null) {
			java.util.Arrays.fill(state.pixels, -1);
			return;
		}
		state.panelBrightness = console.getDimmer(group) / 100f;
		Quaternionf q = new Quaternionf(state.facing.getRotation());
		boolean alongX = state.facing.getAxis() == Direction.Axis.Z;
		float cell = 1f / res;
		Vector3f w = new Vector3f();

		for (int row = 0; row < res; row++) {
			for (int col = 0; col < res; col++) {
				// Pixelmitte im lokalen Raster → Weltposition → durchgehende Wand-Koordinate
				w.set(-0.5f + (col + 0.5f) * cell, -0.37f, 0.5f - (row + 0.5f) * cell);
				q.transform(w);
				double wx = pos.getX() + 0.5 + w.x;
				double wy = pos.getY() + 0.5 + w.y;
				double wz = pos.getZ() + 0.5 + w.z;
				int u = (int) Math.floor((alongX ? wx : wz) * res);
				int v = (int) Math.floor(wy * res);
				state.pixels[row * res + col] = ShowMath.ledWallPixel(console, group, u, v, time);
			}
		}
	}

	/** Wie weit kommt der Strahl, bis er auf einen festen Block trifft? */
	private static float traceBeam(Level level, BlockPos pos, FixtureRenderState state) {
		Quaternionf q = new Quaternionf(state.facing.getRotation());
		Vector3f up = q.transform(new Vector3f(0, 1, 0), new Vector3f());
		Vector3f dir = new Quaternionf(q).rotateY(state.pan).rotateX(state.tilt).transform(new Vector3f(0, 1, 0));

		Vec3 start = Vec3.atCenterOf(pos)
				.add(up.x * PIVOT, up.y * PIVOT, up.z * PIVOT)
				.add(dir.x * LENS, dir.y * LENS, dir.z * LENS);
		float max = state.wash ? WASH_MAX : SPOT_MAX;

		for (float d = 0; d < max; d += 0.25f) {
			BlockPos bp = BlockPos.containing(start.x + dir.x * d, start.y + dir.y * d, start.z + dir.z * d);
			if (bp.equals(pos)) continue;
			BlockState hit = level.getBlockState(bp);
			if (!hit.isAir() && hit.canOcclude()) return d;
		}
		return max;
	}

	@Override
	public void submit(FixtureRenderState state, PoseStack poseStack, SubmitNodeCollector collector, CameraRenderState cameraState) {
		if (state.panel) {
			submitPanel(state, poseStack, collector);
		} else if (state.movingHead) {
			submitHead(state, poseStack, collector);
		}
	}

	// ---------------- LED-Wand ----------------

	private static void submitPanel(FixtureRenderState state, PoseStack poseStack, SubmitNodeCollector collector) {
		poseStack.pushPose();
		poseStack.translate(0.5f, 0.5f, 0.5f);
		poseStack.mulPose(new Matrix4f().rotation(state.facing.getRotation()));
		final int res = FixtureRenderState.PANEL_RES;
		final float bright = 0.35f + 0.65f * state.panelBrightness;
		final int[] pixels = state.pixels.clone();

		RenderType type = RenderTypes.entitySolid(WHITE_TEX);
		collector.submitCustomGeometry(poseStack, type, (pose, vc) -> {
			float cell = 1f / res;
			float gap = 0.012f;
			float y = -0.37f;
			for (int row = 0; row < res; row++) {
				for (int col = 0; col < res; col++) {
					int rgb = pixels[row * res + col];
					int color = rgb < 0 ? 0xFF0C0C0E : (0xFF000000 | scale(rgb, bright));
					// lokale Achsen: x = waagrecht über das Panel, z = senkrecht (Weltrichtung "oben" ist lokal -Z)
					float x0 = -0.5f + col * cell + gap, x1 = -0.5f + (col + 1) * cell - gap;
					float z1 = 0.5f - row * cell - gap, z0 = 0.5f - (row + 1) * cell + gap;
					quadUp(pose, vc, x0, y, z0, x1, z1, color, FULL_BRIGHT);
				}
			}
		});
		poseStack.popPose();
	}

	private static int scale(int rgb, float f) {
		int r = (int) (((rgb >> 16) & 0xFF) * f);
		int g = (int) (((rgb >> 8) & 0xFF) * f);
		int b = (int) ((rgb & 0xFF) * f);
		return (r << 16) | (g << 8) | b;
	}

	// ---------------- Moving Head ----------------

	private static void submitHead(FixtureRenderState state, PoseStack poseStack, SubmitNodeCollector collector) {
		final int light = state.lightCoords;
		RenderType body = RenderTypes.entitySolid(BODY_TEX);

		poseStack.pushPose();
		poseStack.translate(0.5f, 0.5f, 0.5f);
		poseStack.mulPose(new Matrix4f().rotation(state.facing.getRotation()));

		// Bügel: dreht sich mit Pan
		poseStack.mulPose(new Matrix4f().rotation(Axis.YP.rotation(state.pan)));
		collector.submitCustomGeometry(poseStack, body, (pose, vc) -> {
			box(pose, vc, -0.25f, -0.3125f, -0.25f, 0.25f, -0.25f, 0.25f, light);       // Drehteller
			box(pose, vc, -0.375f, -0.25f, -0.0625f, -0.3125f, 0.1875f, 0.0625f, light); // Arm links
			box(pose, vc, 0.3125f, -0.25f, -0.0625f, 0.375f, 0.1875f, 0.0625f, light);   // Arm rechts
		});

		// Kopf: kippt mit Tilt um die Achse zwischen den Armen
		poseStack.translate(0f, PIVOT, 0f);
		poseStack.mulPose(new Matrix4f().rotation(Axis.XP.rotation(state.tilt)));
		collector.submitCustomGeometry(poseStack, body, (pose, vc) ->
				box(pose, vc, -0.28f, -0.22f, -0.28f, 0.28f, LENS, 0.28f, light));

		final int lensColor = state.on ? (0xFF000000 | state.rgb) : 0xFF3A3A42;
		final float lensR = state.wash ? 0.24f : 0.17f;
		collector.submitCustomGeometry(poseStack, RenderTypes.entitySolid(WHITE_TEX), (pose, vc) ->
				quadUp(pose, vc, -lensR, LENS + 0.002f, -lensR, lensR, lensR, lensColor, state.on ? FULL_BRIGHT : light));

		// Lichtkegel
		if (state.on && state.intensity > 0.01f) {
			final float len = state.beamLength;
			final float r0 = state.wash ? 0.22f : 0.1f;
			final float spread = state.wash ? 0.2f : 0.03f;
			final float alphaCore = (state.wash ? 0.32f : 0.55f) * state.intensity;
			final float alphaHalo = alphaCore * 0.3f;
			final int rgb = state.rgb;
			collector.submitCustomGeometry(poseStack, RenderTypes.debugFilledBox(), (pose, vc) -> {
				cone(pose, vc, LENS + 0.004f, len, r0, r0 + len * spread, rgb, alphaCore);
				cone(pose, vc, LENS + 0.004f, len, r0 * 1.8f, (r0 + len * spread) * 2.2f, rgb, alphaHalo);
			});
		}

		poseStack.popPose();
	}

	// ---------------- Geometrie ----------------

	private static int argb(float a, int rgb) {
		int ai = Math.max(0, Math.min(255, (int) (a * 255)));
		return (ai << 24) | (rgb & 0xFFFFFF);
	}

	/** Kegelmantel entlang +Y. Vorne hell, hinten durchsichtig. Beidseitig. */
	private static void cone(PoseStack.Pose pose, VertexConsumer vc, float y0, float len, float r0, float r1, int rgb, float alpha) {
		int cStart = argb(alpha, rgb);
		int cEnd = argb(0f, rgb);
		float y1 = y0 + len;
		for (int i = 0; i < SEGMENTS; i++) {
			double a1 = Math.PI * 2 * i / SEGMENTS;
			double a2 = Math.PI * 2 * (i + 1) / SEGMENTS;
			float c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
			float c2 = (float) Math.cos(a2), s2 = (float) Math.sin(a2);

			vc.addVertex(pose, c1 * r0, y0, s1 * r0).setColor(cStart);
			vc.addVertex(pose, c1 * r1, y1, s1 * r1).setColor(cEnd);
			vc.addVertex(pose, c2 * r1, y1, s2 * r1).setColor(cEnd);
			vc.addVertex(pose, c2 * r0, y0, s2 * r0).setColor(cStart);

			vc.addVertex(pose, c2 * r0, y0, s2 * r0).setColor(cStart);
			vc.addVertex(pose, c2 * r1, y1, s2 * r1).setColor(cEnd);
			vc.addVertex(pose, c1 * r1, y1, s1 * r1).setColor(cEnd);
			vc.addVertex(pose, c1 * r0, y0, s1 * r0).setColor(cStart);
		}
	}

	/** Ein Eckpunkt im Entity-Format (Position, Farbe, Textur, Overlay, Licht, Normale). */
	private static void v(PoseStack.Pose p, VertexConsumer vc, float x, float y, float z, int color, float u, float w,
			int light, float nx, float ny, float nz) {
		vc.addVertex(p, x, y, z).setColor(color).setUv(u, w).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(p, nx, ny, nz);
	}

	/** Blickdichter Gehäuse-Quader mit Textur. */
	private static void box(PoseStack.Pose p, VertexConsumer vc, float x0, float y0, float z0, float x1, float y1, float z1, int light) {
		int c = 0xFFFFFFFF;
		// unten
		v(p, vc, x0, y0, z1, c, 0, 1, light, 0, -1, 0); v(p, vc, x0, y0, z0, c, 0, 0, light, 0, -1, 0);
		v(p, vc, x1, y0, z0, c, 1, 0, light, 0, -1, 0); v(p, vc, x1, y0, z1, c, 1, 1, light, 0, -1, 0);
		// oben
		v(p, vc, x0, y1, z0, c, 0, 0, light, 0, 1, 0); v(p, vc, x0, y1, z1, c, 0, 1, light, 0, 1, 0);
		v(p, vc, x1, y1, z1, c, 1, 1, light, 0, 1, 0); v(p, vc, x1, y1, z0, c, 1, 0, light, 0, 1, 0);
		// norden (z0)
		v(p, vc, x1, y0, z0, c, 0, 1, light, 0, 0, -1); v(p, vc, x0, y0, z0, c, 1, 1, light, 0, 0, -1);
		v(p, vc, x0, y1, z0, c, 1, 0, light, 0, 0, -1); v(p, vc, x1, y1, z0, c, 0, 0, light, 0, 0, -1);
		// süden (z1)
		v(p, vc, x0, y0, z1, c, 0, 1, light, 0, 0, 1); v(p, vc, x1, y0, z1, c, 1, 1, light, 0, 0, 1);
		v(p, vc, x1, y1, z1, c, 1, 0, light, 0, 0, 1); v(p, vc, x0, y1, z1, c, 0, 0, light, 0, 0, 1);
		// westen (x0)
		v(p, vc, x0, y0, z0, c, 0, 1, light, -1, 0, 0); v(p, vc, x0, y0, z1, c, 1, 1, light, -1, 0, 0);
		v(p, vc, x0, y1, z1, c, 1, 0, light, -1, 0, 0); v(p, vc, x0, y1, z0, c, 0, 0, light, -1, 0, 0);
		// osten (x1)
		v(p, vc, x1, y0, z1, c, 0, 1, light, 1, 0, 0); v(p, vc, x1, y0, z0, c, 1, 1, light, 1, 0, 0);
		v(p, vc, x1, y1, z0, c, 1, 0, light, 1, 0, 0); v(p, vc, x1, y1, z1, c, 0, 0, light, 1, 0, 0);
	}

	/** Nach +Y zeigendes Quadrat. */
	private static void quadUp(PoseStack.Pose p, VertexConsumer vc, float x0, float y, float z0, float x1, float z1, int color, int light) {
		v(p, vc, x0, y, z0, color, 0, 0, light, 0, 1, 0);
		v(p, vc, x0, y, z1, color, 0, 1, light, 0, 1, 0);
		v(p, vc, x1, y, z1, color, 1, 1, light, 0, 1, 0);
		v(p, vc, x1, y, z0, color, 1, 0, light, 0, 1, 0);
	}

	// Strahlen sollen auch sichtbar bleiben, wenn der Head selbst nicht im Bild ist.
	public boolean shouldRenderOffScreen() {
		return true;
	}

	public int getViewDistance() {
		return 128;
	}
}
