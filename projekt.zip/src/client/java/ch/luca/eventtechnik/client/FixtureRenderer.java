package ch.luca.eventtechnik.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import ch.luca.eventtechnik.block.FixtureBlock;
import ch.luca.eventtechnik.block.FixtureType;
import ch.luca.eventtechnik.blockentity.ConsoleBlockEntity;
import ch.luca.eventtechnik.blockentity.FixtureBlockEntity;
import ch.luca.eventtechnik.show.ShowMath;

/**
 * Zeichnet bei Moving Heads den drehbaren Bügel, den kippbaren Kopf und den Lichtkegel.
 * Koordinaten: Ursprung in der Blockmitte, +Y zeigt in die Montagerichtung (FACING).
 */
public class FixtureRenderer implements BlockEntityRenderer<FixtureBlockEntity, FixtureRenderState> {
	private static final int SEGMENTS = 16;
	private static final float SPOT_MAX = 32f;
	private static final float WASH_MAX = 16f;
	/** Höhe des Drehpunkts (Tilt-Achse) über der Blockmitte. */
	private static final float PIVOT = 0.0625f;
	/** Abstand Drehpunkt → Linse. */
	private static final float LENS = 0.3125f;

	public FixtureRenderer(BlockEntityRendererProvider.Context context) {
	}

	@Override
	public FixtureRenderState createRenderState() {
		return new FixtureRenderState();
	}

	@Override
	public void extractRenderState(FixtureBlockEntity fixture, FixtureRenderState state, float partialTick, Vec3 cameraPos,
			@Nullable ModelFeatureRenderer.CrumblingOverlay crumblingOverlay) {
		BlockEntityRenderer.super.extractRenderState(fixture, state, partialTick, cameraPos, crumblingOverlay);

		FixtureType type = fixture.type();
		state.movingHead = type == FixtureType.SPOT || type == FixtureType.WASH;
		state.on = false;
		if (!state.movingHead) return;

		Level level = fixture.getLevel();
		if (level == null) return;
		BlockState blockState = fixture.getBlockState();
		state.wash = type == FixtureType.WASH;
		state.facing = blockState.hasProperty(FixtureBlock.FACING) ? blockState.getValue(FixtureBlock.FACING) : Direction.UP;

		ConsoleBlockEntity console = fixture.console(level);
		if (console == null) {
			// Ohne Pult: Kopf steht gerade, Licht aus
			state.pan = 0;
			state.tilt = 0;
			return;
		}

		BlockPos pos = fixture.getBlockPos();
		double time = level.getGameTime() + partialTick;
		float[] pt = ShowMath.panTilt(console, pos, time);
		state.pan = pt[0];
		state.tilt = pt[1];

		long tick = level.getGameTime();
		state.on = ShowMath.isOn(console, tick);
		if (!state.on) return;

		state.rgb = ShowMath.colorFor(console, pos, tick);
		float dimmer = console.getDimmer() / 100f;
		float haze = console.getHaze() / 10f;
		state.intensity = dimmer * (0.25f + 0.75f * haze);
		state.beamLength = traceBeam(level, pos, state);
	}

	/** Wie weit kommt der Strahl, bis er auf einen festen Block trifft? */
	private static float traceBeam(Level level, BlockPos pos, FixtureRenderState state) {
		Quaternionf q = new Quaternionf(state.facing.getRotation());
		Vector3f up = q.transform(new Vector3f(0, 1, 0), new Vector3f());
		Vector3f dir = new Quaternionf(q).rotateY(state.pan).rotateX(state.tilt).transform(new Vector3f(0, 1, 0));

		Vec3 start = Vec3.atCenterOf(pos)
				.add(up.x * PIVOT, up.y * PIVOT, up.z * PIVOT)
				.add(dir.x * LENS, dir.y * LENS, dir.z * LENS);
		float max = state.wash ? WASH_MAX : SPOT_MAX;

		for (float d = 0; d < max; d += 0.25f) {
			BlockPos bp = BlockPos.containing(start.x + dir.x * d, start.y + dir.y * d, start.z + dir.z * d);
			if (bp.equals(pos)) continue;
			BlockState hit = level.getBlockState(bp);
			if (!hit.isAir() && hit.canOcclude()) return d;
		}
		return max;
	}

	@Override
	public void submit(FixtureRenderState state, PoseStack poseStack, SubmitNodeCollector collector, CameraRenderState cameraState) {
		if (!state.movingHead) return;

		poseStack.pushPose();
		poseStack.translate(0.5f, 0.5f, 0.5f);
		poseStack.mulPose(state.facing.getRotation());

		// Bügel: dreht sich mit Pan
		poseStack.mulPose(Axis.YP.rotation(state.pan));
		collector.submitCustomGeometry(poseStack, RenderTypes.debugFilledBox(), (pose, vc) -> {
			box(pose, vc, -0.25f, -0.3125f, -0.25f, 0.25f, -0.25f, 0.25f);   // Drehteller
			box(pose, vc, -0.375f, -0.25f, -0.0625f, -0.3125f, 0.1875f, 0.0625f); // Arm links
			box(pose, vc, 0.3125f, -0.25f, -0.0625f, 0.375f, 0.1875f, 0.0625f);   // Arm rechts
		});

		// Kopf: kippt mit Tilt um die Achse zwischen den Armen
		poseStack.translate(0f, PIVOT, 0f);
		poseStack.mulPose(Axis.XP.rotation(state.tilt));
		final int lensColor = state.on ? (0xFF000000 | state.rgb) : 0xFF3A3A42;
		final float lensR = state.wash ? 0.24f : 0.17f;
		collector.submitCustomGeometry(poseStack, RenderTypes.debugFilledBox(), (pose, vc) -> {
			box(pose, vc, -0.28f, -0.22f, -0.28f, 0.28f, LENS, 0.28f);
			// Linse (leicht vor dem Gehäuse, damit sie nicht flimmert)
			float y = LENS + 0.002f;
			quadUp(pose, vc, -lensR, y, -lensR, lensR, lensR, lensColor);
		});

		// Lichtkegel
		if (state.on && state.intensity > 0.01f) {
			final float len = state.beamLength;
			final float r0 = state.wash ? 0.22f : 0.1f;
			final float spread = state.wash ? 0.2f : 0.03f;
			final float alphaCore = (state.wash ? 0.32f : 0.55f) * state.intensity;
			final float alphaHalo = alphaCore * 0.3f;
			final int rgb = state.rgb;
			collector.submitCustomGeometry(poseStack, RenderTypes.debugFilledBox(), (pose, vc) -> {
				cone(pose, vc, LENS + 0.004f, len, r0, r0 + len * spread, rgb, alphaCore);
				cone(pose, vc, LENS + 0.004f, len, r0 * 1.8f, (r0 + len * spread) * 2.2f, rgb, alphaHalo);
			});
		}

		poseStack.popPose();
	}

	// ---------------- Geometrie ----------------

	private static int argb(float a, int rgb) {
		int ai = Math.max(0, Math.min(255, (int) (a * 255)));
		return (ai << 24) | (rgb & 0xFFFFFF);
	}

	/** Kegelmantel entlang +Y. Vorne hell, hinten durchsichtig. Beidseitig, damit man ihn von innen und aussen sieht. */
	private static void cone(PoseStack.Pose pose, VertexConsumer vc, float y0, float len, float r0, float r1, int rgb, float alpha) {
		int cStart = argb(alpha, rgb);
		int cEnd = argb(0f, rgb);
		float y1 = y0 + len;
		for (int i = 0; i < SEGMENTS; i++) {
			double a1 = Math.PI * 2 * i / SEGMENTS;
			double a2 = Math.PI * 2 * (i + 1) / SEGMENTS;
			float c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
			float c2 = (float) Math.cos(a2), s2 = (float) Math.sin(a2);

			// aussen
			vc.addVertex(pose, c1 * r0, y0, s1 * r0).setColor(cStart);
			vc.addVertex(pose, c1 * r1, y1, s1 * r1).setColor(cEnd);
			vc.addVertex(pose, c2 * r1, y1, s2 * r1).setColor(cEnd);
			vc.addVertex(pose, c2 * r0, y0, s2 * r0).setColor(cStart);
			// innen
			vc.addVertex(pose, c2 * r0, y0, s2 * r0).setColor(cStart);
			vc.addVertex(pose, c2 * r1, y1, s2 * r1).setColor(cEnd);
			vc.addVertex(pose, c1 * r1, y1, s1 * r1).setColor(cEnd);
			vc.addVertex(pose, c1 * r0, y0, s1 * r0).setColor(cStart);
		}
	}

	/** Gehäuse-Quader mit leichter Schattierung pro Seite. */
	private static void box(PoseStack.Pose p, VertexConsumer vc, float x0, float y0, float z0, float x1, float y1, float z1) {
		int top = 0xFF34343A, side = 0xFF26262B, side2 = 0xFF202024, bottom = 0xFF18181B;
		// unten
		vc.addVertex(p, x0, y0, z1).setColor(bottom); vc.addVertex(p, x0, y0, z0).setColor(bottom);
		vc.addVertex(p, x1, y0, z0).setColor(bottom); vc.addVertex(p, x1, y0, z1).setColor(bottom);
		// oben
		vc.addVertex(p, x0, y1, z0).setColor(top); vc.addVertex(p, x0, y1, z1).setColor(top);
		vc.addVertex(p, x1, y1, z1).setColor(top); vc.addVertex(p, x1, y1, z0).setColor(top);
		// norden (z0)
		vc.addVertex(p, x1, y0, z0).setColor(side); vc.addVertex(p, x0, y0, z0).setColor(side);
		vc.addVertex(p, x0, y1, z0).setColor(side); vc.addVertex(p, x1, y1, z0).setColor(side);
		// süden (z1)
		vc.addVertex(p, x0, y0, z1).setColor(side); vc.addVertex(p, x1, y0, z1).setColor(side);
		vc.addVertex(p, x1, y1, z1).setColor(side); vc.addVertex(p, x0, y1, z1).setColor(side);
		// westen (x0)
		vc.addVertex(p, x0, y0, z0).setColor(side2); vc.addVertex(p, x0, y0, z1).setColor(side2);
		vc.addVertex(p, x0, y1, z1).setColor(side2); vc.addVertex(p, x0, y1, z0).setColor(side2);
		// osten (x1)
		vc.addVertex(p, x1, y0, z1).setColor(side2); vc.addVertex(p, x1, y0, z0).setColor(side2);
		vc.addVertex(p, x1, y1, z0).setColor(side2); vc.addVertex(p, x1, y1, z1).setColor(side2);
	}

	/** Nach oben zeigendes Quadrat (Linse). */
	private static void quadUp(PoseStack.Pose p, VertexConsumer vc, float x0, float y, float z0, float x1, float z1, int color) {
		vc.addVertex(p, x0, y, z0).setColor(color); vc.addVertex(p, x0, y, z1).setColor(color);
		vc.addVertex(p, x1, y, z1).setColor(color); vc.addVertex(p, x1, y, z0).setColor(color);
	}

	// Strahlen sollen auch sichtbar bleiben, wenn der Head selbst nicht im Bild ist.
	public boolean shouldRenderOffScreen() {
		return true;
	}

	public int getViewDistance() {
		return 128;
	}
}
