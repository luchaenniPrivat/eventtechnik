package ch.luca.eventtechnik.client;

import java.util.Arrays;
import java.util.UUID;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import ch.luca.eventtechnik.EventTechnik;
import ch.luca.eventtechnik.block.FixtureBlock;
import ch.luca.eventtechnik.block.FixtureType;
import ch.luca.eventtechnik.block.LedPanelBlock;
import ch.luca.eventtechnik.blockentity.ConsoleBlockEntity;
import ch.luca.eventtechnik.blockentity.FixtureBlockEntity;
import ch.luca.eventtechnik.client.FixtureRenderState.Kind;
import ch.luca.eventtechnik.show.ShowMath;

/**
 * Zeichnet Moving Heads, Laser, LED-Wand, LED-Floor und den Haze im Raum.
 * Koordinaten: Ursprung in der Blockmitte, +Y zeigt in die Montagerichtung (FACING).
 */
public class FixtureRenderer implements BlockEntityRenderer<FixtureBlockEntity, FixtureRenderState> {
	private static final int SEGMENTS = 16;
	private static final float SPOT_MAX = 32f;
	private static final float WASH_MAX = 16f;
	private static final float LASER_LEN = 28f;
	private static final int LASER_BEAMS = 9;
	private static final float PIVOT = 0.0625f;
	private static final float LENS = 0.3125f;
	private static final int FULL_BRIGHT = 0x00F000F0;

	private static final Identifier BODY_TEX = EventTechnik.id("textures/block/fixture_body.png");
	private static final Identifier WHITE_TEX = EventTechnik.id("textures/block/led_white.png");

	public FixtureRenderer(BlockEntityRendererProvider.Context context) {
	}

	@Override
	public FixtureRenderState createRenderState() {
		return new FixtureRenderState();
	}

	// =====================================================================
	// Zustand sammeln
	// =====================================================================

	@Override
	public void extractRenderState(FixtureBlockEntity fixture, FixtureRenderState state, float partialTick, Vec3 cameraPos,
			@Nullable ModelFeatureRenderer.CrumblingOverlay crumblingOverlay) {
		BlockEntityRenderer.super.extractRenderState(fixture, state, partialTick, cameraPos, crumblingOverlay);

		FixtureType type = fixture.type();
		state.kind = switch (type) {
			case SPOT, WASH -> Kind.HEAD;
			case LED_PANEL -> Kind.PANEL;
			case LED_FLOOR -> Kind.FLOOR;
			case LASER -> Kind.LASER;
			case HAZER -> Kind.HAZE;
			default -> Kind.NONE;
		};
		state.on = false;
		if (state.kind == Kind.NONE) return;

		Level level = fixture.getLevel();
		if (level == null) return;
		BlockState blockState = fixture.getBlockState();
		BlockPos pos = fixture.getBlockPos();
		ConsoleBlockEntity console = fixture.console(level);
		int page = fixture.page();
		int group = fixture.getGroup();
		double time = level.getGameTime() + partialTick;
		long tick = level.getGameTime();

		switch (state.kind) {
			case PANEL -> {
				state.facing = blockState.hasProperty(LedPanelBlock.FACING) ? blockState.getValue(LedPanelBlock.FACING) : Direction.NORTH;
				extractPixels(state, pos, console, page, group, time, false);
			}
			case FLOOR -> {
				state.facing = Direction.UP;
				extractPixels(state, pos, console, page, group, time, true);
			}
			case HAZE -> {
				state.facing = blockState.hasProperty(FixtureBlock.FACING) ? blockState.getValue(FixtureBlock.FACING) : Direction.NORTH;
				state.haze = console == null ? 0 : console.getHaze();
				state.time = (float) (time % 100000);
				state.seed = (int) pos.asLong();
			}
			case HEAD, LASER -> {
				state.wash = type == FixtureType.WASH;
				state.facing = blockState.hasProperty(FixtureBlock.FACING) ? blockState.getValue(FixtureBlock.FACING) : Direction.UP;
				if (console == null) {
					state.pan = 0;
					state.tilt = 0;
					return;
				}
				float[] pt = ShowMath.panTilt(console, page, group, pos, time);
				state.pan = pt[0];
				state.tilt = pt[1];
				if (state.kind == Kind.HEAD && console.getEffect(page, group) == ShowMath.FOLLOW) {
					aimAtTarget(level, pos, state, console.getFollowTarget(), partialTick);
				}
				state.on = ShowMath.isOn(console, page, group, tick);
				if (!state.on) return;
				state.rgb = ShowMath.colorFor(console, page, group, pos, tick);
				float dimmer = console.getDimmer(page, group) / 100f;
				float haze = console.getHaze() / 10f;
				state.intensity = state.kind == Kind.LASER
						? dimmer * (0.45f + 0.55f * haze)
						: dimmer * (0.25f + 0.75f * haze);
				state.beamLength = state.kind == Kind.HEAD ? traceBeam(level, pos, state) : LASER_LEN;
			}
			default -> { }
		}
	}

	/** Verfolger: Pan/Tilt so setzen, dass der Kopf auf den Spieler zeigt. */
	private static void aimAtTarget(Level level, BlockPos pos, FixtureRenderState state, @Nullable UUID target, float partialTick) {
		if (target == null) return;
		Player player = level.getPlayerByUUID(target);
		if (player == null) return;

		Quaternionf q = new Quaternionf(state.facing.getRotation());
		Vector3f up = q.transform(new Vector3f(0, 1, 0), new Vector3f());
		Vec3 pivot = Vec3.atCenterOf(pos).add(up.x * PIVOT, up.y * PIVOT, up.z * PIVOT);
		Vec3 aim = player.getPosition(partialTick).add(0, player.getBbHeight() * 0.6, 0);

		Vector3f d = new Vector3f((float) (aim.x - pivot.x), (float) (aim.y - pivot.y), (float) (aim.z - pivot.z));
		if (d.lengthSquared() < 1e-4f) return;
		d.normalize();
		new Quaternionf(q).conjugate().transform(d); // Welt → lokal
		// lokal: Richtung = rotY(pan) · rotX(tilt) · (0,1,0) = (sin t · sin p, cos t, sin t · cos p)
		state.tilt = (float) Math.acos(Math.max(-1f, Math.min(1f, d.y)));
		state.pan = (float) Math.atan2(d.x, d.z);
	}

	/** Pixel aus Weltkoordinaten, damit benachbarte Panels/Bodenplatten ein Bild ergeben. */
	private static void extractPixels(FixtureRenderState state, BlockPos pos, @Nullable ConsoleBlockEntity console,
			int page, int group, double time, boolean floor) {
		int res = FixtureRenderState.PANEL_RES;
		if (console == null) {
			Arrays.fill(state.pixels, -1);
			return;
		}
		state.panelBrightness = console.getDimmer(page, group) / 100f;

		if (floor) {
			for (int row = 0; row < res; row++) {
				for (int col = 0; col < res; col++) {
					int u = pos.getX() * res + col;
					int v = pos.getZ() * res + row;
					state.pixels[row * res + col] = ShowMath.ledWallPixel(console, page, group, u, v, time);
				}
			}
			return;
		}

		Quaternionf q = new Quaternionf(state.facing.getRotation());
		boolean alongX = state.facing.getAxis() == Direction.Axis.Z;
		float cell = 1f / res;
		Vector3f w = new Vector3f();
		for (int row = 0; row < res; row++) {
			for (int col = 0; col < res; col++) {
				w.set(-0.5f + (col + 0.5f) * cell, -0.37f, 0.5f - (row + 0.5f) * cell);
				q.transform(w);
				double wx = pos.getX() + 0.5 + w.x;
				double wy = pos.getY() + 0.5 + w.y;
				double wz = pos.getZ() + 0.5 + w.z;
				int u = (int) Math.floor((alongX ? wx : wz) * res);
				int v = (int) Math.floor(wy * res);
				state.pixels[row * res + col] = ShowMath.ledWallPixel(console, page, group, u, v, time);
			}
		}
	}

	private static float traceBeam(Level level, BlockPos pos, FixtureRenderState state) {
		Quaternionf q = new Quaternionf(state.facing.getRotation());
		Vector3f up = q.transform(new Vector3f(0, 1, 0), new Vector3f());
		Vector3f dir = new Quaternionf(q).rotateY(state.pan).rotateX(state.tilt).transform(new Vector3f(0, 1, 0));
		Vec3 start = Vec3.atCenterOf(pos)
				.add(up.x * PIVOT, up.y * PIVOT, up.z * PIVOT)
				.add(dir.x * LENS, dir.y * LENS, dir.z * LENS);
		float max = state.wash ? WASH_MAX : SPOT_MAX;
		for (float d = 0; d < max; d += 0.25f) {
			BlockPos bp = BlockPos.containing(start.x + dir.x * d, start.y + dir.y * d, start.z + dir.z * d);
			if (bp.equals(pos)) continue;
			BlockState hit = level.getBlockState(bp);
			if (!hit.isAir() && hit.canOcclude()) return d;
		}
		return max;
	}

	// =====================================================================
	// Zeichnen
	// =====================================================================

	@Override
	public void submit(FixtureRenderState state, PoseStack poseStack, SubmitNodeCollector collector, CameraRenderState cameraState) {
		switch (state.kind) {
			case HEAD -> submitHead(state, poseStack, collector);
			case PANEL -> submitPixels(state, poseStack, collector, -0.37f);
			case FLOOR -> submitPixels(state, poseStack, collector, 0.501f);
			case LASER -> submitLaser(state, poseStack, collector);
			case HAZE -> submitHaze(state, poseStack, collector);
			default -> { }
		}
	}

	private static void rotateToFacing(PoseStack poseStack, Direction facing) {
		poseStack.translate(0.5f, 0.5f, 0.5f);
		poseStack.mulPose(new Matrix4f().rotation(facing.getRotation()));
	}

	// ---------------- LED-Wand & Floor ----------------

	private static void submitPixels(FixtureRenderState state, PoseStack poseStack, SubmitNodeCollector collector, float y) {
		poseStack.pushPose();
		rotateToFacing(poseStack, state.facing);
		final int res = FixtureRenderState.PANEL_RES;
		final float bright = 0.35f + 0.65f * state.panelBrightness;
		final int[] pixels = state.pixels.clone();
		final boolean floor = state.kind == Kind.FLOOR;

		collector.submitCustomGeometry(poseStack, RenderTypes.entitySolid(WHITE_TEX), (pose, vc) -> {
			float cell = 1f / res;
			float gap = floor ? 0.02f : 0.012f;
			for (int row = 0; row < res; row++) {
				for (int col = 0; col < res; col++) {
					int rgb = pixels[row * res + col];
					int color = rgb < 0 ? 0xFF0C0C0E : (0xFF000000 | scale(rgb, bright));
					float x0 = -0.5f + col * cell + gap, x1 = -0.5f + (col + 1) * cell - gap;
					float z0, z1;
					if (floor) {
						z0 = -0.5f + row * cell + gap;
						z1 = -0.5f + (row + 1) * cell - gap;
					} else {
						z1 = 0.5f - row * cell - gap;
						z0 = 0.5f - (row + 1) * cell + gap;
					}
					quadUp(pose, vc, x0, y, z0, x1, z1, color, FULL_BRIGHT);
				}
			}
		});
		poseStack.popPose();
	}

	private static int scale(int rgb, float f) {
		int r = (int) (((rgb >> 16) & 0xFF) * f);
		int g = (int) (((rgb >> 8) & 0xFF) * f);
		int b = (int) ((rgb & 0xFF) * f);
		return (r << 16) | (g << 8) | b;
	}

	// ---------------- Moving Head ----------------

	private static void submitHead(FixtureRenderState state, PoseStack poseStack, SubmitNodeCollector collector) {
		final int light = state.lightCoords;
		RenderType body = RenderTypes.entitySolid(BODY_TEX);

		poseStack.pushPose();
		rotateToFacing(poseStack, state.facing);

		poseStack.mulPose(new Matrix4f().rotation(Axis.YP.rotation(state.pan)));
		collector.submitCustomGeometry(poseStack, body, (pose, vc) -> {
			box(pose, vc, -0.25f, -0.3125f, -0.25f, 0.25f, -0.25f, 0.25f, light);
			box(pose, vc, -0.375f, -0.25f, -0.0625f, -0.3125f, 0.1875f, 0.0625f, light);
			box(pose, vc, 0.3125f, -0.25f, -0.0625f, 0.375f, 0.1875f, 0.0625f, light);
		});

		poseStack.translate(0f, PIVOT, 0f);
		poseStack.mulPose(new Matrix4f().rotation(Axis.XP.rotation(state.tilt)));
		collector.submitCustomGeometry(poseStack, body, (pose, vc) ->
				box(pose, vc, -0.28f, -0.22f, -0.28f, 0.28f, LENS, 0.28f, light));

		final int lensColor = state.on ? (0xFF000000 | state.rgb) : 0xFF3A3A42;
		final float lensR = state.wash ? 0.24f : 0.17f;
		final boolean on = state.on;
		collector.submitCustomGeometry(poseStack, RenderTypes.entitySolid(WHITE_TEX), (pose, vc) ->
				quadUp(pose, vc, -lensR, LENS + 0.002f, -lensR, lensR, lensR, lensColor, on ? FULL_BRIGHT : light));

		if (state.on && state.intensity > 0.01f) {
			final float len = state.beamLength;
			final float r0 = state.wash ? 0.22f : 0.1f;
			final float spread = state.wash ? 0.2f : 0.03f;
			final float alphaCore = (state.wash ? 0.32f : 0.55f) * state.intensity;
			final float alphaHalo = alphaCore * 0.3f;
			final int rgb = state.rgb;
			collector.submitCustomGeometry(poseStack, RenderTypes.debugFilledBox(), (pose, vc) -> {
				cone(pose, vc, LENS + 0.004f, len, r0, r0 + len * spread, rgb, alphaCore);
				cone(pose, vc, LENS + 0.004f, len, r0 * 1.8f, (r0 + len * spread) * 2.2f, rgb, alphaHalo);
			});
		}
		poseStack.popPose();
	}

	// ---------------- Laser ----------------

	private static void submitLaser(FixtureRenderState state, PoseStack poseStack, SubmitNodeCollector collector) {
		final int light = state.lightCoords;
		poseStack.pushPose();
		rotateToFacing(poseStack, state.facing);

		collector.submitCustomGeometry(poseStack, RenderTypes.entitySolid(BODY_TEX), (pose, vc) ->
				box(pose, vc, -0.3f, -0.5f, -0.3f, 0.3f, -0.1f, 0.3f, light));

		if (state.on && state.intensity > 0.01f) {
			final float pan = state.pan;
			// Fächerbreite aus dem Tilt-Wert des Effekts
			final float spread = 0.12f + Math.min(0.9f, Math.abs(state.tilt)) * 0.6f;
			final int rgb = state.rgb;
			final float alpha = 0.85f * state.intensity;
			poseStack.translate(0f, -0.09f, 0f);
			poseStack.mulPose(new Matrix4f().rotation(Axis.YP.rotation(pan)));
			for (int i = 0; i < LASER_BEAMS; i++) {
				float a = (i - (LASER_BEAMS - 1) / 2f) / ((LASER_BEAMS - 1) / 2f) * spread;
				poseStack.pushPose();
				poseStack.mulPose(new Matrix4f().rotation(Axis.ZP.rotation(a)));
				collector.submitCustomGeometry(poseStack, RenderTypes.debugFilledBox(), (pose, vc) -> {
					cone(pose, vc, 0f, LASER_LEN, 0.008f, 0.035f, rgb, alpha);
					cone(pose, vc, 0f, LASER_LEN, 0.03f, 0.12f, rgb, alpha * 0.15f);
				});
				poseStack.popPose();
			}
		}
		poseStack.popPose();
	}

	// ---------------- Haze ----------------

	/**
	 * Haze als weicher, durchgehender Nebel: viele sehr durchsichtige "Wolken-Kugeln" aus drei
	 * gekreuzten Scheiben mit weichem Rand. Sie liegen dicht beieinander und treiben langsam,
	 * sodass ein gleichmässiger Schleier entsteht statt einzelner Partikel.
	 */
	private static void submitHaze(FixtureRenderState state, PoseStack poseStack, SubmitNodeCollector collector) {
		if (state.haze <= 0) return;
		final int haze = state.haze;
		final float t = state.time;
		final Direction f = state.facing;
		final float radius = 2.5f + haze * 1.2f;          // Fläche wächst mit Haze
		final float height = 1.2f + haze * 0.3f;          // und die Höhe der Schicht
		final float spacing = 1.7f;
		final float puff = 1.9f;
		final float alpha = 0.035f + haze * 0.007f;
		final int rgb = 0xDCE2EE;
		final float cx = 0.5f + f.getStepX() * radius * 0.85f;
		final float cz = 0.5f + f.getStepZ() * radius * 0.85f;
		final int seed = state.seed;

		collector.submitCustomGeometry(poseStack, RenderTypes.debugFilledBox(), (pose, vc) -> {
			int n = (int) Math.ceil(radius / spacing);
			for (int ix = -n; ix <= n; ix++) {
				for (int iz = -n; iz <= n; iz++) {
					float gx = ix * spacing, gz = iz * spacing;
					float dist = (float) Math.sqrt(gx * gx + gz * gz);
					if (dist > radius) continue;
					for (int layer = 0; layer * spacing * 0.8f < height; layer++) {
						int h = hash(seed, ix, iz, layer);
						float ph = (h & 1023) / 1023f * 6.28f;
						// langsames Treiben
						float px = cx + gx + (float) Math.sin(t * 0.011f + ph) * 0.6f + ((h >> 10) & 255) / 255f - 0.5f;
						float pz = cz + gz + (float) Math.cos(t * 0.009f + ph) * 0.6f + ((h >> 18) & 255) / 255f - 0.5f;
						float py = 0.3f + layer * spacing * 0.8f + (float) Math.sin(t * 0.013f + ph * 2) * 0.25f;
						// zum Rand hin dünner
						float edge = 1f - (dist / radius) * (dist / radius) * 0.7f;
						float a = alpha * edge;
						float r = puff * (0.8f + ((h >> 4) & 63) / 63f * 0.5f);
						disc(pose, vc, px, py, pz, r, 0, rgb, a); // waagrecht
						disc(pose, vc, px, py, pz, r, 1, rgb, a); // senkrecht X
						disc(pose, vc, px, py, pz, r, 2, rgb, a); // senkrecht Z
					}
				}
			}
		});
	}

	private static int hash(int seed, int x, int y, int z) {
		int h = seed ^ (x * 73856093) ^ (y * 19349663) ^ (z * 83492791);
		h ^= h >>> 13;
		h *= 0x5bd1e995;
		return (h ^ (h >>> 15)) & 0x7FFFFFFF;
	}

	/** Weiche Scheibe: Mitte deckend, Rand durchsichtig. axis 0 = waagrecht, 1 = Ebene XY, 2 = Ebene ZY. Beidseitig. */
	private static void disc(PoseStack.Pose p, VertexConsumer vc, float x, float y, float z, float r, int axis, int rgb, float alpha) {
		final int segs = 8;
		int center = argb(alpha, rgb);
		int edge = argb(0f, rgb);
		for (int i = 0; i < segs; i++) {
			double a1 = Math.PI * 2 * i / segs, a2 = Math.PI * 2 * (i + 1) / segs;
			float c1 = (float) Math.cos(a1) * r, s1 = (float) Math.sin(a1) * r;
			float c2 = (float) Math.cos(a2) * r, s2 = (float) Math.sin(a2) * r;
			float ax1, ay1, az1, ax2, ay2, az2;
			switch (axis) {
				case 0 -> { ax1 = x + c1; ay1 = y; az1 = z + s1; ax2 = x + c2; ay2 = y; az2 = z + s2; }
				case 1 -> { ax1 = x + c1; ay1 = y + s1; az1 = z; ax2 = x + c2; ay2 = y + s2; az2 = z; }
				default -> { ax1 = x; ay1 = y + s1; az1 = z + c1; ax2 = x; ay2 = y + s2; az2 = z + c2; }
			}
			vc.addVertex(p, x, y, z).setColor(center);
			vc.addVertex(p, ax1, ay1, az1).setColor(edge);
			vc.addVertex(p, ax2, ay2, az2).setColor(edge);
			vc.addVertex(p, x, y, z).setColor(center);

			vc.addVertex(p, x, y, z).setColor(center);
			vc.addVertex(p, ax2, ay2, az2).setColor(edge);
			vc.addVertex(p, ax1, ay1, az1).setColor(edge);
			vc.addVertex(p, x, y, z).setColor(center);
		}
	}

	// ---------------- Geometrie ----------------

	private static int argb(float a, int rgb) {
		int ai = Math.max(0, Math.min(255, (int) (a * 255)));
		return (ai << 24) | (rgb & 0xFFFFFF);
	}

	private static void cone(PoseStack.Pose pose, VertexConsumer vc, float y0, float len, float r0, float r1, int rgb, float alpha) {
		int cStart = argb(alpha, rgb);
		int cEnd = argb(0f, rgb);
		float y1 = y0 + len;
		for (int i = 0; i < SEGMENTS; i++) {
			double a1 = Math.PI * 2 * i / SEGMENTS;
			double a2 = Math.PI * 2 * (i + 1) / SEGMENTS;
			float c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
			float c2 = (float) Math.cos(a2), s2 = (float) Math.sin(a2);

			vc.addVertex(pose, c1 * r0, y0, s1 * r0).setColor(cStart);
			vc.addVertex(pose, c1 * r1, y1, s1 * r1).setColor(cEnd);
			vc.addVertex(pose, c2 * r1, y1, s2 * r1).setColor(cEnd);
			vc.addVertex(pose, c2 * r0, y0, s2 * r0).setColor(cStart);

			vc.addVertex(pose, c2 * r0, y0, s2 * r0).setColor(cStart);
			vc.addVertex(pose, c2 * r1, y1, s2 * r1).setColor(cEnd);
			vc.addVertex(pose, c1 * r1, y1, s1 * r1).setColor(cEnd);
			vc.addVertex(pose, c1 * r0, y0, s1 * r0).setColor(cStart);
		}
	}

	private static void v(PoseStack.Pose p, VertexConsumer vc, float x, float y, float z, int color, float u, float w,
			int light, float nx, float ny, float nz) {
		vc.addVertex(p, x, y, z).setColor(color).setUv(u, w).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(p, nx, ny, nz);
	}

	private static void box(PoseStack.Pose p, VertexConsumer vc, float x0, float y0, float z0, float x1, float y1, float z1, int light) {
		int c = 0xFFFFFFFF;
		v(p, vc, x0, y0, z1, c, 0, 1, light, 0, -1, 0); v(p, vc, x0, y0, z0, c, 0, 0, light, 0, -1, 0);
		v(p, vc, x1, y0, z0, c, 1, 0, light, 0, -1, 0); v(p, vc, x1, y0, z1, c, 1, 1, light, 0, -1, 0);
		v(p, vc, x0, y1, z0, c, 0, 0, light, 0, 1, 0); v(p, vc, x0, y1, z1, c, 0, 1, light, 0, 1, 0);
		v(p, vc, x1, y1, z1, c, 1, 1, light, 0, 1, 0); v(p, vc, x1, y1, z0, c, 1, 0, light, 0, 1, 0);
		v(p, vc, x1, y0, z0, c, 0, 1, light, 0, 0, -1); v(p, vc, x0, y0, z0, c, 1, 1, light, 0, 0, -1);
		v(p, vc, x0, y1, z0, c, 1, 0, light, 0, 0, -1); v(p, vc, x1, y1, z0, c, 0, 0, light, 0, 0, -1);
		v(p, vc, x0, y0, z1, c, 0, 1, light, 0, 0, 1); v(p, vc, x1, y0, z1, c, 1, 1, light, 0, 0, 1);
		v(p, vc, x1, y1, z1, c, 1, 0, light, 0, 0, 1); v(p, vc, x0, y1, z1, c, 0, 0, light, 0, 0, 1);
		v(p, vc, x0, y0, z0, c, 0, 1, light, -1, 0, 0); v(p, vc, x0, y0, z1, c, 1, 1, light, -1, 0, 0);
		v(p, vc, x0, y1, z1, c, 1, 0, light, -1, 0, 0); v(p, vc, x0, y1, z0, c, 0, 0, light, -1, 0, 0);
		v(p, vc, x1, y0, z1, c, 0, 1, light, 1, 0, 0); v(p, vc, x1, y0, z0, c, 1, 1, light, 1, 0, 0);
		v(p, vc, x1, y1, z0, c, 1, 0, light, 1, 0, 0); v(p, vc, x1, y1, z1, c, 0, 0, light, 1, 0, 0);
	}

	private static void quadUp(PoseStack.Pose p, VertexConsumer vc, float x0, float y, float z0, float x1, float z1, int color, int light) {
		v(p, vc, x0, y, z0, color, 0, 0, light, 0, 1, 0);
		v(p, vc, x0, y, z1, color, 0, 1, light, 0, 1, 0);
		v(p, vc, x1, y, z1, color, 1, 1, light, 0, 1, 0);
		v(p, vc, x1, y, z0, color, 1, 0, light, 0, 1, 0);
	}

	public boolean shouldRenderOffScreen() {
		return true;
	}

	public int getViewDistance() {
		return 128;
	}
}
