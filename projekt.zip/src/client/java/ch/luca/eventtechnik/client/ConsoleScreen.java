package ch.luca.eventtechnik.client;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.jetbrains.annotations.Nullable;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

import ch.luca.eventtechnik.blockentity.ConsoleBlockEntity;
import ch.luca.eventtechnik.network.ConsoleActionPayload;
import ch.luca.eventtechnik.show.ShowMath;

/**
 * GUI des Lichtpults.
 * Zeile 1: Seite (Alle, Spots, Washes, LED-Bars, LED-Wand, Laser, Floor).
 * Zeile 2: Gruppe (Alle, 1–8). Darunter Werte der Auswahl, ganz unten Master und Verfolger-Ziel.
 */
public class ConsoleScreen extends Screen {
	private static final int PANEL_W = 320;
	private static final int G = ConsoleBlockEntity.GROUPS;
	private static final int P = ConsoleBlockEntity.PAGES;

	private final BlockPos pos;
	private int page = -1;
	private int group = -1;

	private final List<Button> pageTabs = new ArrayList<>();
	private final List<Button> groupTabs = new ArrayList<>();
	private final List<Button> colorBtns = new ArrayList<>();
	private final List<Button> effectBtns = new ArrayList<>();
	private Button groupOnBtn;
	private Button blackoutBtn;
	private Button strobeBtn;
	private Button autoBtn;
	private Button followBtn;
	private int top;
	private int left;

	public ConsoleScreen(BlockPos pos) {
		super(Component.translatable("screen.eventtechnik.console"));
		this.pos = pos;
	}

	@Nullable
	private ConsoleBlockEntity console() {
		if (minecraft == null || minecraft.level == null) return null;
		return minecraft.level.getBlockEntity(pos) instanceof ConsoleBlockEntity c ? c : null;
	}

	private void send(int action, int value) {
		ClientPlayNetworking.send(new ConsoleActionPayload(pos, action, ConsoleBlockEntity.target(page, group), value));
	}

	private int shownPage() { return Math.max(0, page); }
	private int shownGroup() { return Math.max(0, group); }

	@Override
	protected void init() {
		pageTabs.clear();
		groupTabs.clear();
		colorBtns.clear();
		effectBtns.clear();
		left = width / 2 - PANEL_W / 2;
		top = height / 2 - 112;
		int y = top;

		for (int i = -1; i < P; i++) {
			final int p = i;
			pageTabs.add(addRenderableWidget(Button.builder(Component.literal(""), b -> page = p)
					.bounds(left + (i + 1) * 46, y, 44, 20).build()));
		}
		y += 22;
		for (int i = -1; i < G; i++) {
			final int g = i;
			groupTabs.add(addRenderableWidget(Button.builder(Component.literal(""), b -> group = g)
					.bounds(left + (i + 1) * 35, y, 33, 20).build()));
		}

		y += 28;
		groupOnBtn = addRenderableWidget(Button.builder(Component.literal(""), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) send(ConsoleBlockEntity.ACTION_GROUP_ON, c.isRawGroupOn(shownPage(), shownGroup()) ? 0 : 1);
		}).bounds(left, y, 100, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Dimmer -"), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) send(ConsoleBlockEntity.ACTION_GROUP_DIMMER, c.getGroupDimmer(shownPage(), shownGroup()) - 10);
		}).bounds(left + 106, y, 104, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Dimmer +"), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) send(ConsoleBlockEntity.ACTION_GROUP_DIMMER, c.getGroupDimmer(shownPage(), shownGroup()) + 10);
		}).bounds(left + 216, y, 104, 20).build());

		y += 32;
		for (int i = 0; i < ShowMath.COLOR_NAMES.length; i++) {
			final int color = i;
			colorBtns.add(addRenderableWidget(Button.builder(Component.literal(""), b -> send(ConsoleBlockEntity.ACTION_COLOR, color))
					.bounds(left + (i % 5) * 64, y + (i / 5) * 22, 62, 20).build()));
		}

		y += 54;
		for (int i = 0; i < ShowMath.EFFECT_NAMES.length; i++) {
			final int effect = i;
			effectBtns.add(addRenderableWidget(Button.builder(Component.literal(""), b -> send(ConsoleBlockEntity.ACTION_EFFECT, effect))
					.bounds(left + i * 54, y, 52, 20).build()));
		}

		y += 32;
		blackoutBtn = addRenderableWidget(Button.builder(Component.literal(""), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) send(ConsoleBlockEntity.ACTION_BLACKOUT, c.isBlackoutSwitch() ? 0 : 1);
		}).bounds(left, y, 76, 20).build());
		strobeBtn = addRenderableWidget(Button.builder(Component.literal(""), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) send(ConsoleBlockEntity.ACTION_STROBE, c.isStrobe() ? 0 : 1);
		}).bounds(left + 80, y, 76, 20).build());
		autoBtn = addRenderableWidget(Button.builder(Component.literal(""), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) send(ConsoleBlockEntity.ACTION_AUTO, c.isAuto() ? 0 : 1);
		}).bounds(left + 160, y, 76, 20).build());
		followBtn = addRenderableWidget(Button.builder(Component.literal(""), b -> cycleFollow())
				.bounds(left + 240, y, 80, 20).build());

		y += 24;
		master(left, y, "Master -", ConsoleBlockEntity.ACTION_MASTER_DIMMER, -10);
		master(left + 54, y, "Master +", ConsoleBlockEntity.ACTION_MASTER_DIMMER, 10);
		master(left + 108, y, "Speed -", ConsoleBlockEntity.ACTION_SPEED, -1);
		master(left + 162, y, "Speed +", ConsoleBlockEntity.ACTION_SPEED, 1);
		master(left + 216, y, "Haze -", ConsoleBlockEntity.ACTION_HAZE, -1);
		master(left + 270, y, "Haze +", ConsoleBlockEntity.ACTION_HAZE, 1);
	}

	/** Verfolger-Ziel: nächster Spieler in der Welt, nach dem letzten wieder "kein Ziel". */
	private void cycleFollow() {
		ConsoleBlockEntity c = console();
		if (c == null || minecraft == null || minecraft.level == null) return;
		List<? extends Player> players = minecraft.level.players();
		UUID current = c.getFollowTarget();
		int idx = -1;
		for (int i = 0; i < players.size(); i++) {
			if (players.get(i).getUUID().equals(current)) idx = i;
		}
		int next = idx + 1;
		int id = next < players.size() ? players.get(next).getId() : -1;
		send(ConsoleBlockEntity.ACTION_FOLLOW, id);
	}

	private String followName(ConsoleBlockEntity c) {
		UUID t = c.getFollowTarget();
		if (t == null || minecraft == null || minecraft.level == null) return "–";
		Player p = minecraft.level.getPlayerByUUID(t);
		return p == null ? "weg" : p.getName().getString();
	}

	private void master(int x, int y, String label, int action, int delta) {
		addRenderableWidget(Button.builder(Component.literal(label), b -> {
			ConsoleBlockEntity c = console();
			if (c == null) return;
			int current = switch (action) {
				case ConsoleBlockEntity.ACTION_MASTER_DIMMER -> c.getMasterDimmer();
				case ConsoleBlockEntity.ACTION_SPEED -> c.getRawSpeed();
				case ConsoleBlockEntity.ACTION_HAZE -> c.getRawHaze();
				default -> 0;
			};
			ClientPlayNetworking.send(new ConsoleActionPayload(pos, action, 0, current + delta));
		}).bounds(x, y, 50, 20).build());
	}

	private static Component mark(boolean active, String text) {
		return Component.literal(active ? "§a> " + text : text);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		ConsoleBlockEntity c = console();
		if (c == null) {
			onClose();
			return;
		}
		int p = shownPage();
		int g = shownGroup();

		for (int i = 0; i < pageTabs.size(); i++) {
			int pi = i - 1;
			String label = pi < 0 ? "Alle" : ConsoleBlockEntity.PAGE_NAMES[pi];
			pageTabs.get(i).setMessage(Component.literal(pi == page ? "§e" + label : label));
		}
		for (int i = 0; i < groupTabs.size(); i++) {
			int gi = i - 1;
			String label = gi < 0 ? "Alle" : String.valueOf(gi + 1);
			groupTabs.get(i).setMessage(Component.literal(gi == group ? "§e[" + label + "]" : label));
		}
		groupOnBtn.setMessage(Component.literal(c.isRawGroupOn(p, g) ? "§aAN" : "§7AUS"));
		for (int i = 0; i < colorBtns.size(); i++) {
			colorBtns.get(i).setMessage(mark(i == c.getRawColor(p, g), ShowMath.COLOR_NAMES[i]));
		}
		for (int i = 0; i < effectBtns.size(); i++) {
			effectBtns.get(i).setMessage(mark(i == c.getRawEffect(p, g), ShowMath.EFFECT_NAMES[i]));
		}
		blackoutBtn.setMessage(Component.literal(c.isBlackoutSwitch() ? "§cBLACKOUT" : "Blackout"));
		strobeBtn.setMessage(Component.literal(c.isStrobe() ? "§eSTROBE" : "Strobe"));
		autoBtn.setMessage(Component.literal(c.isAuto() ? "§bAUTO" : "Auto"));
		followBtn.setMessage(Component.literal("Ziel: " + followName(c)));

		super.extractRenderState(graphics, mouseX, mouseY, delta);

		String pageName = page < 0 ? "Alle Seiten" : ConsoleBlockEntity.PAGE_NAMES[page];
		String groupName = group < 0 ? "alle Gruppen" : "Gruppe " + (group + 1);
		graphics.text(font, "LICHTPULT  –  " + pageName + ", " + groupName + "  –  Dimmer " + c.getGroupDimmer(p, g) + "%",
				left, top - 12, 0xFFFFD200, true);
		graphics.text(font, "Farbe", left, top + 72, 0xFFAAAAAA, true);
		graphics.text(font, "Effekt", left, top + 126, 0xFFAAAAAA, true);
		graphics.text(font, "Master " + c.getMasterDimmer() + "%   Speed " + c.getRawSpeed() + "   Haze " + c.getRawHaze(),
				left, top + 157, 0xFFFFFFFF, true);
		graphics.text(font, "§7Gruppe zuweisen: leere Hand + Rechtsklick aufs Gerät",
				left, top + 218, 0xFFAAAAAA, false);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
