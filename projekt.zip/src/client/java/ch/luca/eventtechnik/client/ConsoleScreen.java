package ch.luca.eventtechnik.client;

import java.util.ArrayList;
import java.util.List;

import org.jetbrains.annotations.Nullable;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

import ch.luca.eventtechnik.blockentity.ConsoleBlockEntity;
import ch.luca.eventtechnik.network.ConsoleActionPayload;
import ch.luca.eventtechnik.show.ShowMath;

/**
 * GUI des Lichtpults: Blackout, Strobe, Dimmer, Farben, Effekte, Speed, Haze.
 */
public class ConsoleScreen extends Screen {
	private static final int PANEL_W = 300;

	private final BlockPos pos;
	private Button blackoutBtn;
	private Button strobeBtn;
	private final List<Button> colorBtns = new ArrayList<>();
	private final List<Button> effectBtns = new ArrayList<>();

	public ConsoleScreen(BlockPos pos) {
		super(Component.translatable("screen.eventtechnik.console"));
		this.pos = pos;
	}

	@Nullable
	private ConsoleBlockEntity console() {
		if (minecraft == null || minecraft.level == null) return null;
		return minecraft.level.getBlockEntity(pos) instanceof ConsoleBlockEntity c ? c : null;
	}

	private void send(int action, int value) {
		ClientPlayNetworking.send(new ConsoleActionPayload(pos, action, value));
	}

	@Override
	protected void init() {
		colorBtns.clear();
		effectBtns.clear();
		int left = width / 2 - PANEL_W / 2;
		int y = height / 2 - 95;

		// Zeile 1: Blackout + Strobe
		blackoutBtn = addRenderableWidget(Button.builder(Component.literal("Blackout"), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) send(ConsoleBlockEntity.ACTION_BLACKOUT, c.isBlackout() ? 0 : 1);
		}).bounds(left, y, 147, 20).build());
		strobeBtn = addRenderableWidget(Button.builder(Component.literal("Strobe"), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) send(ConsoleBlockEntity.ACTION_STROBE, c.isStrobe() ? 0 : 1);
		}).bounds(left + 153, y, 147, 20).build());

		// Zeile 2: Dimmer
		y += 26;
		addStepper(left, y, ConsoleBlockEntity.ACTION_DIMMER, -10, "Dimmer -");
		addStepper(left + 153, y, ConsoleBlockEntity.ACTION_DIMMER, 10, "Dimmer +");

		// Zeile 3+4: Farben
		y += 34;
		for (int i = 0; i < ShowMath.COLOR_NAMES.length; i++) {
			final int color = i;
			int col = i % 5;
			int row = i / 5;
			Button b = addRenderableWidget(Button.builder(Component.literal(ShowMath.COLOR_NAMES[i]),
					btn -> send(ConsoleBlockEntity.ACTION_COLOR, color))
					.bounds(left + col * 60, y + row * 22, 58, 20).build());
			colorBtns.add(b);
		}

		// Zeile 5: Effekte
		y += 54;
		for (int i = 0; i < ShowMath.EFFECT_NAMES.length; i++) {
			final int effect = i;
			Button b = addRenderableWidget(Button.builder(Component.literal(ShowMath.EFFECT_NAMES[i]),
					btn -> send(ConsoleBlockEntity.ACTION_EFFECT, effect))
					.bounds(left + i * 60, y, 58, 20).build());
			effectBtns.add(b);
		}

		// Zeile 6: Speed + Haze
		y += 34;
		addStepper(left, y, ConsoleBlockEntity.ACTION_SPEED, -1, "Speed -");
		addStepper(left + 75, y, ConsoleBlockEntity.ACTION_SPEED, 1, "Speed +");
		addStepper(left + 153, y, ConsoleBlockEntity.ACTION_HAZE, -1, "Haze -");
		addStepper(left + 228, y, ConsoleBlockEntity.ACTION_HAZE, 1, "Haze +");
	}

	private void addStepper(int x, int y, int action, int delta, String label) {
		int w = (action == ConsoleBlockEntity.ACTION_DIMMER) ? 147 : 72;
		addRenderableWidget(Button.builder(Component.literal(label), b -> {
			ConsoleBlockEntity c = console();
			if (c == null) return;
			int current = switch (action) {
				case ConsoleBlockEntity.ACTION_DIMMER -> c.getDimmer();
				case ConsoleBlockEntity.ACTION_SPEED -> c.getSpeed();
				case ConsoleBlockEntity.ACTION_HAZE -> c.getHaze();
				default -> 0;
			};
			send(action, current + delta);
		}).bounds(x, y, w, 20).build());
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		ConsoleBlockEntity c = console();
		if (c == null) {
			onClose();
			return;
		}

		// Aktive Knöpfe markieren
		blackoutBtn.setMessage(Component.literal(c.isBlackout() ? "§cBLACKOUT AN" : "Blackout"));
		strobeBtn.setMessage(Component.literal(c.isStrobe() ? "§eSTROBE AN" : "Strobe"));
		for (int i = 0; i < colorBtns.size(); i++) {
			String name = ShowMath.COLOR_NAMES[i];
			colorBtns.get(i).setMessage(Component.literal(i == c.getColor() ? "§a> " + name : name));
		}
		for (int i = 0; i < effectBtns.size(); i++) {
			String name = ShowMath.EFFECT_NAMES[i];
			effectBtns.get(i).setMessage(Component.literal(i == c.getEffect() ? "§a> " + name : name));
		}

		super.extractRenderState(graphics, mouseX, mouseY, delta);

		int left = width / 2 - PANEL_W / 2;
		int top = height / 2 - 95;
		graphics.text(font, "LICHTPULT", left, top - 22, 0xFFFFD200, true);
		graphics.text(font,
				"Dimmer " + c.getDimmer() + "%   Speed " + c.getSpeed() + "   Haze " + c.getHaze(),
				left, top - 11, 0xFFFFFFFF, true);
		graphics.text(font, "Farbe", left, top + 50, 0xFFAAAAAA, true);
		graphics.text(font, "Effekt", left, top + 104, 0xFFAAAAAA, true);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
