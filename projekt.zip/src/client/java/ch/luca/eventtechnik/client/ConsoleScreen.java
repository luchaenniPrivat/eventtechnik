package ch.luca.eventtechnik.client;

import java.util.ArrayList;
import java.util.List;

import org.jetbrains.annotations.Nullable;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

import ch.luca.eventtechnik.blockentity.ConsoleBlockEntity;
import ch.luca.eventtechnik.network.ConsoleActionPayload;
import ch.luca.eventtechnik.show.ShowMath;

/**
 * GUI des Lichtpults.
 * Oben: Gruppenwahl (Alle, 1–8). Mitte: Werte der gewählten Gruppe. Unten: Master.
 */
public class ConsoleScreen extends Screen {
	private static final int PANEL_W = 320;
	private static final int G = ConsoleBlockEntity.GROUPS;

	private final BlockPos pos;
	/** -1 = Alle Gruppen. */
	private int selected = ConsoleBlockEntity.ALL_GROUPS;

	private final List<Button> groupTabs = new ArrayList<>();
	private final List<Button> colorBtns = new ArrayList<>();
	private final List<Button> effectBtns = new ArrayList<>();
	private Button groupOnBtn;
	private Button blackoutBtn;
	private Button strobeBtn;
	private Button autoBtn;
	private int top;
	private int left;

	public ConsoleScreen(BlockPos pos) {
		super(Component.translatable("screen.eventtechnik.console"));
		this.pos = pos;
	}

	@Nullable
	private ConsoleBlockEntity console() {
		if (minecraft == null || minecraft.level == null) return null;
		return minecraft.level.getBlockEntity(pos) instanceof ConsoleBlockEntity c ? c : null;
	}

	private void send(int action, int group, int value) {
		ClientPlayNetworking.send(new ConsoleActionPayload(pos, action, group, value));
	}

	/** Gruppe, deren Werte angezeigt werden (bei "Alle" Gruppe 1). */
	private int shown() {
		return selected < 0 ? 0 : selected;
	}

	@Override
	protected void init() {
		groupTabs.clear();
		colorBtns.clear();
		effectBtns.clear();
		left = width / 2 - PANEL_W / 2;
		top = height / 2 - 100;
		int y = top;

		// Gruppenwahl
		for (int i = -1; i < G; i++) {
			final int grp = i;
			int x = left + (i + 1) * 35;
			Button b = addRenderableWidget(Button.builder(Component.literal(i < 0 ? "Alle" : String.valueOf(i + 1)),
					btn -> selected = grp).bounds(x, y, 33, 20).build());
			groupTabs.add(b);
		}

		// Gruppe: an/aus + Dimmer
		y += 30;
		groupOnBtn = addRenderableWidget(Button.builder(Component.literal("An"), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) send(ConsoleBlockEntity.ACTION_GROUP_ON, selected, c.isRawGroupOn(shown()) ? 0 : 1);
		}).bounds(left, y, 100, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Dimmer -"), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) send(ConsoleBlockEntity.ACTION_GROUP_DIMMER, selected, c.getGroupDimmer(shown()) - 10);
		}).bounds(left + 106, y, 104, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Dimmer +"), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) send(ConsoleBlockEntity.ACTION_GROUP_DIMMER, selected, c.getGroupDimmer(shown()) + 10);
		}).bounds(left + 216, y, 104, 20).build());

		// Farben
		y += 34;
		for (int i = 0; i < ShowMath.COLOR_NAMES.length; i++) {
			final int color = i;
			Button b = addRenderableWidget(Button.builder(Component.literal(ShowMath.COLOR_NAMES[i]),
					btn -> send(ConsoleBlockEntity.ACTION_COLOR, selected, color))
					.bounds(left + (i % 5) * 64, y + (i / 5) * 22, 62, 20).build());
			colorBtns.add(b);
		}

		// Effekte
		y += 56;
		for (int i = 0; i < ShowMath.EFFECT_NAMES.length; i++) {
			final int effect = i;
			Button b = addRenderableWidget(Button.builder(Component.literal(ShowMath.EFFECT_NAMES[i]),
					btn -> send(ConsoleBlockEntity.ACTION_EFFECT, selected, effect))
					.bounds(left + i * 64, y, 62, 20).build());
			effectBtns.add(b);
		}

		// Master Zeile 1
		y += 36;
		blackoutBtn = addRenderableWidget(Button.builder(Component.literal("Blackout"), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) send(ConsoleBlockEntity.ACTION_BLACKOUT, 0, c.isBlackoutSwitch() ? 0 : 1);
		}).bounds(left, y, 104, 20).build());
		strobeBtn = addRenderableWidget(Button.builder(Component.literal("Strobe"), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) send(ConsoleBlockEntity.ACTION_STROBE, 0, c.isStrobe() ? 0 : 1);
		}).bounds(left + 108, y, 104, 20).build());
		autoBtn = addRenderableWidget(Button.builder(Component.literal("Auto"), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) send(ConsoleBlockEntity.ACTION_AUTO, 0, c.isAuto() ? 0 : 1);
		}).bounds(left + 216, y, 104, 20).build());

		// Master Zeile 2
		y += 24;
		master(left, y, "Master -", ConsoleBlockEntity.ACTION_MASTER_DIMMER, -10);
		master(left + 54, y, "Master +", ConsoleBlockEntity.ACTION_MASTER_DIMMER, 10);
		master(left + 108, y, "Speed -", ConsoleBlockEntity.ACTION_SPEED, -1);
		master(left + 162, y, "Speed +", ConsoleBlockEntity.ACTION_SPEED, 1);
		master(left + 216, y, "Haze -", ConsoleBlockEntity.ACTION_HAZE, -1);
		master(left + 270, y, "Haze +", ConsoleBlockEntity.ACTION_HAZE, 1);
	}

	private void master(int x, int y, String label, int action, int delta) {
		addRenderableWidget(Button.builder(Component.literal(label), b -> {
			ConsoleBlockEntity c = console();
			if (c == null) return;
			int current = switch (action) {
				case ConsoleBlockEntity.ACTION_MASTER_DIMMER -> c.getMasterDimmer();
				case ConsoleBlockEntity.ACTION_SPEED -> c.getRawSpeed();
				case ConsoleBlockEntity.ACTION_HAZE -> c.getRawHaze();
				default -> 0;
			};
			send(action, 0, current + delta);
		}).bounds(x, y, 50, 20).build());
	}

	private static Component mark(boolean active, String text) {
		return Component.literal(active ? "§a> " + text : text);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		ConsoleBlockEntity c = console();
		if (c == null) {
			onClose();
			return;
		}
		int g = shown();

		for (int i = 0; i < groupTabs.size(); i++) {
			int grp = i - 1;
			String label = grp < 0 ? "Alle" : String.valueOf(grp + 1);
			groupTabs.get(i).setMessage(Component.literal(grp == selected ? "§e[" + label + "]" : label));
		}
		groupOnBtn.setMessage(Component.literal(c.isRawGroupOn(g) ? "§aGruppe AN" : "§7Gruppe AUS"));
		for (int i = 0; i < colorBtns.size(); i++) {
			colorBtns.get(i).setMessage(mark(i == c.getRawColor(g), ShowMath.COLOR_NAMES[i]));
		}
		for (int i = 0; i < effectBtns.size(); i++) {
			effectBtns.get(i).setMessage(mark(i == c.getRawEffect(g), ShowMath.EFFECT_NAMES[i]));
		}
		blackoutBtn.setMessage(Component.literal(c.isBlackoutSwitch() ? "§cBLACKOUT" : "Blackout"));
		strobeBtn.setMessage(Component.literal(c.isStrobe() ? "§eSTROBE" : "Strobe"));
		autoBtn.setMessage(Component.literal(c.isAuto() ? "§bAUTO (nachts)" : "Auto"));

		super.extractRenderState(graphics, mouseX, mouseY, delta);

		String target = selected < 0 ? "Alle Gruppen" : "Gruppe " + (selected + 1);
		graphics.text(font, "LICHTPULT  –  " + target + "  –  Dimmer " + c.getGroupDimmer(g) + "%", left, top - 24, 0xFFFFD200, true);
		graphics.text(font, "Farbe", left, top + 56, 0xFFAAAAAA, true);
		graphics.text(font, "Effekt", left, top + 112, 0xFFAAAAAA, true);
		graphics.text(font, "Master " + c.getMasterDimmer() + "%   Speed " + c.getRawSpeed() + "   Haze " + c.getRawHaze(),
				left, top + 148, 0xFFFFFFFF, true);
		graphics.text(font, "§7Gerät einer Gruppe zuweisen: mit leerer Hand rechtsklicken", left, top + 206, 0xFFAAAAAA, false);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
