package ch.luca.eventtechnik.client;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.jetbrains.annotations.Nullable;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

import ch.luca.eventtechnik.blockentity.ConsoleBlockEntity;
import ch.luca.eventtechnik.network.ConsoleActionPayload;
import ch.luca.eventtechnik.show.ShowMath;
import ch.luca.eventtechnik.show.ShowPresets;

/**
 * GUI des Lichtpults mit zwei Ansichten:
 * "Programmieren" (Seite, Gruppe, Farbe, Effekt, Master) und "Presets" (fertige Shows).
 */
public class ConsoleScreen extends Screen {
	private static final int PANEL_W = 320;
	private static final int G = ConsoleBlockEntity.GROUPS;
	private static final int P = ConsoleBlockEntity.PAGES;

	private final BlockPos pos;
	private boolean presetView = false;
	private int page = -1;
	private int group = -1;

	private final List<Button> pageTabs = new ArrayList<>();
	private final List<Button> groupTabs = new ArrayList<>();
	private final List<Button> colorBtns = new ArrayList<>();
	private final List<Button> effectBtns = new ArrayList<>();
	private final List<Button> presetBtns = new ArrayList<>();
	@Nullable private Button groupOnBtn;
	@Nullable private Button blackoutBtn;
	@Nullable private Button strobeBtn;
	@Nullable private Button autoBtn;
	@Nullable private Button followBtn;
	@Nullable private Button syncBtn;
	private int top;
	private int left;

	public ConsoleScreen(BlockPos pos) {
		super(Component.translatable("screen.eventtechnik.console"));
		this.pos = pos;
	}

	@Nullable
	private ConsoleBlockEntity console() {
		if (minecraft == null || minecraft.level == null) return null;
		return minecraft.level.getBlockEntity(pos) instanceof ConsoleBlockEntity c ? c : null;
	}

	private void send(int action, int value) {
		ClientPlayNetworking.send(new ConsoleActionPayload(pos, action, ConsoleBlockEntity.target(page, group), value));
	}

	private void sendMaster(int action, int value) {
		ClientPlayNetworking.send(new ConsoleActionPayload(pos, action, 0, value));
	}

	private int shownPage() { return Math.max(0, page); }
	private int shownGroup() { return Math.max(0, group); }

	@Override
	protected void init() {
		pageTabs.clear();
		groupTabs.clear();
		colorBtns.clear();
		effectBtns.clear();
		presetBtns.clear();
		groupOnBtn = blackoutBtn = strobeBtn = autoBtn = followBtn = syncBtn = null;
		left = width / 2 - PANEL_W / 2;
		top = height / 2 - 112;

		// Umschalter oben rechts
		addRenderableWidget(Button.builder(Component.literal(presetView ? "Programmieren" : "§dPresets"), b -> {
			presetView = !presetView;
			rebuildWidgets();
		}).bounds(left + PANEL_W - 90, top - 26, 90, 20).build());

		if (presetView) {
			initPresets();
		} else {
			initProgrammer();
		}
		initMaster(top + 176);
	}

	private void initPresets() {
		int y = top;
		for (int i = 0; i < ShowPresets.PRESETS.length; i++) {
			final int idx = i;
			presetBtns.add(addRenderableWidget(Button.builder(Component.literal(""), b -> sendMaster(ConsoleBlockEntity.ACTION_PRESET, idx))
					.bounds(left + (i % 3) * 107, y + (i / 3) * 26, 104, 22).build()));
		}
	}

	private void initProgrammer() {
		int y = top;
		for (int i = -1; i < P; i++) {
			final int p = i;
			pageTabs.add(addRenderableWidget(Button.builder(Component.literal(""), b -> page = p)
					.bounds(left + (i + 1) * 46, y, 44, 20).build()));
		}
		y += 22;
		for (int i = -1; i < G; i++) {
			final int g = i;
			groupTabs.add(addRenderableWidget(Button.builder(Component.literal(""), b -> group = g)
					.bounds(left + (i + 1) * 35, y, 33, 20).build()));
		}

		y += 26;
		groupOnBtn = addRenderableWidget(Button.builder(Component.literal(""), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) send(ConsoleBlockEntity.ACTION_GROUP_ON, c.isRawGroupOn(shownPage(), shownGroup()) ? 0 : 1);
		}).bounds(left, y, 100, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Dimmer -"), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) send(ConsoleBlockEntity.ACTION_GROUP_DIMMER, c.getGroupDimmer(shownPage(), shownGroup()) - 10);
		}).bounds(left + 106, y, 104, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Dimmer +"), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) send(ConsoleBlockEntity.ACTION_GROUP_DIMMER, c.getGroupDimmer(shownPage(), shownGroup()) + 10);
		}).bounds(left + 216, y, 104, 20).build());

		y += 24;
		for (int i = 0; i < ShowMath.COLOR_NAMES.length; i++) {
			final int color = i;
			colorBtns.add(addRenderableWidget(Button.builder(Component.literal(""), b -> send(ConsoleBlockEntity.ACTION_COLOR, color))
					.bounds(left + (i % 5) * 64, y + (i / 5) * 21, 62, 19).build()));
		}

		y += 44;
		for (int i = 0; i < ShowMath.EFFECT_COUNT; i++) {
			final int effect = i;
			effectBtns.add(addRenderableWidget(Button.builder(Component.literal(""), b -> send(ConsoleBlockEntity.ACTION_EFFECT, effect))
					.bounds(left + (i % 5) * 64, y + (i / 5) * 21, 62, 19).build()));
		}
	}

	private void initMaster(int y) {
		blackoutBtn = addRenderableWidget(Button.builder(Component.literal(""), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) sendMaster(ConsoleBlockEntity.ACTION_BLACKOUT, c.isBlackoutSwitch() ? 0 : 1);
		}).bounds(left, y, 62, 20).build());
		strobeBtn = addRenderableWidget(Button.builder(Component.literal(""), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) sendMaster(ConsoleBlockEntity.ACTION_STROBE, c.isStrobe() ? 0 : 1);
		}).bounds(left + 64, y, 62, 20).build());
		autoBtn = addRenderableWidget(Button.builder(Component.literal(""), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) sendMaster(ConsoleBlockEntity.ACTION_AUTO, c.isAuto() ? 0 : 1);
		}).bounds(left + 128, y, 62, 20).build());
		syncBtn = addRenderableWidget(Button.builder(Component.literal(""), b -> {
			ConsoleBlockEntity c = console();
			if (c != null) sendMaster(ConsoleBlockEntity.ACTION_SYNC, c.isSync() ? 0 : 1);
		}).bounds(left + 192, y, 62, 20).build());
		followBtn = addRenderableWidget(Button.builder(Component.literal(""), b -> cycleFollow())
				.bounds(left + 256, y, 64, 20).build());

		y += 22;
		master(left, y, "Master -", ConsoleBlockEntity.ACTION_MASTER_DIMMER, -10);
		master(left + 54, y, "Master +", ConsoleBlockEntity.ACTION_MASTER_DIMMER, 10);
		master(left + 108, y, "Speed -", ConsoleBlockEntity.ACTION_SPEED, -1);
		master(left + 162, y, "Speed +", ConsoleBlockEntity.ACTION_SPEED, 1);
		master(left + 216, y, "Haze -", ConsoleBlockEntity.ACTION_HAZE, -1);
		master(left + 270, y, "Haze +", ConsoleBlockEntity.ACTION_HAZE, 1);
	}

	private void cycleFollow() {
		ConsoleBlockEntity c = console();
		if (c == null || minecraft == null || minecraft.level == null) return;
		List<? extends Player> players = minecraft.level.players();
		UUID current = c.getFollowTarget();
		int idx = -1;
		for (int i = 0; i < players.size(); i++) {
			if (players.get(i).getUUID().equals(current)) idx = i;
		}
		int next = idx + 1;
		sendMaster(ConsoleBlockEntity.ACTION_FOLLOW, next < players.size() ? players.get(next).getId() : -1);
	}

	private String followName(ConsoleBlockEntity c) {
		UUID t = c.getFollowTarget();
		if (t == null || minecraft == null || minecraft.level == null) return "–";
		Player p = minecraft.level.getPlayerByUUID(t);
		return p == null ? "weg" : p.getName().getString();
	}

	private void master(int x, int y, String label, int action, int delta) {
		addRenderableWidget(Button.builder(Component.literal(label), b -> {
			ConsoleBlockEntity c = console();
			if (c == null) return;
			int current = switch (action) {
				case ConsoleBlockEntity.ACTION_MASTER_DIMMER -> c.getMasterDimmer();
				case ConsoleBlockEntity.ACTION_SPEED -> c.getRawSpeed();
				case ConsoleBlockEntity.ACTION_HAZE -> c.getRawHaze();
				default -> 0;
			};
			sendMaster(action, current + delta);
		}).bounds(x, y, 50, 20).build());
	}

	private static Component mark(boolean active, String text) {
		return Component.literal(active ? "§a> " + text : text);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		ConsoleBlockEntity c = console();
		if (c == null) {
			onClose();
			return;
		}
		int p = shownPage();
		int g = shownGroup();

		for (int i = 0; i < presetBtns.size(); i++) {
			presetBtns.get(i).setMessage(mark(i == c.getLastPreset(), ShowPresets.PRESETS[i].name()));
		}
		for (int i = 0; i < pageTabs.size(); i++) {
			int pi = i - 1;
			String label = pi < 0 ? "Alle" : ConsoleBlockEntity.PAGE_NAMES[pi];
			pageTabs.get(i).setMessage(Component.literal(pi == page ? "§e" + label : label));
		}
		for (int i = 0; i < groupTabs.size(); i++) {
			int gi = i - 1;
			String label = gi < 0 ? "Alle" : String.valueOf(gi + 1);
			groupTabs.get(i).setMessage(Component.literal(gi == group ? "§e[" + label + "]" : label));
		}
		if (groupOnBtn != null) groupOnBtn.setMessage(Component.literal(c.isRawGroupOn(p, g) ? "§aAN" : "§7AUS"));
		for (int i = 0; i < colorBtns.size(); i++) {
			colorBtns.get(i).setMessage(mark(i == c.getRawColor(p, g), ShowMath.COLOR_NAMES[i]));
		}
		String[] fx = page < 0 ? null : ShowMath.effectNames(page);
		for (int i = 0; i < effectBtns.size(); i++) {
			String name = fx == null ? ShowMath.HEAD_FX[i] + "/" + ShowMath.PIXEL_FX[i].charAt(0) : fx[i];
			effectBtns.get(i).setMessage(mark(i == c.getRawEffect(p, g), name));
		}
		if (blackoutBtn != null) blackoutBtn.setMessage(Component.literal(c.isBlackoutSwitch() ? "§cBLACK" : "Blackout"));
		if (strobeBtn != null) strobeBtn.setMessage(Component.literal(c.isStrobe() ? "§eSTROBE" : "Strobe"));
		if (autoBtn != null) autoBtn.setMessage(Component.literal(c.isAuto() ? "§bAUTO" : "Auto"));
		if (syncBtn != null) syncBtn.setMessage(Component.literal(c.isSync() ? (c.isBeatSynced() ? "§a♪ Sync" : "§7Sync") : "Sync aus"));
		if (followBtn != null) followBtn.setMessage(Component.literal("Ziel: " + followName(c)));

		super.extractRenderState(graphics, mouseX, mouseY, delta);

		if (presetView) {
			graphics.text(font, "LICHTPULT  –  Presets", left, top - 20, 0xFFFFD200, true);
		} else {
			String pageName = page < 0 ? "Alle Seiten" : ConsoleBlockEntity.PAGE_NAMES[page];
			String groupName = group < 0 ? "alle Gruppen" : "Gruppe " + (group + 1);
			graphics.text(font, "LICHTPULT  –  " + pageName + ", " + groupName + "  –  " + c.getGroupDimmer(p, g) + "%",
					left, top - 20, 0xFFFFD200, true);
		}
		String beat = c.isBeatSynced() ? "   §a♪ im Takt mit dem DJ" : "";
		graphics.text(font, "Master " + c.getMasterDimmer() + "%   Speed " + c.getRawSpeed() + "   Haze " + c.getRawHaze() + beat,
				left, top + 166, 0xFFFFFFFF, true);
		graphics.text(font, "§7Gruppe zuweisen: leere Hand + Rechtsklick aufs Gerät", left, top + 222, 0xFFAAAAAA, false);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
