package ch.luca.eventtechnik.client;

import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.core.Direction;

/** Alles, was der Renderer pro Bild für einen Moving Head braucht. */
public class FixtureRenderState extends BlockEntityRenderState {
	public boolean movingHead;
	public boolean wash;
	public Direction facing = Direction.UP;
	public float pan;
	public float tilt;
	public boolean on;
	public int rgb = 0xFFFFFF;
	/** 0..1, aus Dimmer und Haze. */
	public float intensity;
	public float beamLength;
}
