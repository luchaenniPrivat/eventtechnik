package ch.luca.eventtechnik.client;

import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.core.Direction;

/** Alles, was der Renderer pro Bild für ein Gerät braucht. */
public class FixtureRenderState extends BlockEntityRenderState {
	public static final int PANEL_RES = 4;

	public boolean movingHead;
	public boolean panel;
	public boolean wash;
	public Direction facing = Direction.UP;

	// Moving Head
	public float pan;
	public float tilt;
	public boolean on;
	public int rgb = 0xFFFFFF;
	/** 0..1, aus Dimmer und Haze. */
	public float intensity;
	public float beamLength;

	// LED-Wand: PANEL_RES × PANEL_RES Pixel, RGB oder -1 für aus
	public final int[] pixels = new int[PANEL_RES * PANEL_RES];
	public float panelBrightness;
}
